// kök Edit — Субтитры для открытой последовательности: локальный Whisper или облако → дорожка субтитров / шаблон .mogrt.
(function () {
  const { $, esc, log, status, fmt } = K;
  const DEFAULTS = { mode: "srt", lang: "kk", words: 3, chars: 28, punct: "keep", fix: false, hint: "", stt: "local", key: "", model: "", mogrt: "" };
  const SC = require(K.path.join(K.EXT, "lib", "subclean.js"));
  const AI_MODEL = "claude-haiku-5-5";
  const aiKey = () => (K.cfg.ai && K.cfg.ai.key) || "";
  const c = () => K.cfg.sb;
  K.cfg.sb = K.cfg.sb || {};
  // перенос настроек субтитров из «Нарезок» прошлой версии
  const old = K.cfg.cl || {};
  for (const k of ["lang", "words", "hint", "key", "model", "mogrt"]) if (c()[k] === undefined && old[k] !== undefined) c()[k] = old[k];
  if (c().stt === undefined && old.stt && old.key) c().stt = old.stt;
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = v;
  const MODELS = { elevenlabs: "scribe_v2", openai: "whisper-1" };
  // есть ключ ElevenLabs — по умолчанию распознаём там (точнее на живой казахской речи)
  if (c().key && c().stt === "local" && !c().sttManual) c().stt = "elevenlabs";
  const SVC = { local: "whisper", elevenlabs: "elevenlabs", openai: "openai" };
  const BIN = "kök Edit/Субтитры";

  // готовая расшифровка этой последовательности (из «Расшифровки и AI», копии или нарезки)
  let ready = null, fresh = false;
  const usable = () => !!ready && !fresh && (c().lang === "auto" || !ready.lang || ready.lang === "auto" || ready.lang === c().lang);
  async function checkReady() {
    ready = null;
    if (K.scan) { try { ready = await K.TR.find(K.scan.seqId); } catch (e) {} }
    render();
  }
  function render() {
    K.renderSegs($("scr-subs"), c());
    const local = c().stt === "local", st = K.stt;
    $("sb-mogrtRow").classList.toggle("hidden", c().mode !== "mogrt");
    $("sb-mogrtName").textContent = c().mogrt ? K.path.basename(c().mogrt) : "не выбран";
    $("sb-words").value = c().words;
    $("sb-chars").value = c().chars;
    $("sb-fix").checked = !!c().fix;
    $("sb-hint").value = c().hint || "";
    $("sb-stt").value = c().stt;
    $("sb-localBox").classList.toggle("hidden", !local);
    $("sb-cloudBox").classList.toggle("hidden", local);
    $("sb-mBase").textContent = st.has(st.BASE) ? "готова ✓" : "скачается при первом запуске (547 МБ)";
    $("sb-mKaz").textContent = st.has(st.KAZ) ? "готова ✓" : "не подготовлена";
    $("sb-prepare").classList.toggle("hidden", st.has(st.KAZ));
    $("sb-prepare").disabled = K.busy;
    $("sb-key").value = c().key;
    $("sb-model").value = c().model;
    $("sb-model").placeholder = MODELS[c().stt] || "";
    const use = usable();
    $("sb-trRow").classList.toggle("hidden", !ready);
    $("sb-trState").textContent = !ready ? "" : use ? `Готовая расшифровка: ${ready.words.length} слов, ${ready.svc}${ready.how && ready.how !== "готовая" ? ", " + ready.how : ""} — запроса в сервис не будет`
      : `Есть расшифровка на другом языке (${ready.lang}) — распознаю заново`;
    $("sb-fresh").checked = !!fresh;
    const needKey = !use && !local && !c().key;
    const why = !K.scan ? "Откройте последовательность" : c().mode === "mogrt" && !c().mogrt ? "Выберите шаблон .mogrt"
      : needKey ? "Для облачного сервиса нужен ключ API"
      : !use && !local && !K.lic.can("cloudStt") ? K.noFeature("cloudStt")
      : c().fix && !K.lic.can("ai") ? "ИИ-корректура — в подписке. Снимите галочку или подключите подписку."
      : c().fix && !aiKey() ? "Для ИИ-корректуры нужен ключ Claude (раздел «Расшифровка и AI»)" : "";
    $("sb-why").textContent = why;
    $("sb-run").disabled = K.busy || !!why;
  }

  $("scr-subs").addEventListener("change", (e) => {
    const t = e.target;
    if (t.id === "sb-words") c().words = Math.max(1, Math.min(8, parseInt(t.value, 10) || 3));
    else if (t.id === "sb-chars") c().chars = Math.max(12, Math.min(60, parseInt(t.value, 10) || 28));
    else if (t.id === "sb-fix") c().fix = t.checked;
    else if (t.id === "sb-stt") { c().stt = t.value; c().sttManual = true; }
    else if (t.id === "sb-key") { c().key = t.value.trim(); if (c().key && !c().sttManual) c().stt = "elevenlabs"; }
    else if (t.id === "sb-model") c().model = t.value.trim();
    else if (t.id === "sb-hint") c().hint = t.value.trim();
    else return;
    K.saveCfg(); render();
  });
  $("sb-mogrtPick").onclick = () => { const f = K.pickFile("Шаблон субтитров (.mogrt)", ["mogrt"]); if (f) { c().mogrt = f; K.saveCfg(); render(); } };
  $("sb-prepare").onclick = async () => {
    if (K.busy) return;
    K.setBusy(true);
    try { await K.stt.ensureKazakh((m) => status(m)); status("Казахская модель готова ✓", "good"); }
    catch (e) { status("Казахская модель: " + e.message, "err"); log("ОШИБКА модели: " + e.message); }
    K.setBusy(false);
  };

  function hintText() {
    const names = Object.values(K.cfg.ac.mics || {}).filter((m) => m.use && m.name && !/^Спикер \d+$/.test(m.name)).map((m) => m.name);
    return [...names, ...String(c().hint || "").split(",").map((x) => x.trim()).filter(Boolean)].join(", ");
  }

  // ---------- распознавание ----------
  // opt.events — вернуть и звуковые события (смех и т.п.) в свойстве .events (только ElevenLabs)
  async function transcribe(wav, opt) {
    opt = opt || {};
    const lang = c().lang;
    if (c().stt === "local") return K.stt.transcribe(wav, lang, hintText(), (m) => status(m));
    if (!K.lic.can("cloudStt")) throw new Error(K.noFeature("cloudStt"));
    const flac = wav.replace(/\.wav$/, ".flac");
    await K.ffmpeg(["-y", "-v", "error", "-i", wav, "-ac", "1", "-ar", "16000", "-c:a", "flac", flac]);
    status("Отправляю звук в " + (c().stt === "elevenlabs" ? "ElevenLabs" : "OpenAI") + "…");
    const model = c().model || MODELS[c().stt];
    try {
      if (c().stt === "elevenlabs") {
        const call = (m) => {
          const fields = [["model_id", m], ["timestamps_granularity", "word"], ["tag_audio_events", opt.events ? "true" : "false"], ["diarize", "false"]];
          if (lang !== "auto") fields.push(["language_code", { kk: "kaz", ru: "rus", en: "eng" }[lang] || "rus"]);
          return K.postMultipart("https://api.elevenlabs.io/v1/speech-to-text", { "xi-api-key": c().key }, fields, { field: "file", path: flac, type: "audio/flac" });
        };
        let r;
        try { r = await call(model); }
        catch (e) {
          // модель по умолчанию не принята — пробуем предыдущую
          if (!c().model && /HTTP 4\d\d/.test(e.message) && /model/i.test(e.message)) { log("scribe_v2 не принята, пробую scribe_v1"); r = await call("scribe_v1"); }
          else throw e;
        }
        const words = (r.words || []).filter((w) => w.type === "word" && w.text && w.text.trim()).map((w) => ({ w: w.text.trim(), s: w.start, e: w.end }));
        words.events = (r.words || []).filter((w) => w.type === "audio_event").map((w) => ({ t: w.start, type: String(w.text || "").replace(/[()\[\]]/g, "").trim() }));
        return words;
      }
      const fields = [["model", model], ["response_format", "verbose_json"], ["timestamp_granularities[]", "word"]];
      if (lang !== "auto") fields.push(["language", lang]);
      if (hintText()) fields.push(["prompt", hintText()]);
      const r = await K.postMultipart("https://api.openai.com/v1/audio/transcriptions", { Authorization: "Bearer " + c().key }, fields, { field: "file", path: flac, type: "audio/flac" });
      return (r.words || []).map((w) => ({ w: String(w.word).trim(), s: w.start, e: w.end })).filter((w) => w.w);
    } finally { try { K.fs.unlinkSync(flac); } catch (e) {} }
  }

  // слова → строки: чистка паразитов и обрывков, предлоги не в конце строки, разрыв по смыслу (lib/subclean.js)
  // Чистится только текст субтитров — сохранённая расшифровка остаётся как есть (нужна «Паузам» и AI)
  function chunk(words, n) {
    return SC.finish(SC.chunk(SC.clean(words), { n: n || c().words, chars: c().chars || 28, lang: c().lang }), c().punct);
  }

  // ИИ-корректура: строки пачками по 120, тайминги не трогаем
  async function aiFix(caps) {
    const model = (K.cfg.ai && K.cfg.ai.model) || AI_MODEL;
    let changed = 0;
    for (let i = 0; i < caps.length; i += 120) {
      const part = caps.slice(i, i + 120);
      status(`ИИ-корректура: строки ${i + 1}–${i + part.length} из ${caps.length}…`);
      try {
        const r = await K.postJSON("https://api.anthropic.com/v1/messages",
          { "x-api-key": aiKey(), "anthropic-version": "2023-06-01" },
          { model, max_tokens: 8000, system: "Ты — редактор субтитров видеопродакшена в Казахстане. Отвечаешь строго JSON, без пояснений.",
            messages: [{ role: "user", content: SC.promptFix(part.map((x) => x.text), c().lang, hintText()) }] });
        const text = (r.content || []).map((x) => x.text || "").join("");
        const a = text.indexOf("{"), b = text.lastIndexOf("}");
        if (a < 0 || b < a) { log(`  ИИ-корректура: строки ${i + 1}–${i + part.length} без ответа JSON — оставлены как есть`); continue; }
        changed += SC.applyFix(part, JSON.parse(text.slice(a, b + 1)), 0);
        for (let k = 0; k < part.length; k++) caps[i + k] = part[k];
        if (r.usage) log(`  Claude: вход ${r.usage.input_tokens} токенов, ответ ${r.usage.output_tokens}`);
      } catch (e) { log(`  ИИ-корректура: строки ${i + 1}–${i + part.length} оставлены как есть — ${e.message}`); }
    }
    log(`ИИ-корректура (${model}): исправлено строк ${changed} из ${caps.length}`);
    return SC.finish(caps, c().punct); // знаки в конце — после модели, она могла их вернуть
  }
  async function build(words) {
    let caps = chunk(words, c().words);
    if (c().fix && aiKey() && caps.length) {
      if (K.lic.can("ai")) caps = await aiFix(caps);
      else log("ИИ-корректура пропущена: " + K.noFeature("ai"));
    }
    return caps;
  }
  const srtTime = (s) => {
    const ms = Math.round(s * 1000), h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), sec = Math.floor((ms % 60000) / 1000);
    const p = (x, l) => String(x).padStart(l, "0");
    return `${p(h, 2)}:${p(m, 2)}:${p(sec, 2)},${p(ms % 1000, 3)}`;
  };
  const toSrt = (caps) => caps.map((x, i) => `${i + 1}\n${srtTime(x.t)} --> ${srtTime(x.t + x.d)}\n${x.text}\n`).join("\n");

  async function run() {
    if (!K.scan || K.busy) return;
    K.setBusy(true);
    const scan = K.scan, svc = SVC[c().stt];
    K.report = [`Субтитры: «${scan.seqName}» (${fmt(scan.seqEnd)}), язык ${c().lang}, сервис ${svc}${c().stt !== "local" ? " " + (c().model || MODELS[c().stt]) : ""}`];
    const dir = K.path.join(K.OUT, "subs");
    K.fs.mkdirSync(dir, { recursive: true });
    try {
      const t0 = Date.now();
      let words, t1 = t0, t2;
      if (!fresh) { try { ready = await K.TR.find(scan.seqId); } catch (e) { ready = null; } }
      if (usable()) {
        words = ready.words;
        t2 = Date.now();
        log(`Расшифровка готовая (${ready.svc}, ${ready.how || "готовая"}) — в сервис ничего не отправлялось`);
      } else {
        const wav = K.path.join(K.CACHE, `subs_${Date.now()}.wav`);
        status("Premiere выгружает звук последовательности… Premiere может не отвечать.");
        await K.exportWav(scan.seqId, -1, wav);
        t1 = Date.now();
        words = await transcribe(wav, { events: c().stt === "elevenlabs" });
        try { K.fs.unlinkSync(wav); } catch (e) {}
        t2 = Date.now();
        // сохраняем — пригодится AI, паузам и нарезкам
        if (words.length) { try { ready = await K.TR.save(scan.seqId, { words, events: words.events || [], svc: svc, lang: c().lang }, scan.seqName); } catch (e) {} }
        fresh = false;
      }
      const caps = await build(words);
      const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-");
      const srt = K.path.join(dir, `${K.safeName(scan.seqName)}_${svc}_${c().lang}_${stamp}.srt`);
      K.fs.writeFileSync(srt, toSrt(caps), "utf8");
      log(`Выгрузка звука ${((t1 - t0) / 1000).toFixed(0)} с, распознавание ${((t2 - t1) / 1000).toFixed(0)} с; слов ${words.length}, строк ${caps.length}`);
      log(`SRT: ${srt}`);
      if (!caps.length) throw new Error("Речь не распознана");
      status("Кладу субтитры на таймлайн…");
      let r;
      if (c().mode === "srt") r = await K.call("ac_captionsSRT", scan.seqId, srt, BIN);
      else {
        r = await K.call("ac_captionsMGT", scan.seqId, c().mogrt, caps);
        if (r.ok) log(`Шаблонов ${r.n}, текст подставлен в ${r.text}`);
      }
      if (!r.ok) throw new Error(r.error + ` — файл SRT лежит: ${srt}`);
      status(`Готово: ${caps.length} строк (${svc}). Файл: ${K.path.basename(srt)}`, "good");
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    log("Лог: " + K.saveLog("subs_" + svc));
    K.setBusy(false);
  }
  $("sb-run").onclick = run;

  $("sb-fresh").onchange = (e) => { fresh = e.target.checked; render(); };
  K.modules.subs = { title: "Субтитры", cfgKey: "sb", needsTimeline: true, onScan: checkReady, render, transcribe, svcName: () => SVC[c().stt], _chunk: chunk, _toSrt: toSrt };
})();

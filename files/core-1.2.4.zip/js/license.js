// kök Edit — вход и лицензия: почта или телефон → код → компьютер привязан к аккаунту.
// Пока лицензии нет или она закончилась — открыт только этот экран. Монтаж и файлы не трогаются.
(function () {
  const { $, esc, status } = K;
  const L = require(K.path.join(K.EXT, "lib", "license.js"));
  const FILE = K.path.join(K.WORK, "license.json");
  // тестовая среда — тестовая CRM, клиенты — основная kök
  const DEFAULTS = { server: K.CHANNEL === "test" ? "https://test.msng.app" : "https://kok.blue", contact: "" };
  const c = () => K.cfg.lic;
  K.cfg.lic = K.cfg.lic || {};
  if (c().contact === undefined) c().contact = "";
  if (c().server === "https://kok.blue") c().server = ""; // 1.2.0 запоминал адрес по умолчанию  // сервер не запоминаем по умолчанию — он зависит от канала (тест/клиенты)
  const BUY = "https://kok.blue/edit#try"; // заявка на подписку — свяжемся по номеру из заявки
  const CHECK_EVERY = 6 * 3600000;
  const VERSION = K.VERSION;

  // ---------- отпечаток компьютера ----------
  function machineGuid() {
    try {
      const out = require("child_process").execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: "utf8", timeout: 5000, windowsHide: true });
      const m = out.match(/MachineGuid\s+REG_SZ\s+([0-9a-f-]{20,})/i);
      return m ? m[1].toLowerCase() : "";
    } catch (e) { return ""; }
  }
  function fallbackId() {
    const nets = K.os.networkInterfaces();
    const macs = Object.values(nets).flat().filter((n) => n && !n.internal && n.mac && n.mac !== "00:00:00:00:00:00").map((n) => n.mac).sort();
    return [K.os.hostname(), K.os.cpus()[0] ? K.os.cpus()[0].model : "", K.os.totalmem(), macs[0] || ""].join("|");
  }
  const DEVICE = K.crypto.createHash("sha256").update("kok-edit|" + (machineGuid() || fallbackId())).digest("hex");
  const DEVICE_NAME = K.os.hostname();

  // ---------- хранение ----------
  let saved = null; // { token, data, sig }
  try { saved = JSON.parse(K.fs.readFileSync(FILE, "utf8")); } catch (e) {}
  const store = () => { try { K.fs.writeFileSync(FILE, JSON.stringify(saved || {})); } catch (e) {} };
  let lic = saved && saved.data ? L.verify(saved.data, saved.sig) : null;
  let st = lic ? L.state(lic, DEVICE, Date.now(), false) : { ok: false, reason: "login" };
  let view = "check"; // check | login | code | seats | blocked
  let seats = null, lastCheck = 0, msg = "", info = "", noAccount = false;

  const base = () => String(c().server || DEFAULTS.server).trim().replace(/\/+$/, "") + "/api/edit";
  const post = (path, body, token) => K.request("POST", base() + path, token ? { Authorization: "Bearer " + token } : {}, body, 20000);

  function apply(r, online) {
    const v = L.verify(r.data, r.sig);
    if (!v) throw new Error("Ответ сервера не прошёл проверку подписи — обновите kök Edit.");
    lic = v;
    saved = Object.assign(saved || {}, { data: r.data, sig: r.sig }, r.token ? { token: r.token } : {});
    store();
    st = L.state(lic, DEVICE, Date.now(), online);
  }

  // ---------- проверка ----------
  async function check(quiet) {
    if (!saved || !saved.token) { st = { ok: false, reason: "login" }; view = "login"; return finish(); }
    try {
      const r = await post("/check", { device: DEVICE, version: VERSION }, saved.token);
      apply(r, true);
      lastCheck = Date.now();
      msg = "";
    } catch (e) {
      if (e.status === 401) { saved = null; lic = null; store(); st = { ok: false, reason: "login" }; msg = e.message; }
      else {
        // нет связи — работаем по сохранённой лицензии, пока не истёк срок без интернета
        st = lic ? L.state(lic, DEVICE, Date.now(), false) : { ok: false, reason: "login" };
        if (!quiet || !st.ok) msg = e.offline ? "Нет связи с сервером kök." : e.message;
      }
    }
    view = st.ok ? "ok" : st.reason === "login" || st.reason === "device" ? "login" : "blocked";
    finish();
  }
  function finish() {
    render();
    K.onLicense && K.onLicense(st.ok);
  }
  setInterval(() => { if (!K.busy) check(true); }, CHECK_EVERY);

  // ---------- что разрешено ----------
  K.lic = {
    ok: () => st.ok,
    can: (f) => st.ok && !!lic && !!lic[f], // "ai" | "cloudStt"
    info: () => lic,
    device: DEVICE,
    check,
  };
  K.noFeature = (f) => (f === "ai" ? "ИИ-функции не входят в ваш тариф." : "Распознавание в облаке не входит в ваш тариф — выберите «Локально (Whisper)».");

  // ---------- экран ----------
  const fmtD = (t) => new Date(t).toLocaleDateString("ru-RU");
  const PLAN = { trial: "Пробный месяц", paid: "Подписка", off: "Выключен" };
  function render() {
    const box = $("lic-body");
    if (!box) return;
    $("lic-server").value = c().server || DEFAULTS.server;
    let h = "";
    if (view === "check") h = `<div class="small-text" style="text-align:center">Проверяю лицензию…</div>`;
    else if (view === "login") {
      h = `<div class="card"><h4>Вход в kök Edit</h4>
        <div class="small-text" style="margin-bottom:6px">Почта и пароль — из письма «Ваш доступ к kök Edit» после покупки. Вход по номеру телефона — пароль из 8 цифр в Telegram.</div>
        <div class="row"><input type="text" id="lic-contact" class="grow" placeholder="почта или +7 7XX XXX XX XX" value="${esc(c().contact)}" autocomplete="username"></div>
        <div class="row"><input type="password" id="lic-pwd" class="grow" placeholder="пароль" autocomplete="current-password"><button class="btn" id="lic-verify">Войти</button></div>
        <div class="row"><a href="#" id="lic-send" class="small-text">Прислать пароль</a><span class="grow"></span><span class="small-text">Этот компьютер: <b>${esc(DEVICE_NAME)}</b></span></div>
        ${info ? `<div class="small-text good">${esc(info)}</div>` : ""}
        ${noAccount ? `<div class="row" style="margin-top:6px"><button class="main" data-lic-buy style="margin:0">Оставить заявку на подписку</button></div>` : ""}
        <div class="small-text" style="margin-top:6px">Нет подписки? <a href="#" data-lic-buy>Оставьте заявку</a> — свяжемся. Помощь: support@kok.blue</div></div>`;
    } else if (view === "seats") {
      h = `<div class="card"><h4>Все места заняты</h4>
        <div class="small-text">Аккаунт уже работает на других компьютерах. ${seats.canRelease ? "Отвяжите старый — сами можно раз в 30 дней." : `Сами отвязать можно с ${fmtD(seats.nextRelease)} — или напишите на support@kok.blue.`}</div>
        <div class="list" style="margin-top:6px">${seats.devices.map((d) => `<div class="li"><span class="nm">${esc(d.name || "компьютер")}<br><span class="small-text">${d.lastSeenAt ? "был " + new Date(d.lastSeenAt).toLocaleString("ru-RU") : ""}</span></span>
          ${seats.canRelease ? `<button class="btn" data-lic-rel="${esc(d.id)}">Отвязать и войти здесь</button>` : ""}</div>`).join("")}</div>
        <div class="row"><button class="btn grow" id="lic-back">Назад</button><button class="btn grow" data-lic-buy>Оставить заявку</button></div></div>`;
    } else if (view === "blocked") {
      const why = st.reason === "off" ? "Подписка не активна."
        : st.reason === "expired" ? `${PLAN[lic.plan] || "Подписка"} закончилась ${fmtD(lic.until)}.`
        : "Нужен интернет: kök Edit проверяет подписку хотя бы раз в 3 дня.";
      h = `<div class="card"><h4>kök Edit не активен</h4><div>${esc(why)}</div>
        <div class="small-text" style="margin-top:4px">Аккаунт: ${esc(lic ? lic.contact : "")}. Проекты и монтаж не затронуты — открыт только этот экран.</div>
        <div class="row" style="margin-top:8px"><button class="main" data-lic-buy style="margin:0">Продлить подписку</button></div>
        <div class="row"><button class="btn grow" id="lic-recheck">Проверить снова</button><button class="btn grow" id="lic-logout">Выйти из аккаунта</button></div></div>`;
    } else {
      // вошли — сведения об аккаунте
      h = `<div class="card"><h4>Аккаунт</h4>
        <div class="row"><div class="label">Вход</div><div class="grow"><b>${esc(lic.contact)}</b>${lic.name ? " · " + esc(lic.name) : ""}</div></div>
        <div class="row"><div class="label">Тариф</div><div class="grow">${PLAN[lic.plan] || lic.plan} до ${fmtD(lic.until)}</div></div>
        <div class="row"><div class="label">ИИ-функции</div><div class="grow">${lic.ai ? "есть" : "не входят в тариф"}</div></div>
        <div class="row"><div class="label">Компьютер</div><div class="grow">${esc(DEVICE_NAME)} · мест в аккаунте ${lic.seats}</div></div>
        <div class="row"><button class="btn grow" id="lic-recheck">Проверить подписку</button><button class="btn grow" id="lic-logout" data-tip="Освободит место — можно войти на другом компьютере.">Выйти на этом компьютере</button></div>
        ${lic.plan !== "paid" ? `<div class="row"><button class="main" data-lic-buy style="margin:0">Продлить подписку</button></div>` : ""}</div>`;
    }
    box.innerHTML = h + (msg ? `<div class="small-text err" style="text-align:center">${esc(msg)}</div>` : "");
    if (K.update) K.update.render();
    // строка на главном экране
    const foot = $("lic-foot");
    if (foot) {
      const left = lic ? Math.ceil((lic.until - Date.now()) / 86400000) : 0;
      foot.innerHTML = st.ok && lic ? `${PLAN[lic.plan] || ""} до ${fmtD(lic.until)}${lic.plan === "trial" ? ` · осталось ${left} дн. · без ИИ` : !lic.ai ? " · без ИИ" : ""} · <a href="#" id="lic-acc">аккаунт</a>` : "";
      foot.classList.toggle("warn", st.ok && lic && left <= 5);
    }
  }

  async function act(fn) {
    msg = "";
    try { await fn(); } catch (e) { msg = e.message; }
    render();
  }
  let pwdMem = ""; // пароль держим только до конца входа (для «Отвязать и войти здесь»)
  async function login(replace) {
    const pwd = ($("lic-pwd") || {}).value || pwdMem;
    c().contact = (($("lic-contact") || {}).value || c().contact).trim(); K.saveCfg();
    if (!c().contact) throw new Error("Введите почту или номер телефона");
    if (!pwd) throw new Error("Введите пароль из письма — или нажмите «Прислать пароль»");
    info = ""; noAccount = false;
    try {
      const r = await post("/login", { contact: c().contact, password: pwd, device: DEVICE, deviceName: DEVICE_NAME, version: VERSION, replace });
      apply(r, true);
      seats = null; pwdMem = "";
      view = st.ok ? "ok" : "blocked";
      lastCheck = Date.now();
      // тот же контакт — для «Правок из kök»
      if (K.cfg.kok && !K.cfg.kok.contact && c().contact.includes("@")) { K.cfg.kok.contact = c().contact; K.saveCfg(); }
      finish();
      if (st.ok) K.show(K.cfg.screenAfterLogin || "home");
    } catch (e) {
      if (e.status === 409 && e.data && e.data.devices) { seats = e.data; pwdMem = pwd; view = "seats"; msg = ""; render(); return; }
      if (e.data && e.data.noAccount) noAccount = true;
      throw e;
    }
  }

  $("scr-license").addEventListener("click", (e) => {
    const t = e.target;
    if (t.id === "lic-send") { e.preventDefault(); return act(async () => {
      c().contact = $("lic-contact").value.trim(); K.saveCfg();
      if (!c().contact) throw new Error("Введите почту или номер телефона — пришлём новый пароль");
      info = ""; noAccount = false;
      try {
        const r = await post("/password", { contact: c().contact });
        info = r.via === "Telegram" ? "Новый пароль отправлен в Telegram." : "Новый пароль отправлен на почту — проверьте и папку «Спам».";
      } catch (err) { if (err.data && err.data.noAccount) noAccount = true; throw err; }
      setTimeout(() => $("lic-pwd") && $("lic-pwd").focus(), 50);
    }); }
    if (t.id === "lic-verify") return act(() => login(""));
    if (t.dataset.licRel) return act(() => login(t.dataset.licRel));
    if (t.id === "lic-back") { view = "login"; seats = null; pwdMem = ""; return render(); }
    if (t.id === "lic-recheck") { view = st.ok ? "ok" : "check"; render(); return check(false); }
    if (t.id === "lic-logout") return act(async () => {
      try { if (saved && saved.token) await post("/logout", { device: DEVICE }, saved.token); } catch (e2) {}
      saved = null; lic = null; store(); st = { ok: false, reason: "login" }; view = "login";
      finish();
    });
    if (t.closest("[data-lic-buy]")) { e.preventDefault(); return K.openURL(BUY); }
  });
  $("scr-license").addEventListener("change", (e) => {
    if (e.target.id === "lic-server") { const v = e.target.value.trim(); c().server = v && v !== DEFAULTS.server ? v : ""; K.saveCfg(); }
  });
  $("scr-license").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.target.id === "lic-pwd" || e.target.id === "lic-contact")) $("lic-verify").click();
  });
  document.addEventListener("click", (e) => { if (e.target.id === "lic-acc") { e.preventDefault(); K.show("license"); } });

  K.modules.license = { title: "Аккаунт kök Edit", cfgKey: "lic", needsTimeline: false, render, onShow: () => { if (view === "check" && lastCheck) view = st.ok ? "ok" : "blocked"; render(); } };
  // первая проверка — сразу при открытии панели
  K.licStart = () => check(true);
})();

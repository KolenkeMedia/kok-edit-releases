// kök Edit — Паузы: вырезает длинные паузы и «ээ/мм» во всех дорожках сразу, только в копии последовательности.
// Режем только там, где все отмеченные микрофоны молчат и нет ни одного нормального слова. Исходная не меняется.
(function () {
  const { $, esc, log, status, fmt, P } = K;
  const C = require(K.path.join(K.EXT, "lib", "cuts.js"));
  const DEFAULTS = { pause: "1.0", keep: "0.35", thr: "std", fill: false, list: "ээ, мм, эм, хм, енді", tracks: null };
  const THR = { safe: 6, std: 10, bold: 14 };
  const PREFIX = "kök пауза: ";
  const c = () => K.cfg.ct;
  K.cfg.ct = K.cfg.ct || {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = v;

  let plan = null; // { seqId, seqName, end, cuts, skip:Set }

  const aTracks = () => (K.scan ? K.scan.audio.filter((t) => t.clips.length) : []);
  function chosen() {
    const all = aTracks().map((t) => t.index);
    if (c().tracks && c().tracks.length) { const s = all.filter((i) => c().tracks.includes(i)); if (s.length) return s; }
    // по умолчанию — микрофоны из AutoCam, иначе все дорожки со звуком
    const mics = K.cfg.ac && K.cfg.ac.mics ? all.filter((i) => K.cfg.ac.mics[i] && K.cfg.ac.mics[i].use) : [];
    return mics.length ? mics : all;
  }
  const active = () => (plan ? plan.cuts.filter((_, i) => !plan.skip.has(i)) : []);
  const total = (list) => list.reduce((a, x) => a + (x.b - x.a), 0);

  function render() {
    K.renderSegs($("scr-cuts"), c());
    $("ct-fill").checked = !!c().fill;
    $("ct-list").value = c().list;
    $("ct-listRow").classList.toggle("off", !c().fill);
    const sel = chosen();
    $("ct-tracks").innerHTML = aTracks().length
      ? aTracks().map((t) => `<label class="chip ${sel.includes(t.index) ? "on" : ""}" data-ct-tr="${t.index}">A${t.index + 1}${K.cfg.ac && K.cfg.ac.mics && K.cfg.ac.mics[t.index] && K.cfg.ac.mics[t.index].name ? " " + esc(K.cfg.ac.mics[t.index].name) : ""}</label>`).join("")
      : `<span class="small-text">Нет дорожек со звуком</span>`;
    const stale = plan && (!K.scan || plan.seqId !== K.scan.seqId);
    if (stale) plan = null;
    $("ct-resCard").classList.toggle("hidden", !plan);
    if (plan) {
      const act = active(), np = act.filter((x) => x.kind === "pause").length, nf = act.length - np;
      $("ct-sum").innerHTML = `<div class="big">−${fmt(total(act)).replace(/\.\d$/, "")}</div>
        <div class="small-text">пауз ${np}, паразитов ${nf} · было ${fmt(plan.end).replace(/\.\d$/, "")}, станет ${fmt(plan.end - total(act)).replace(/\.\d$/, "")}</div>`;
      $("ct-list2").innerHTML = plan.cuts.slice(0, 400).map((x, i) => `<div class="li ${plan.skip.has(i) ? "off" : ""}"><input type="checkbox" data-ct-item="${i}" ${plan.skip.has(i) ? "" : "checked"}>
        <span class="tc" data-ct-go="${x.a}" style="cursor:pointer">${fmt(x.a)}</span><span class="nm">${x.kind === "pause" ? "⏸" : "✂"} ${esc(x.text)}</span><span class="tc">${(x.b - x.a).toFixed(1)} с</span></div>`).join("")
        + (plan.cuts.length > 400 ? `<div class="small-text">… и ещё ${plan.cuts.length - 400}</div>` : "");
    }
    const can = !K.busy && !!K.scan && sel.length > 0 && (c().pause !== "off" || c().fill);
    $("ct-find").disabled = !can;
    $("ct-apply").disabled = K.busy || !plan || !active().length;
    $("ct-marks").disabled = K.busy || !plan || !active().length;
    $("ct-why").textContent = !K.scan ? "Откройте последовательность" : !sel.length ? "Отметьте микрофоны" : c().pause === "off" && !c().fill ? "Включите паузы или слова-паразиты" : "";
  }

  $("scr-cuts").addEventListener("click", (e) => {
    const tr = e.target.closest("[data-ct-tr]");
    if (tr) {
      const i = +tr.dataset.ctTr, cur = chosen();
      c().tracks = cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i];
      K.saveCfg(); plan = null; render(); return;
    }
    const g = e.target.closest("[data-ct-go]");
    if (g && K.scan) K.call("ac_setPlayhead", K.scan.seqId, +g.dataset.ctGo);
  });
  $("scr-cuts").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.ctItem !== undefined) { const i = +t.dataset.ctItem; if (t.checked) plan.skip.delete(i); else plan.skip.add(i); render(); return; }
    if (t.id === "ct-fill") c().fill = t.checked;
    else if (t.id === "ct-list") c().list = t.value;
    else return;
    K.saveCfg(); render();
  });

  async function find() {
    if (K.busy || !K.scan) return;
    K.setBusy(true);
    const scan = K.scan;
    K.report = [`Паузы: «${scan.seqName}» (${fmt(scan.seqEnd)}), паузы ${c().pause}, оставить ${c().keep} с, тишина ${c().thr}, паразиты ${c().fill ? c().list : "нет"}`];
    plan = null;
    try {
      const idx = chosen();
      log("Микрофоны: " + idx.map((i) => "A" + (i + 1)).join(", "));
      const levels = await K.modules.autocam.trackLevels(idx, { noSameCheck: true });
      let act = null;
      if (levels.length > 1) act = P.labelWindows(levels, { snrDb: 8, excessDb: 6, multiDensity: 0.6, hangoverSec: 0.6, minReplySec: 0.5, multiMinSec: 1.5 }).act;
      // расшифровка нужна для паразитов; для пауз — берём, если уже есть (не режем тихое слово)
      let tr = null;
      try { tr = await K.modules.ai.transcript(!!c().fill); } catch (e) { if (c().fill) throw e; }
      if (tr) log(`Расшифровка: ${tr.words.length} слов (${tr.svc})`);
      else log("Расшифровки нет — паузы ищутся только по звуку");
      status("Ищу паузы…");
      const cuts = C.planCuts(levels, tr ? tr.words : [], {
        rate: P.RATE, seqEnd: scan.seqEnd, frame: scan.frameDur,
        minPause: c().pause === "off" ? 1e9 : +c().pause, keep: +c().keep, thrDb: THR[c().thr] || 10,
        fillers: c().fill ? C.parseList(c().list) : null, act,
      }).filter((x) => c().fill || x.kind === "pause");
      plan = { seqId: scan.seqId, seqName: scan.seqName, end: scan.seqEnd, cuts, skip: new Set() };
      const np = cuts.filter((x) => x.kind === "pause").length;
      log(`Найдено: пауз ${np}, паразитов ${cuts.length - np}, всего −${total(cuts).toFixed(1)} с`);
      if (c().fill && tr && !cuts.some((x) => x.kind === "filler")) log("Паразитов в расшифровке нет: сервис распознавания мог их не записать — тогда помогут только паузы.");
      status(cuts.length ? `Можно убрать ${fmt(total(cuts)).replace(/\.\d$/, "")}. Проверьте список и нажмите «Вырезать в копии».` : "Нечего вырезать с такими настройками.", cuts.length ? "good" : "");
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    log("Лог: " + K.saveLog("cuts"));
    K.setBusy(false);
  }

  async function marks() {
    if (K.busy || !plan) return;
    await K.call("ac_removeMarkers", plan.seqId, PREFIX);
    const list = active().map((x) => ({ t: +x.a.toFixed(3), d: +(x.b - x.a).toFixed(3), n: PREFIX + x.text, c: x.kind === "pause" ? 5 : 3 }));
    for (let i = 0; i < list.length; i += 200) await K.call("ac_markers", plan.seqId, list.slice(i, i + 200));
    status(`Маркеры «${PREFIX.trim()}» поставлены: ${list.length}. Таймлайн не менялся.`, "good");
  }

  async function apply() {
    if (K.busy || !plan) return;
    const cuts = active();
    if (!cuts.length) return;
    K.setBusy(true);
    const t0 = Date.now(), eps = Math.min(0.01, K.scan.frameDur / 3);
    K.report = [`Вырезаю ${cuts.length} мест (−${total(cuts).toFixed(1)} с) из «${plan.seqName}»`];
    let copy = null;
    try {
      const srcKey = await K.TR.keyOf(plan.seqId);
      status("Создаю копию последовательности…");
      copy = await K.call("ac_clone", plan.seqId, "— без пауз");
      if (!copy.ok) throw new Error(copy.error);
      log(`Копия: «${copy.name}»`);
      const chk = await K.call("ac_cutCheck", copy.id);
      if (!chk.ok) throw new Error(chk.error);
      if (!chk.canMove) throw new Error("Эта версия Premiere не умеет сдвигать клипы из скрипта — вырезание недоступно. Поставьте маркеры и режьте вручную.");
      const flat = [];
      cuts.forEach((x) => flat.push(x.a, x.b));
      const times = [...new Set(flat.map((t) => +t.toFixed(4)))].sort((a, b) => a - b);
      for (let i = 0; i < times.length; i += 30) {
        status(`Режу дорожки… ${Math.round((i / times.length) * 100)}%`);
        const r = await K.call("ac_cutRazor", copy.id, times.slice(i, i + 30));
        if (!r.ok) throw new Error(r.error);
      }
      status("Убираю вырезанные куски…");
      const rm = await K.call("ac_cutRemove", copy.id, flat, eps);
      if (!rm.ok) throw new Error(rm.error);
      log(`Убрано кусков клипов: ${rm.removed}`);
      // сдвиг: окнами по исходному времени, слева направо — клипы не наезжают друг на друга
      let moved = 0, failed = 0;
      const W = 120;
      for (let t = cuts[0].b - eps * 2; t < plan.end + W; t += W) {
        status(`Сдвигаю клипы… ${Math.min(99, Math.round(((t - cuts[0].b) / Math.max(1, plan.end - cuts[0].b)) * 100))}%`);
        const r = await K.call("ac_cutMove", copy.id, flat, t, t + W, eps);
        if (!r.ok) throw new Error(r.error);
        moved += r.moved; failed += r.failed;
      }
      log(`Сдвинуто клипов: ${moved}${failed ? `, не сдвинулось: ${failed}` : ""}`);
      const mk = await K.call("ac_cutMarkers", copy.id, flat, eps);
      if (mk.ok && mk.n) log(`Маркеры сдвинуты: ${mk.n} из ${mk.total}`);
      const v = await K.call("ac_cutVerify", copy.id, eps);
      const want = plan.end - total(cuts);
      if (!v.ok) throw new Error(v.error);
      log(`Длина: было ${fmt(plan.end)}, стало ${fmt(v.end)} (ожидалось ${fmt(want)})`);
      if (failed || v.nOver) throw new Error(`Проверка не прошла: ${failed ? `не сдвинулось ${failed} клипов` : ""}${failed && v.nOver ? ", " : ""}${v.nOver ? `наложения на ${v.overlaps.join(", ")}` : ""}. Копия «${copy.name}» испорчена — удалите её; исходная не тронута.`);
      await K.TR.link(srcKey, copy.id, K.TR.segsFromCuts(cuts), plan.seqName); // расшифровка копии — без нового запроса
      if (Math.abs(v.end - want) > 1) log(`Внимание: длина отличается от ожидаемой на ${(v.end - want).toFixed(1)} с — посмотрите конец таймлайна.`);
      status(`Готово за ${((Date.now() - t0) / 1000).toFixed(0)} с: «${copy.name}», короче на ${fmt(plan.end - v.end).replace(/\.\d$/, "")}.`, "good");
      plan = null;
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
      if (copy && copy.ok && !/удалите её/.test(e.message)) log(`Копия «${copy.name}» могла остаться недоделанной — удалите её. Исходная последовательность не менялась.`);
    }
    log("Лог: " + K.saveLog("cuts"));
    K.setBusy(false);
    await K.readTimeline();
    render();
  }

  $("ct-find").onclick = find;
  $("ct-apply").onclick = apply;
  $("ct-marks").onclick = marks;
  $("ct-clearMarks").onclick = async () => {
    if (!K.scan) return;
    const r = await K.call("ac_removeMarkers", K.scan.seqId, PREFIX);
    status(r.ok ? `Удалено маркеров: ${r.n}` : r.error, r.ok ? "good" : "err");
  };

  K.modules.cuts = { title: "Паузы", cfgKey: "ct", needsTimeline: true, onSeg: () => { plan = null; render(); }, onScan: render, render };
})();

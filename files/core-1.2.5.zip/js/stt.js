// kök Edit — локальное распознавание речи: whisper.cpp + модели (базовая turbo и казахская turbo).
(function () {
  const { fs, path, os } = K;
  const https = require("https");
  const GC = require(path.join(K.EXT, "lib", "ggmlconv.js"));

  const WDIR = path.join(K.EXT, "bin", "whisper");
  const CLI = path.join(WDIR, "whisper-cli.exe");
  const QUANT = path.join(WDIR, "whisper-quantize.exe");
  const MODELS = path.join(K.WORK, "models");
  try { fs.mkdirSync(MODELS, { recursive: true }); } catch (e) {}

  const BASE = { file: "ggml-large-v3-turbo-q5_0.bin", url: "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin", mb: 547 };
  const KAZ = { file: "ggml-kazakh-turbo-q5_0.bin", repo: "shyngys879/kazakh-whisper-large-v3-turbo" };

  const has = (m) => fs.existsSync(path.join(MODELS, m.file));
  K.stt = { WDIR, MODELS, BASE, KAZ, has, engineOk: () => fs.existsSync(CLI) };

  // ---------- загрузка по https (с переадресацией) ----------
  function download(url, dest, onProg, redirects) {
    return new Promise((resolve, reject) => {
      const req = https.get(url, { headers: { "User-Agent": "kok-edit" } }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          if ((redirects || 0) > 6) return reject(new Error("Слишком много переадресаций"));
          return resolve(download(new URL(res.headers.location, url).toString(), dest, onProg, (redirects || 0) + 1));
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode}: ${url}`)); }
        const total = +res.headers["content-length"] || 0;
        let got = 0;
        const part = dest + ".part";
        const out = fs.createWriteStream(part);
        res.on("data", (c) => { got += c.length; if (onProg) onProg(got, total); });
        res.pipe(out);
        out.on("finish", () => out.close(() => { try { fs.renameSync(part, dest); resolve(dest); } catch (e) { reject(e); } }));
        res.on("error", reject);
        out.on("error", reject);
      });
      req.on("error", (e) => reject(new Error("Нет связи с " + new URL(url).hostname + ": " + e.message)));
      req.setTimeout(60000, () => req.destroy(new Error("Сервер не отвечает")));
    });
  }
  const getJSON = (url) => new Promise((resolve, reject) => {
    https.get(url, { headers: { "User-Agent": "kok-edit" } }, (res) => {
      let s = "";
      res.on("data", (c) => (s += c));
      res.on("end", () => { if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}: ${url}`)); try { resolve(JSON.parse(s)); } catch (e) { reject(e); } });
    }).on("error", reject);
  });
  const mb = (b) => (b / 1048576).toFixed(0);

  // ---------- модели ----------
  async function ensureBase(status) {
    if (has(BASE)) return path.join(MODELS, BASE.file);
    status(`Скачиваю модель Whisper (${BASE.mb} МБ, один раз)…`);
    await download(BASE.url, path.join(MODELS, BASE.file), (g, t) => status(`Скачиваю модель Whisper: ${mb(g)} из ${mb(t || BASE.mb * 1048576)} МБ`));
    return path.join(MODELS, BASE.file);
  }

  async function ensureKazakh(status) {
    const out = path.join(MODELS, KAZ.file);
    if (fs.existsSync(out)) return out;
    if (!fs.existsSync(QUANT)) await K.update.ensureComponent("whisper", (m) => status("Скачиваю движок Whisper (один раз): " + m));
    if (!fs.existsSync(QUANT)) throw new Error("Не удалось скачать движок Whisper — проверьте интернет");
    const base = await ensureBase(status);
    const tmp = path.join(MODELS, "tmp_kazakh");
    fs.mkdirSync(tmp, { recursive: true });
    status("Казахская модель: список файлов…");
    const info = await getJSON(`https://huggingface.co/api/models/${KAZ.repo}`);
    const names = (info.siblings || []).map((s) => s.rfilename);
    const shards = names.filter((n) => /\.safetensors$/i.test(n));
    if (!shards.length) throw new Error("У казахской модели нет файлов .safetensors");
    const fileUrl = (n) => `https://huggingface.co/${KAZ.repo}/resolve/main/${n}`;
    await download(fileUrl("config.json"), path.join(tmp, "config.json"));
    const local = [];
    for (let i = 0; i < shards.length; i++) {
      const dst = path.join(tmp, path.basename(shards[i]));
      if (!fs.existsSync(dst)) await download(fileUrl(shards[i]), dst, (g, t) => status(`Казахская модель: скачиваю ${i + 1}/${shards.length} — ${mb(g)} из ${mb(t)} МБ (один раз)`));
      local.push(dst);
    }
    const f16 = path.join(tmp, "ggml-kazakh-f16.bin");
    status("Казахская модель: перевожу в формат whisper.cpp…");
    await K.sleep(50);
    const cfg = JSON.parse(fs.readFileSync(path.join(tmp, "config.json"), "utf8"));
    let last = 0;
    GC.convert(local, cfg, base, f16, (p) => { if (p - last > 0.02) { last = p; status(`Казахская модель: перевожу ${Math.round(p * 100)}%`); } });
    status("Казахская модель: сжимаю до q5…");
    await new Promise((resolve, reject) => {
      const p = K.spawn(QUANT, [f16, out + ".part", "q5_0"], { cwd: WDIR });
      let err = "";
      p.stderr.on("data", (d) => (err += d));
      p.stdout.on("data", (d) => (err += d));
      p.on("error", reject);
      p.on("close", (code) => (code === 0 ? resolve() : reject(new Error("whisper-quantize: " + err.slice(-400)))));
    });
    fs.renameSync(out + ".part", out);
    try { for (const f of fs.readdirSync(tmp)) fs.unlinkSync(path.join(tmp, f)); fs.rmdirSync(tmp); } catch (e) {}
    return out;
  }

  // ---------- распознавание ----------
  // audio — любой звук/видео; lang: "kk" | "ru" | "auto"; prompt — имена и термины
  // → [{w, s, e}] слова с секундами
  async function transcribe(audio, lang, prompt, status) {
    if (!fs.existsSync(CLI)) await K.update.ensureComponent("whisper", (m) => status("Скачиваю движок Whisper (один раз): " + m));
    if (!fs.existsSync(CLI)) throw new Error("Не удалось скачать движок Whisper — проверьте интернет");
    const model = lang === "kk" ? await ensureKazakh(status) : await ensureBase(status);
    const wav = path.join(K.CACHE, `stt_${Date.now()}.wav`);
    await K.ffmpeg(["-y", "-v", "error", "-i", audio, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", wav]);
    const outBase = wav.replace(/\.wav$/, "");
    const args = ["-m", model, "-f", wav, "-l", lang === "auto" ? "auto" : lang, "-ml", "1", "-sow", "-ojf", "-of", outBase, "-np", "-pp", "-sns",
      "-dtw", "large.v3.turbo", "-t", String(Math.max(2, Math.min(16, os.cpus().length - 1))), "-bs", "5"];
    if (prompt) args.push("--prompt", prompt);
    await new Promise((resolve, reject) => {
      const p = K.spawn(CLI, args, { cwd: WDIR });
      let err = "";
      p.stderr.on("data", (d) => {
        err += d;
        if (err.length > 100000) err = err.slice(-50000);
        const m = String(d).match(/progress =\s*(\d+)%/g);
        if (m) status(`Распознаю речь… ${m[m.length - 1].match(/\d+/)[0]}%`);
      });
      p.on("error", (e) => reject(new Error("whisper-cli не запустился: " + e.message)));
      p.on("close", (code) => (code === 0 ? resolve() : reject(new Error("whisper-cli: " + err.slice(-400)))));
    });
    const js = JSON.parse(fs.readFileSync(outBase + ".json", "utf8"));
    try { fs.unlinkSync(wav); fs.unlinkSync(outBase + ".json"); } catch (e) {}
    return wordsFromJson(js);
  }

  // слова с точным временем: DTW-время первого текстового токена слова (если есть), иначе время сегмента
  function wordsFromJson(js) {
    const words = [];
    for (const seg of js.transcription || []) {
      const text = String(seg.text || "").trim();
      if (!text || /^\[.*\]$/.test(text)) continue;
      let s = seg.offsets.from / 1000, e = seg.offsets.to / 1000, dtw = [];
      for (const t of seg.tokens || []) {
        if (/^\[_|^<\|/.test(t.text || "")) continue;
        if (typeof t.t_dtw === "number" && t.t_dtw >= 0) dtw.push(t.t_dtw / 100);
      }
      if (dtw.length) { s = dtw[0]; e = Math.max(s + 0.08, dtw[dtw.length - 1] + 0.12); }
      words.push({ w: text, s, e });
    }
    // конец слова не позже начала следующего, и не дольше 1,2 с
    for (let i = 0; i < words.length; i++) {
      const nx = words[i + 1];
      if (nx && words[i].e > nx.s) words[i].e = Math.max(words[i].s + 0.05, nx.s);
      if (words[i].e - words[i].s > 1.2) words[i].e = words[i].s + 1.2;
    }
    return words;
  }
  K.stt.wordsFromJson = wordsFromJson;

  K.stt.ensureBase = ensureBase;
  K.stt.ensureKazakh = ensureKazakh;
  K.stt.transcribe = transcribe;
})();

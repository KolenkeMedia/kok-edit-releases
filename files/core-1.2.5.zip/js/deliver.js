// kök Edit — Сдача: техническая проверка готового файла перед отправкой клиенту или на площадку.
// Только читает файл — ничего не меняет.
(function () {
  const { $, esc, log, status } = K;
  const D = require(K.path.join(K.EXT, "lib", "delivery.js"));
  const DEFAULTS = { preset: "youtube", cmp: true, depth: "full", file: "" };
  const c = () => K.cfg.dl;
  K.cfg.dl = K.cfg.dl || {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = v;
  const DIR = K.path.join(K.OUT, "delivery");
  const ICON = { ok: "✓", warn: "!", err: "✕" };
  let res = null; // { file, items, text }

  function render() {
    K.renderSegs($("scr-deliver"), c());
    $("dl-cmp").checked = !!c().cmp;
    const ok = c().file && K.fs.existsSync(c().file);
    $("dl-file").textContent = ok ? K.path.basename(c().file) : "не выбран — нажмите «Выбрать» или перетащите файл сюда";
    $("dl-file").title = c().file || "";
    $("dl-run").disabled = K.busy || !ok;
    $("dl-seq").textContent = K.scan ? `«${K.scan.seqName}»` : "нет открытой";
    $("dl-res").classList.toggle("hidden", !res);
    if (res) {
      const nErr = res.items.filter((x) => x.level === "err").length, nWarn = res.items.filter((x) => x.level === "warn").length;
      $("dl-verdict").innerHTML = nErr ? `<span class="err">Не отправлять: ${nErr} ${nErr === 1 ? "ошибка" : nErr < 5 ? "ошибки" : "ошибок"}</span>`
        : nWarn ? `<span class="warn" style="margin:0">Посмотрите замечания: ${nWarn}</span>` : `<span class="good">Можно отправлять</span>`;
      $("dl-list").innerHTML = res.items.map((x) => `<div class="li dl-${x.level}" ${x.t !== undefined && res.cmp ? `data-dl-go="${x.t}" style="cursor:pointer" title="Показать в Premiere"` : ""}>
        <span class="dl-ic">${ICON[x.level]}</span>${x.t !== undefined ? `<span class="tc">${D.tc(x.t)}</span>` : ""}
        <span class="nm" style="white-space:normal">${esc(x.title)}${x.detail ? `<br><span class="small-text">${esc(x.detail)}</span>` : ""}</span></div>`).join("");
    }
  }
  $("scr-deliver").addEventListener("change", (e) => { if (e.target.id === "dl-cmp") { c().cmp = e.target.checked; K.saveCfg(); render(); } });
  $("scr-deliver").addEventListener("click", (e) => {
    const g = e.target.closest("[data-dl-go]");
    if (g && K.scan) K.call("ac_setPlayhead", K.scan.seqId, +g.dataset.dlGo);
  });
  $("dl-pick").onclick = () => {
    const f = K.pickFile("Готовый файл для проверки", ["mp4", "mov", "mxf", "m4v", "mkv"]);
    if (f) setFile(f);
  };
  function setFile(f) { c().file = f; res = null; K.saveCfg(); render(); }
  // перетаскивание файла на панель
  const sec = $("scr-deliver");
  sec.addEventListener("dragover", (e) => { e.preventDefault(); sec.classList.add("drop"); });
  sec.addEventListener("dragleave", () => sec.classList.remove("drop"));
  sec.addEventListener("drop", (e) => {
    e.preventDefault(); sec.classList.remove("drop");
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f && f.path) setFile(f.path);
  });

  async function run() {
    const file = c().file;
    if (K.busy || !file) return;
    K.setBusy(true);
    res = null;
    K.report = [`Сдача: ${file}, площадка ${D.PRESETS[c().preset].name}`];
    try {
      if (c().cmp) await K.readTimeline();
      const infoText = await new Promise((resolve) => {
        const p = K.spawn(K.FFMPEG, ["-hide_banner", "-i", file]);
        let t = ""; p.stderr.on("data", (d) => (t += d)); p.on("close", () => resolve(t)); p.on("error", () => resolve(""));
      });
      const info = D.parseInfo(infoText);
      if (!info.dur && !info.video) throw new Error("Не удалось прочитать файл — это видео?");
      log(`Файл: ${info.format}, ${D.tc(info.dur || 0)}, ${info.video ? `${info.video.codec} ${info.video.w}×${info.video.h} ${info.video.fps} к/с` : "без видео"}, ${info.audio ? `${info.audio.codec} ${info.audio.layout}` : "без звука"}`);
      // один проход ffmpeg: громкость, тишина, чёрные и застывшие кадры (картинка уменьшается для скорости)
      const parts = [], maps = [];
      if (info.video && c().depth === "full") { parts.push("[0:v:0]scale=320:-2,blackdetect=d=0.5:pix_th=0.10,freezedetect=n=-60dB:d=2[vo]"); maps.push("-map", "[vo]"); }
      if (info.audio) { parts.push("[0:a:0]ebur128=peak=true:framelog=quiet,silencedetect=n=-50dB:d=2[ao]"); maps.push("-map", "[ao]"); }
      let an = null;
      if (parts.length) {
        an = D.newAnalysis();
        let buf = "";
        const t0 = Date.now();
        await K.ffmpeg(["-i", file, "-filter_complex", parts.join(";"), ...maps, "-f", "null", "-"], (chunk) => {
          buf += chunk;
          const lines = buf.split(/\r\n|\n|\r/);
          buf = lines.pop();
          for (const l of lines) D.feedAnalysis(an, l);
          const m = String(chunk).match(/time=(\d+):(\d+):([\d.]+)/);
          if (m && info.dur) status(`Смотрю и слушаю файл… ${Math.min(99, Math.round(((+m[1] * 3600 + +m[2] * 60 + +m[3]) / info.dur) * 100))}%`);
        });
        if (buf) D.feedAnalysis(an, buf);
        D.finishAnalysis(an, info.dur);
        log(`Анализ: ${((Date.now() - t0) / 1000).toFixed(0)} с`);
      }
      const s = K.scan;
      const seq = c().cmp && s ? { end: s.seqEnd, fps: 1 / s.frameDur, w: s.width, h: s.height } : null;
      const items = D.evaluate(info, an, c().preset, seq);
      const text = [`Проверка файла ${K.path.basename(file)} — ${D.PRESETS[c().preset].name}`, `Дата: ${new Date().toLocaleString()}`, seq ? `Сравнение с «${s.seqName}»` : "", "",
        ...items.map((x) => `${ICON[x.level]} ${x.t !== undefined ? D.tc(x.t) + " " : ""}${x.title}${x.detail ? " — " + x.detail : ""}`)].filter((x, i) => x || i > 2).join("\n");
      res = { file, items, text, cmp: !!seq };
      try { K.fs.mkdirSync(DIR, { recursive: true }); K.fs.writeFileSync(K.path.join(DIR, `${K.safeName(K.path.parse(file).name)}_проверка.txt`), text, "utf8"); } catch (e) {}
      items.forEach((x) => log(`  ${ICON[x.level]} ${x.t !== undefined ? D.tc(x.t) + " " : ""}${x.title}`));
      const nErr = items.filter((x) => x.level === "err").length;
      status(nErr ? "Есть ошибки — смотрите список" : "Проверка готова", nErr ? "err" : "good");
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    log("Лог: " + K.saveLog("delivery"));
    K.setBusy(false);
  }
  $("dl-run").onclick = run;
  $("dl-copy").onclick = () => {
    if (!res) return;
    const t = document.createElement("textarea");
    t.value = res.text; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove();
    status("Отчёт скопирован — можно вставить в чат с клиентом или в kök", "good");
  };

  K.modules.deliver = {
    title: "Сдача", cfgKey: "dl", needsTimeline: false,
    onShow() { if (!K.busy) K.readTimeline().then(render, render); },
    render,
  };
})();

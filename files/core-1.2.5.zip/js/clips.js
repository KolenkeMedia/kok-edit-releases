// kök Edit — Нарезки: таймкоды → вертикальные последовательности (одна общая или отдельные).
(function () {
  const { $, esc, log, status, fmt } = K;
  const DEFAULTS = { aspect: "9x16", reframe: "center", layout: "one", source: "" };
  const c = () => K.cfg.cl;
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = v;
  const SIZES = { "9x16": [1080, 1920, 9, 16], "4x5": [1080, 1350, 4, 5], "1x1": [1080, 1080, 1, 1] };
  const BIN = "kök Edit/Нарезки", BIN_SRC = "kök Edit/Нарезки/исходники";
  const GAP = 5;

  let seqs = [], parsed = { items: [], bad: [] }, skip = new Set();
  const src = () => seqs.find((s) => s.id === $("cl-source").value);

  async function loadSequences() {
    const r = await K.call("ac_listSequences");
    if (!r.ok) { seqs = []; $("cl-source").innerHTML = `<option>нет открытого проекта</option>`; render(); return; }
    seqs = r.list;
    const want = seqs.some((s) => s.id === c().source) ? c().source : r.active;
    const sorted = seqs.slice().sort((a, b) => (/AutoCam/.test(b.name) - /AutoCam/.test(a.name)));
    $("cl-source").innerHTML = sorted.map((s) => `<option value="${esc(s.id)}">${esc(s.name)}${s.end ? " · " + fmt(s.end) : ""}</option>`).join("");
    if (want) $("cl-source").value = want;
    parse();
  }

  function parse() {
    const s = src();
    parsed = K.TC.parseTimecodes($("cl-text").value, s ? s.fps : 25);
    const total = parsed.items.reduce((a, x) => a + x.dur, 0);
    let html = parsed.items.map((it, i) => {
      const out = s && s.end && it.parts.some((p) => p.end > s.end + 0.5);
      const tcs = it.parts.map((p) => `${K.TC.secToTc(p.start)}–${K.TC.secToTc(p.end)}`).join(" + ");
      return `<div class="li ${skip.has(i) ? "off" : ""}"><input type="checkbox" data-cl-item="${i}" ${skip.has(i) ? "" : "checked"}>
        <span class="tc" ${it.parts.length > 1 ? `title="${it.parts.length} куска встык"` : ""}>${tcs}</span>
        <span class="nm" title="${esc(it.title)}">${esc(it.title || "Нарезка " + (i + 1))}</span>
        <span class="tc ${out ? "err" : ""}" ${out ? 'title="Дальше конца последовательности"' : ""}>${fmt(it.dur).replace(/\.\d$/, "")}</span></div>`;
    }).join("");
    if (parsed.bad.length) html += parsed.bad.map((b) => `<div class="li warn" title="Не нашёл начало и конец"><span class="nm">⚠ ${esc(b)}</span></div>`).join("");
    if (parsed.items.length) html += `<div class="small-text" style="margin-top:4px">${parsed.items.length - skip.size} нарезок · ${fmt(total).replace(/\.\d$/, "")} всего</div>`;
    $("cl-parsed").innerHTML = html;
    render();
  }

  function render() {
    K.renderSegs($("scr-clips"), c());
    const s = src();
    const n = parsed.items.length - skip.size;
    const outside = s && s.end ? parsed.items.filter((it, i) => !skip.has(i) && it.parts.some((p) => p.start >= s.end)).length : 0;
    $("cl-run").textContent = n ? `Нарезать (${n})` : "Нарезать";
    $("cl-run").disabled = K.busy || !s || n <= 0;
    $("cl-why").textContent = !s ? "Нет последовательности" : outside ? `${outside} таймкод(а) дальше конца «${s.name}» — проверьте источник` : "";
  }

  $("cl-text").addEventListener("input", () => { skip.clear(); c().text = $("cl-text").value; K.saveCfg(); parse(); });
  $("cl-source").addEventListener("change", () => { c().source = $("cl-source").value; K.saveCfg(); parse(); });
  $("scr-clips").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.clItem !== undefined) { const i = +t.dataset.clItem; if (t.checked) skip.delete(i); else skip.add(i); parse(); }
  });

  // пустая вертикальная последовательность через XML (так Premiere точно ставит размер кадра)
  function emptySeqXML(name, w, h, fps) {
    const near = (x) => Math.abs(fps - x) < 0.02;
    const rate = near(23.976) ? [24, "TRUE"] : near(29.97) ? [30, "TRUE"] : near(59.94) ? [60, "TRUE"] : [Math.round(fps), "FALSE"];
    const R = `<rate><timebase>${rate[0]}</timebase><ntsc>${rate[1]}</ntsc></rate>`;
    const xe = (x) => String(x).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="v1"><name>${xe(name)}</name><duration>0</duration>${R}` +
      `<media><video><format><samplecharacteristics>${R}<width>${w}</width><height>${h}</height><pixelaspectratio>square</pixelaspectratio></samplecharacteristics></format><track></track></video>` +
      `<audio><track></track><track></track></audio></media></sequence></xmeml>`;
  }
  async function newVertical(name, w, h, fps, bin) {
    const dir = K.path.join(K.OUT, "clips");
    K.fs.mkdirSync(dir, { recursive: true });
    const xml = K.path.join(dir, K.safeName(name) + "_" + Date.now() + ".xml");
    K.fs.writeFileSync(xml, emptySeqXML(name, w, h, fps), "utf8");
    const r = await K.call("ac_importXML", xml, bin || BIN);
    if (!r.ok) throw new Error("Не создалась последовательность: " + r.error);
    return r.id;
  }

  async function run() {
    const s = src();
    if (!s || K.busy) return;
    K.setBusy(true);
    K.report = [`Нарезки из «${s.name}» (${s.w}×${s.h}, ${s.fps.toFixed(2)} к/с)`];
    const [W, H, num, den] = SIZES[c().aspect];
    const aspect = c().aspect.replace("x", "×");
    const items = parsed.items.map((it, i) => Object.assign({ i }, it)).filter((it) => !skip.has(it.i) && (!s.end || it.parts.every((p) => p.start < s.end)));
    let ok = 0, vId = null, cursor = 0;
    const srcKey = await K.TR.keyOf(s.id), segs = [];
    try {
      if (c().layout === "one") {
        vId = await newVertical(`Нарезки ${aspect} — ${s.name}`, W, H, s.fps);
        log(`Общая последовательность: «Нарезки ${aspect} — ${s.name}»`);
      }
      for (let n = 0; n < items.length; n++) {
        const it = items[n];
        const title = `${String(it.i + 1).padStart(2, "0")}. ${it.title || "Нарезка"}`;
        try {
          // нарезка может состоять из нескольких кусков — они встают встык в указанном порядке
          const target = vId || (await newVertical(`${title} ${aspect}`, W, H, s.fps));
          const start0 = vId ? cursor : 0, mine = [], joins = [];
          let t = start0;
          for (let k = 0; k < it.parts.length; k++) {
            const p = it.parts[k], multi = it.parts.length > 1, ptitle = multi ? `${title} — кусок ${k + 1}` : title;
            status(`${n + 1}/${items.length}: «${title}»${multi ? ` — кусок ${k + 1}/${it.parts.length}` : ""} — вырезаю…`);
            let r = await K.call("ac_subsequence", s.id, p.start, Math.min(p.end, s.end || p.end), ptitle + " (исходник)");
            if (!r.ok) throw new Error(r.error);
            let nestId = r.id;
            if (c().reframe === "auto") {
              status(`${n + 1}/${items.length}: Auto Reframe… (Premiere анализирует кадр)`);
              r = await K.call("ac_autoReframe", nestId, num, den, ptitle + " (reframe)");
              if (!r.ok) throw new Error("Auto Reframe: " + r.error);
              nestId = r.id;
            }
            await K.call("ac_moveSeqToBin", nestId, BIN_SRC);
            r = await K.call("ac_placeNest", target, nestId, t, W, H, k === 0 ? title : "");
            if (!r.ok) throw new Error(r.error);
            // расшифровка нарезки = куски расшифровки исходника, без нового запроса
            mine.push([p.start, p.start + r.dur, t]);
            if (k > 0) joins.push({ t: +t.toFixed(3), d: 0, n: `склейка ${k}/${it.parts.length - 1} — ${title}`, c: 3 });
            t += r.dur;
          }
          if (joins.length) await K.call("ac_markers", target, joins);
          segs.push(...mine);
          if (!vId) await K.TR.link(srcKey, target, mine, s.name);
          const dur = t - start0;
          if (vId) cursor = t + GAP;
          log(`  ${title}: ${fmt(dur).replace(/\.\d$/, "")}${it.parts.length > 1 ? `, кусков ${it.parts.length}` : ""}${vId ? ` (с ${fmt(start0).replace(/\.\d$/, "")})` : ""}`);
          ok++;
        } catch (e) {
          log(`  ✗ ${title}: ${e.message}`);
        }
      }
      if (vId) { await K.TR.link(srcKey, vId, segs, s.name); await K.call("ac_activate_json", vId); }
      status(`Готово: ${ok} из ${items.length}. ${vId ? "Все нарезки — на одном таймлайне, с маркерами." : `Последовательности — в папке «${BIN}».`} Субтитры — в разделе «Субтитры».`, ok === items.length ? "good" : "err");
    } catch (e) {
      status(e.message, "err");
      log("ОШИБКА: " + e.message);
    }
    log("Лог: " + K.saveLog("clips"));
    K.setBusy(false);
  }
  $("cl-run").onclick = run;
  if (c().text) $("cl-text").value = c().text;

  // для раздела AI: открыть «Нарезки» с готовыми таймкодами
  function openWith(seqId, text) {
    c().source = seqId; c().text = text; K.saveCfg();
    $("cl-text").value = text; skip.clear();
  }
  K.modules.clips = { title: "Нарезки", cfgKey: "cl", needsTimeline: false, onShow: loadSequences, onScan: loadSequences, render, newSeq: newVertical, openWith };
})();

// kök Edit — одна расшифровка на всё: AI, субтитры, паузы, нарезки берут один и тот же текст.
// Расшифровка хранится по «отпечатку» звука последовательности. Копии, которые делает панель
// (AutoCam, Звук, без пауз, нарезки, тизер), запоминают, откуда они взяты, — их текст получается сдвигом слов, без нового запроса.
(function () {
  const M = require(K.path.join(K.EXT, "lib", "trmap.js"));
  const DIR = K.path.join(K.OUT, "ai");
  const LINKS = K.path.join(DIR, "links.json");
  try { K.fs.mkdirSync(DIR, { recursive: true }); } catch (e) {}
  let links = {};
  try { links = JSON.parse(K.fs.readFileSync(LINKS, "utf8")); } catch (e) {}

  const fileOf = (key) => K.path.join(DIR, `tr_${key}.json`);
  async function keyOf(seqId) {
    const r = await K.call("ac_audioKey", seqId);
    if (!r.ok || !r.key) return null;
    return K.hash(r.key).slice(0, 16);
  }
  function load(key, depth) {
    try { return Object.assign(JSON.parse(K.fs.readFileSync(fileOf(key), "utf8")), { how: "готовая" }); } catch (e) {}
    const l = links[key];
    if (!l || (depth || 0) > 8) return null;
    const p = load(l.parent, (depth || 0) + 1);
    return p ? Object.assign(M.mapTr(p, l.segs), { how: `перенесена из «${l.from || "исходной"}»` }) : null;
  }

  // старые расшифровки 1.0–1.1 (по id последовательности) — подхватываем один раз
  async function legacy(seqId, key) {
    if (!K.scan || K.scan.seqId !== seqId) return null;
    const sig = await K.call("ac_audioSig", seqId);
    const f = K.path.join(DIR, `${K.safeName(K.scan.seqName)}_${K.hash(seqId, sig.ok ? sig.sig : "", K.scan.seqEnd.toFixed(1)).slice(0, 10)}.json`);
    try {
      const tr = JSON.parse(K.fs.readFileSync(f, "utf8"));
      delete tr.file;
      K.fs.writeFileSync(fileOf(key), JSON.stringify(tr));
      return Object.assign(tr, { how: "готовая" });
    } catch (e) { return null; }
  }

  K.TR = {
    keyOf,
    // расшифровка для последовательности или null
    async find(seqId) {
      const key = await keyOf(seqId);
      if (!key) return null;
      const tr = load(key) || (await legacy(seqId, key));
      if (tr) tr.key = key;
      return tr;
    },
    async save(seqId, tr, seqName) {
      const key = await keyOf(seqId);
      if (!key) return null;
      const data = { words: Array.from(tr.words), events: tr.events || [], svc: tr.svc, lang: tr.lang, date: tr.date || new Date().toISOString(), seqName };
      K.fs.writeFileSync(fileOf(key), JSON.stringify(data));
      return Object.assign(data, { key, file: fileOf(key), how: "новая" });
    },
    // производная последовательность: parentKey снят ДО изменений; segs — куда легли куски исходника
    async link(parentKey, childSeqId, segs, fromName) {
      if (!parentKey) return;
      const key = await keyOf(childSeqId);
      if (!key || key === parentKey) return;
      links[key] = { parent: parentKey, segs: segs || M.IDENT, from: fromName || "", date: new Date().toISOString() };
      try { K.fs.writeFileSync(LINKS, JSON.stringify(links)); } catch (e) {}
    },
    IDENT: M.IDENT,
    segsFromCuts: M.segsFromCuts,
  };
})();

// kök Edit — Звук: обработка микрофонных дорожек.
// Громкость считается только по речи самого спикера (знаем из AutoCam), усиление постоянное,
// паузы глушатся огибающей — чтобы не поднимать шум и голос соседа в чужом микрофоне.
(function () {
  const { $, esc, log, status, P } = K;
  const DEFAULTS = { nr: "soft", voice: "on", target: "-14", gate: "-15", copy: true, sel: {} };
  const c = () => K.cfg.au;
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = JSON.parse(JSON.stringify(v));
  const BIN = "kök Edit/Звук";
  const ENV_RATE = 100;

  const usedA = () => (K.scan ? K.scan.audio.filter((t) => t.clips.length) : []);
  const isSel = (i) => (c().sel[i] !== undefined ? c().sel[i] : !!(K.cfg.ac.mics && K.cfg.ac.mics[i] && K.cfg.ac.mics[i].use));
  const name = (i) => (K.cfg.ac.mics && K.cfg.ac.mics[i] && K.cfg.ac.mics[i].name) || "";

  function render() {
    const tr = usedA();
    $("au-tracks").innerHTML = !K.scan ? `<div class="small-text">Откройте последовательность.</div>` : !tr.length ? `<div class="small-text">На таймлайне нет звука.</div>` :
      tr.map((t) => `<div class="row ${isSel(t.index) ? "" : "off"}"><input type="checkbox" data-au="${t.index}" ${isSel(t.index) ? "checked" : ""}>
        <div class="tag">A${t.index + 1}</div><div class="grow">${esc(name(t.index) || t.clips[0].name)}</div></div>`).join("");
    K.renderSegs($("scr-audio"), c());
    $("au-copy").checked = !!c().copy;
    const n = tr.filter((t) => isSel(t.index)).length;
    $("au-run").textContent = n ? `Обработать звук (${n})` : "Обработать звук";
    $("au-run").disabled = K.busy || !n || (c().nr === "off" && c().voice === "off" && c().target === "off" && c().gate === "off");
  }
  $("scr-audio").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.au !== undefined) c().sel[t.dataset.au] = t.checked;
    else if (t.id === "au-copy") c().copy = t.checked;
    else return;
    K.saveCfg(); render();
  });

  function chain() {
    const f = [];
    if (c().voice === "on") f.push("highpass=f=80");
    if (c().nr === "soft") f.push("afftdn=nr=10:nf=-45:tn=1");
    if (c().nr === "strong") f.push("afftdn=nr=20:nf=-40:tn=1");
    if (c().voice === "on") f.push("acompressor=threshold=-22dB:ratio=3:attack=8:release=120:makeup=1");
    return f;
  }
  const timeOf = (s) => { const m = s.match(/time=(\d+):(\d+):([\d.]+)/g); if (!m) return null; const x = m[m.length - 1].match(/(\d+):(\d+):([\d.]+)/); return +x[1] * 3600 + +x[2] * 60 + +x[3]; };

  // огибающая из ключей [[сек, дБ], ...] → файл f32 (100 значений в секунду), линейно между ключами
  function writeEnvelope(keys, dur, file) {
    const n = Math.ceil(dur * ENV_RATE) + ENV_RATE;
    const env = new Float32Array(n);
    let k = 0;
    for (let i = 0; i < n; i++) {
      const t = i / ENV_RATE;
      while (k < keys.length - 1 && keys[k + 1][0] <= t) k++;
      const a = keys[k], b = keys[k + 1];
      let db = a[1];
      if (b && t > a[0]) db = a[1] + (b[1] - a[1]) * Math.min(1, (t - a[0]) / Math.max(1e-6, b[0] - a[0]));
      env[i] = db <= -99 ? 0 : Math.pow(10, db / 20);
    }
    K.fs.writeFileSync(file, Buffer.from(env.buffer));
  }
  const graph = (pre, post) =>
    `[0:a]${[...pre, "aformat=sample_rates=48000:channel_layouts=stereo"].join(",")}[a];[1:a]aresample=48000,aformat=sample_rates=48000:channel_layouts=stereo[m];[a][m]amultiply${post ? "," + post : ""}[o]`;

  async function processTrack(input, output, label, dur, act) {
    const base = chain();
    const prog = (stage) => (s) => { const t = timeOf(s); if (t !== null) status(`${label}: ${stage} ${Math.min(99, Math.round(t / dur * 100))}%`); };
    const envIn = (f) => ["-f", "f32le", "-ar", String(ENV_RATE), "-ac", "1", "-i", f];
    const mask = output + ".mask.f32", gate = output + ".gate.f32";
    // 1) громкость только там, где говорит сам спикер
    let gainDb = 0, speechI = null;
    if (c().target !== "off") {
      writeEnvelope(P.gateKeys(act, { closedDb: -100, end: dur }), dur, mask);
      const err = await K.ffmpeg(["-y", "-v", "info", "-i", input, ...envIn(mask), "-filter_complex", graph(base, "ebur128=framelog=quiet"), "-map", "[o]", "-f", "null", "-"], prog("замер речи"));
      const m = err.match(/I:\s+(-?[\d.]+) LUFS(?![\s\S]*I:\s+-?[\d.]+ LUFS)/);
      speechI = m ? parseFloat(m[1]) : null;
      if (speechI !== null && isFinite(speechI) && speechI > -70) gainDb = Math.max(-12, Math.min(15, (+c().target - 2) - speechI));
    }
    // 2) постоянное усиление + глушение пауз + ограничитель пиков
    const closedDb = c().gate === "full" ? -100 : c().gate === "off" ? 0 : -15;
    writeEnvelope(c().gate === "off" ? [[0, 0]] : P.gateKeys(act, { closedDb, end: dur }), dur, gate);
    const pre = [...base, `volume=${gainDb.toFixed(2)}dB`];
    await K.ffmpeg(["-y", "-v", "info", "-i", input, ...envIn(gate), "-filter_complex", graph(pre, "alimiter=limit=0.84:level=disabled"), "-map", "[o]", "-ar", "48000", "-c:a", "pcm_s24le", output], prog("обработка"));
    for (const f of [mask, gate]) { try { K.fs.unlinkSync(f); } catch (e) {} }
    return { speechI, gainDb };
  }

  async function run() {
    if (!K.scan || K.busy) return;
    K.setBusy(true);
    const scan = K.scan;
    const tracks = usedA().filter((t) => isSel(t.index));
    K.report = [`Звук: «${scan.seqName}», дорожек ${tracks.length}; шумодав ${c().nr}, голос ${c().voice}, громкость ${c().target}, паузы ${c().gate}`];
    const dir = K.path.join(K.OUT, "audio", K.safeName(scan.seqName) + "_" + new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-"));
    K.fs.mkdirSync(dir, { recursive: true });
    try {
      // кто когда говорит — тем же анализом, что AutoCam (звук берётся из кэша, если уже был)
      const idx = tracks.map((t) => t.index);
      const levels = await K.modules.autocam.trackLevels(idx);
      const lw = P.labelWindows(levels, { snrDb: 8, excessDb: 6, multiDensity: 0.6, hangoverSec: 0.6, minReplySec: 0.5, multiMinSec: 1.5 });
      let seqId = scan.seqId;
      const srcKey = await K.TR.keyOf(seqId);
      if (c().copy) {
        const cl = await K.call("ac_clone", seqId, "kök Звук");
        if (!cl.ok) throw new Error(cl.error);
        seqId = cl.id;
        log(`Копия: «${cl.name}»`);
      }
      const placed = [];
      for (let k = 0; k < tracks.length; k++) {
        const t = tracks[k], label = `A${t.index + 1}${name(t.index) ? " " + name(t.index) : ""}`;
        const raw = K.path.join(K.CACHE, `au_${Date.now()}.wav`);
        status(`${label} (${k + 1}/${tracks.length}): Premiere выгружает звук… Premiere может не отвечать.`);
        await K.exportWav(seqId, t.index, raw);
        const out = K.path.join(dir, `A${t.index + 1}_${K.safeName(name(t.index) || "дорожка")}.wav`);
        const r = await processTrack(raw, out, label, scan.seqEnd || 1, lw.act[k]);
        try { K.fs.unlinkSync(raw); } catch (e) {}
        log(`  ${label}: речь ${r.speechI !== null ? r.speechI.toFixed(1) + " LUFS" : "не измерена"}, усиление ${r.gainDb >= 0 ? "+" : ""}${r.gainDb.toFixed(1)} дБ`);
        placed.push({ path: out, from: t.index });
      }
      status("Кладу обработанный звук на таймлайн…");
      const r = await K.call("ac_placeAudio", seqId, placed, BIN);
      if (!r.ok) throw new Error(r.error + ` — файлы лежат в ${dir}`);
      await K.TR.link(srcKey, seqId, K.TR.IDENT, scan.seqName);
      log(`Обработанный звук на дорожках ${r.tracks.map((x) => "A" + (x + 1)).join(", ")}; исходные заглушены (M).`);
      status(c().copy ? "Готово — в копии «kök Звук». Исходные дорожки заглушены, не удалены." : "Готово. Исходные дорожки заглушены, не удалены.", "good");
      await K.readTimeline();
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    log("Лог: " + K.saveLog("audio"));
    K.setBusy(false);
  }
  $("au-run").onclick = run;

  K.modules.audio = { title: "Звук", cfgKey: "au", needsTimeline: true, onScan: render, render };
})();

// kök Edit — Расшифровка и AI: полный текст подкаста → моменты для нарезок, тизер, главы/заголовки/пост для YouTube.
(function () {
  const { $, esc, log, status, fmt } = K;
  const A = require(K.path.join(K.EXT, "lib", "ai.js"));
  const DEFAULTS = { key: "", model: "", count: "8", len: "30-90", teaser: "45", multi: "yes" };
  const c = () => K.cfg.ai;
  K.cfg.ai = K.cfg.ai || {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = v;
  const MODEL = "claude-haiku-5-5";
  const DIR = K.path.join(K.OUT, "ai");
  try { K.fs.mkdirSync(DIR, { recursive: true }); } catch (e) {}

  let tr = null;      // { words, events, svc, lang, date, file }
  let result = null;  // { kind: 'moments'|'teaser'|'youtube', data, skip:Set }

  // ---------- расшифровка: общая для AI, субтитров и пауз (см. transcript.js) ----------
  async function loadTr() {
    tr = null;
    if (!K.scan) return;
    try { tr = await K.TR.find(K.scan.seqId); } catch (e) {}
  }
  async function transcribeAll() {
    const scan = K.scan;
    const wav = K.path.join(K.CACHE, `ai_${Date.now()}.wav`);
    status("Premiere выгружает звук последовательности… Premiere может не отвечать.");
    await K.exportWav(scan.seqId, -1, wav);
    const words = await K.modules.subs.transcribe(wav, { events: true });
    try { K.fs.unlinkSync(wav); } catch (e) {}
    if (!words.length) throw new Error("Речь не распознана");
    tr = await K.TR.save(scan.seqId, { words, events: words.events || [], svc: K.modules.subs.svcName(), lang: K.cfg.sb.lang }, scan.seqName);
    if (!tr) throw new Error("Не удалось сохранить расшифровку");
    // рядом — обычный текст, удобно читать и править
    const txt = K.path.join(DIR, `${K.safeName(scan.seqName)}_${tr.key.slice(0, 6)}.txt`);
    K.fs.writeFileSync(txt, A.transcriptText(A.phrases(tr.words, tr.events)), "utf8");
    log(`Расшифровка: ${tr.words.length} слов, событий ${tr.events.length} (${tr.svc}). Текст: ${txt}`);
  }

  // ---------- Claude ----------
  async function ask(prompt) {
    if (!K.lic.can("ai")) throw new Error(K.noFeature("ai"));
    const model = c().model || MODEL;
    status(`Claude читает расшифровку (${model})…`);
    const r = await K.postJSON("https://api.anthropic.com/v1/messages",
      { "x-api-key": c().key, "anthropic-version": "2023-06-01" },
      { model, max_tokens: 8000, system: A.SYSTEM, messages: [{ role: "user", content: prompt }] });
    const text = (r.content || []).map((x) => x.text || "").join("");
    if (r.usage) log(`  Claude: вход ${r.usage.input_tokens} токенов, ответ ${r.usage.output_tokens}`);
    return A.parseJSON(text);
  }

  // ---------- отрисовка ----------
  const tcd = (s) => A.tcFull(s) + "." + Math.floor((s % 1) * 10);
  function render() {
    K.renderSegs($("scr-ai"), c());
    $("ai-key").value = c().key;
    $("ai-model").value = c().model;
    $("ai-model").placeholder = MODEL;
    const sb = K.cfg.sb || {};
    $("ai-trState").textContent = !K.scan ? "Откройте последовательность подкаста" : tr
      ? `Есть: ${tr.words.length} слов · ${tr.svc} · ${new Date(tr.date).toLocaleString()}${tr.how && tr.how !== "готовая" && tr.how !== "новая" ? " · " + tr.how : ""}`
      : `Нет. Будет: ${sb.stt === "local" ? "Whisper" : "ElevenLabs"}, язык ${{ kk: "казахский", ru: "русский", en: "английский" }[sb.lang] || "авто"} (меняется в «Субтитрах»)`;
    $("ai-tr").textContent = tr ? "Расшифровать заново" : "Расшифровать";
    $("ai-tr").disabled = K.busy || !K.scan;
    const aiOk = K.lic.can("ai");
    const can = !K.busy && !!tr && !!c().key && aiOk;
    ["ai-moments", "ai-teaser", "ai-yt"].forEach((id) => ($(id).disabled = !can));
    $("ai-why").textContent = !aiOk ? K.noFeature("ai") : !tr ? "Сначала расшифровка" : !c().key ? "Нужен ключ Claude API" : "";
    renderResult();
  }
  function renderResult() {
    const box = $("ai-result");
    if (!result) { box.classList.add("hidden"); return; }
    box.classList.remove("hidden");
    if (result.kind === "moments") {
      $("ai-resTitle").textContent = "Моменты для нарезок";
      $("ai-resBody").innerHTML = result.data.map((m, i) => `<div class="li ${result.skip.has(i) ? "off" : ""}"><input type="checkbox" data-ai-item="${i}" ${result.skip.has(i) ? "" : "checked"}>
        <span class="tc" data-ai-go="${m.start}" style="cursor:pointer" title="${m.parts.map((p) => A.tc(p.start) + "–" + A.tc(p.end)).join(" + ")}">${A.tc(m.start)}–${A.tc(m.end)}${m.parts.length > 1 ? ` +${m.parts.length - 1}` : ""} · ${Math.round(m.dur)} с</span>
        <span class="nm" title="${esc(m.why || "")}">${esc(m.title)}<br><span class="small-text">${esc(m.why || "")}</span></span></div>`).join("");
      $("ai-resAct").innerHTML = `<button class="main" id="ai-toClips" style="margin:0">Открыть в «Нарезках»</button>`;
      $("ai-toClips").onclick = toClips;
    } else if (result.kind === "teaser") {
      const total = result.data.reduce((a, p) => a + (p.end - p.start), 0);
      $("ai-resTitle").textContent = `Тизер · ${total.toFixed(0)} с`;
      $("ai-resBody").innerHTML = result.data.map((p, i) => `<div class="li"><span class="tc" data-ai-go="${p.start}" style="cursor:pointer">${A.tc(p.start)}</span><span class="nm">${i + 1}. ${esc(p.text || "")}</span><span class="tc">${(p.end - p.start).toFixed(1)} с</span></div>`).join("");
      $("ai-resAct").innerHTML = `<button class="main" id="ai-build" style="margin:0">Собрать тизер</button>`;
      $("ai-build").onclick = buildTeaser;
    } else {
      $("ai-resTitle").textContent = "Для YouTube";
      $("ai-resBody").innerHTML = `<textarea id="ai-text" style="min-height:260px">${esc(result.data)}</textarea>`;
      $("ai-resAct").innerHTML = `<button class="btn" id="ai-copy">Скопировать</button>`;
      $("ai-copy").onclick = () => { const t = $("ai-text"); t.select(); document.execCommand("copy"); status("Скопировано", "good"); };
    }
  }
  $("scr-ai").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.aiItem !== undefined) { const i = +t.dataset.aiItem; if (t.checked) result.skip.delete(i); else result.skip.add(i); renderResult(); return; }
    if (t.id === "ai-key") c().key = t.value.trim();
    else if (t.id === "ai-model") c().model = t.value.trim();
    else return;
    K.saveCfg(); render();
  });
  $("scr-ai").addEventListener("click", (e) => {
    const g = e.target.closest("[data-ai-go]");
    if (g && K.scan) K.call("ac_setPlayhead", K.scan.seqId, +g.dataset.aiGo);
  });

  // ---------- действия ----------
  async function act(fn, tag) {
    if (K.busy || !K.scan) return;
    K.setBusy(true);
    K.report = [`AI: «${K.scan.seqName}» — ${tag}`];
    try { await fn(); status("Готово", "good"); }
    catch (e) { log("ОШИБКА: " + e.message); status(e.message, "err"); }
    log("Лог: " + K.saveLog("ai"));
    K.setBusy(false);
  }
  const text = () => A.transcriptText(A.phrases(tr.words, tr.events));
  const stamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-");

  const line = (m) => m.parts.map((p) => `${tcd(p.start)} - ${tcd(p.end)}`).join(" + ") + " " + m.title;
  async function moments() {
    const [mn, mx] = c().len.split("-").map(Number);
    const j = await ask(A.promptMoments(text(), +c().count, mn, mx, c().multi === "yes"));
    const clips = (j.clips || []).map((m) => {
      const raw = Array.isArray(m.parts) && m.parts.length ? m.parts : [{ start: m.start, end: m.end }];
      const parts = raw.map((p) => A.snap(tr.words, +p.start, +p.end)).filter((p) => p.end - p.start >= 1.5).slice(0, 3);
      return Object.assign(m, { parts, start: parts.length ? parts[0].start : 0, end: parts.length ? parts[0].end : 0, dur: parts.reduce((a, p) => a + p.end - p.start, 0) });
    }).filter((m) => m.parts.length && m.dur >= 5);
    if (!clips.length) throw new Error("Модель не нашла фрагментов");
    result = { kind: "moments", data: clips, skip: new Set() };
    K.fs.writeFileSync(K.path.join(DIR, `${K.safeName(K.scan.seqName)}_моменты_${stamp()}.txt`), clips.map((m) => `${line(m)}  // ${m.why || ""}`).join("\n"), "utf8");
    clips.forEach((m) => log(`  ${m.parts.map((p) => A.tc(p.start) + "–" + A.tc(p.end)).join(" + ")} ${m.title} — ${m.why || ""}`));
  }
  function toClips() {
    const lines = result.data.filter((_, i) => !result.skip.has(i)).map(line).join("\n");
    K.modules.clips.openWith(K.scan.seqId, lines);
    K.show("clips");
  }

  async function teaser() {
    const j = await ask(A.promptTeaser(text(), +c().teaser));
    const parts = (j.parts || []).map((p) => Object.assign(p, A.snap(tr.words, +p.start, +p.end, 0.08))).filter((p) => p.end - p.start >= 1);
    if (!parts.length) throw new Error("Модель не собрала тизер");
    result = { kind: "teaser", data: parts };
    parts.forEach((p, i) => log(`  ${i + 1}. ${A.tc(p.start)} (${(p.end - p.start).toFixed(1)} с) ${p.text || ""}`));
  }
  async function buildTeaser() {
    await act(async () => {
      const s = K.scan, fps = 1 / s.frameDur;
      const srcKey = await K.TR.keyOf(s.seqId);
      const id = await K.modules.clips.newSeq(`Тизер — ${s.seqName}`, s.width, s.height, fps, "kök Edit/Тизер");
      let t = 0;
      const segs = [];
      for (let i = 0; i < result.data.length; i++) {
        const p = result.data[i];
        status(`Тизер: кусок ${i + 1} из ${result.data.length}…`);
        const r = await K.call("ac_subsequence", s.seqId, p.start, p.end, `Тизер ${i + 1}`);
        if (!r.ok) throw new Error(r.error);
        await K.call("ac_moveSeqToBin", r.id, "kök Edit/Тизер/куски");
        const x = await K.call("ac_placeNest", id, r.id, t, s.width, s.height, `${i + 1}. ${(p.text || "").slice(0, 40)}`);
        if (!x.ok) throw new Error(x.error);
        segs.push([p.start, p.start + x.dur, t]);
        t += x.dur;
      }
      await K.TR.link(srcKey, id, segs, s.seqName);
      log(`Тизер собран: ${t.toFixed(1)} с, «Тизер — ${s.seqName}»`);
    }, "сборка тизера");
  }

  async function youtube() {
    const j = await ask(A.promptYoutube(text(), K.scan.seqEnd));
    const ch = (j.chapters || []).map((x) => `${A.tc(+x.start)} ${x.title}`);
    if (ch.length && !/^0:00 /.test(ch[0])) ch.unshift("0:00 Кіріспе / Вступление");
    const out = [
      "ГЛАВЫ", ...ch, "",
      "ЗАГОЛОВКИ", ...(j.titles || []).map((x, i) => `${i + 1}. ${x}`), "",
      "ОПИСАНИЕ", j.description || "", "",
      "ПОСТ", j.post || "",
    ].join("\n");
    result = { kind: "youtube", data: out };
    K.fs.writeFileSync(K.path.join(DIR, `${K.safeName(K.scan.seqName)}_youtube_${stamp()}.txt`), out, "utf8");
  }

  $("ai-tr").onclick = () => act(transcribeAll, "расшифровка");
  $("ai-moments").onclick = () => act(moments, "моменты");
  $("ai-teaser").onclick = () => act(teaser, "тизер");
  $("ai-yt").onclick = () => act(youtube, "YouTube");

  K.modules.ai = {
    title: "Расшифровка и AI", cfgKey: "ai", needsTimeline: true,
    async onScan() { result = null; await loadTr(); render(); },
    render,
    // для «Пауз»: расшифровка открытой последовательности (make — расшифровать, если ещё нет)
    async transcript(make) { await loadTr(); if (!tr && make) await transcribeAll(); return tr; },
  };
})();

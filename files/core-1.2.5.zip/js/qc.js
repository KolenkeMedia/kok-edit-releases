// kök Edit — Проверка: находит места, на которые стоит посмотреть (хлопки, пропал звук, перегруз, дыры камер, события в кадре).
// Ставит маркеры «kök: …» на открытую последовательность — сам монтаж не меняется.
(function () {
  const { $, esc, log, status, fmt, P } = K;
  const Q = require(K.path.join(K.EXT, "lib", "qc.js"));
  const DEFAULTS = { sens: "mid", noise: true, drop: true, over: true, gaps: true, scene: false };
  const c = () => K.cfg.qc;
  K.cfg.qc = K.cfg.qc || {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = v;
  const SENS = { low: { jump: 20, diff: 3, scene: 0.12 }, mid: { jump: 16, diff: 4, scene: 0.07 }, high: { jump: 13, diff: 6, scene: 0.04 } };
  const PREFIX = "kök: ";
  const KIND = {
    noise: { icon: "👏", name: "Резкий звук в комнате", color: 1 },
    hit: { icon: "🎙", name: "Удар по микрофону", color: 1 },
    drop: { icon: "🔇", name: "Пропал звук", color: 0 },
    over: { icon: "📢", name: "Очень громко — возможен перегруз", color: 3 },
    gap: { icon: "⬛", name: "Нет картинки на камере", color: 0 },
    scene: { icon: "🎥", name: "Резкое изменение в кадре", color: 5 },
  };
  let found = [];

  function render() {
    K.renderSegs($("scr-qc"), c());
    for (const k of ["noise", "drop", "over", "gaps", "scene"]) $("qc-" + k).checked = !!c()[k];
    $("qc-list").innerHTML = found.length
      ? found.map((f, i) => `<div class="li" data-qc-go="${i}" style="cursor:pointer" title="Перейти"><span class="tc">${fmt(f.t).replace(/\.\d$/, "")}</span><span>${KIND[f.kind].icon}</span><span class="nm">${esc(f.text)}</span></div>`).join("")
      : `<div class="small-text">Пока ничего не найдено.</div>`;
    $("qc-resCard").classList.toggle("hidden", !found.length);
    $("qc-run").disabled = K.busy || !K.scan || !["noise", "drop", "over", "gaps", "scene"].some((k) => c()[k]);
  }
  $("scr-qc").addEventListener("change", (e) => {
    const id = e.target.id;
    if (id && id.startsWith("qc-") && DEFAULTS[id.slice(3)] !== undefined) { c()[id.slice(3)] = e.target.checked; K.saveCfg(); render(); }
  });
  $("scr-qc").addEventListener("click", (e) => {
    const li = e.target.closest("[data-qc-go]");
    if (li && K.scan) K.call("ac_setPlayhead", K.scan.seqId, found[+li.dataset.qcGo].t);
  });

  // события в кадре: ffmpeg смотрит ключевые кадры каждой камеры и ищет резкие изменения картинки
  async function sceneEvents(track, thr, idx, total) {
    const out = [];
    for (const clip of track.clips) {
      if (!clip.path) continue;
      const dur = clip.end - clip.start;
      const key = "scene_" + K.hash(K.fileKey(clip.path), clip.inPoint.toFixed(2), dur.toFixed(2), thr);
      let list = null;
      const cf = K.path.join(K.CACHE, key + ".json");
      try { list = JSON.parse(K.fs.readFileSync(cf, "utf8")); } catch (e) {}
      if (!list) {
        const err = await K.ffmpeg(["-v", "info", "-skip_frame", "nokey", "-ss", clip.inPoint.toFixed(3), "-t", dur.toFixed(3), "-i", clip.path, "-an",
          "-vf", `scale=160:-2,select='gt(scene,${thr})',metadata=print`, "-f", "null", "-"], (s) => {
          const m = String(s).match(/time=(\d+):(\d+):([\d.]+)/);
          if (m) status(`Камера V${track.index + 1} (${idx}/${total}): смотрю кадр… ${Math.min(99, Math.round(((+m[1] * 3600 + +m[2] * 60 + +m[3]) / dur) * 100))}%`);
        });
        list = Q.parseScenes(err);
        try { K.fs.writeFileSync(cf, JSON.stringify(list)); } catch (e) {}
      }
      for (const s of list) out.push({ t: clip.start + s.t, d: 0.5, score: s.score });
    }
    return Q.mergeHits(out, 3);
  }

  async function run() {
    if (!K.scan || K.busy) return;
    K.setBusy(true);
    const scan = K.scan, S = SENS[c().sens];
    K.report = [`Проверка «${scan.seqName}» (${fmt(scan.seqEnd)}), чувствительность ${c().sens}`];
    found = [];
    try {
      const aTracks = scan.audio.filter((t) => t.clips.length);
      const cover = (t, tr) => tr.clips.some((x) => t >= x.start && t <= x.end);
      if ((c().noise || c().drop || c().over) && aTracks.length) {
        const idx = aTracks.map((t) => t.index);
        const levels = await K.modules.autocam.trackLevels(idx, { noSameCheck: true });
        status("Ищу проблемы в звуке…");
        if (c().noise) {
          const per = levels.map((l) => Q.transients(l, P.RATE, { jumpDb: S.jump, overRefDb: -3 }));
          if (levels.length > 1) {
            const room = Q.coincident(per, 2, 0.15).filter((h) => {
              const w = Math.round(h.t * P.RATE);
              const v = h.tracks.map((k) => Math.max(levels[k][w], levels[k][w + 1] || -100));
              return Math.max(...v) - Math.min(...v) < S.diff;
            });
            room.forEach((h) => found.push({ t: h.t, d: h.d, kind: "noise", text: `${KIND.noise.name} (${h.tracks.map((k) => "A" + (idx[k] + 1)).join(", ")})` }));
          }
          // очень резкий звук только на одном микрофоне — задели петличку, стук по столу рядом
          per.forEach((hits, k) => hits.filter((h) => h.score > S.jump + 12).forEach((h) => {
            if (!found.some((f) => Math.abs(f.t - h.t) < 0.5)) found.push({ t: h.t, d: h.d, kind: "hit", text: `${KIND.hit.name} A${idx[k] + 1}` });
          }));
        }
        if (c().drop) levels.forEach((l, k) => Q.dropouts(l, P.RATE).forEach((h) => {
          const tr = aTracks[k];
          if (!cover(h.t + 0.1, tr)) return; // там просто нет клипа
          const othersLive = levels.some((o, j) => j !== k && o[Math.round((h.t + h.d / 2) * P.RATE)] > -95);
          if (othersLive || levels.length === 1) found.push({ t: h.t, d: h.d, kind: "drop", text: `${KIND.drop.name} на A${idx[k] + 1} (${h.d.toFixed(1)} с)` });
        }));
        if (c().over) levels.forEach((l, k) => Q.overloads(l, P.RATE, { limitDb: -8 }).forEach((h) => found.push({ t: h.t, d: h.d, kind: "over", text: `${KIND.over.name} на A${idx[k] + 1}` })));
      }
      const vTracks = scan.video.filter((t) => t.clips.length);
      if (c().gaps) vTracks.forEach((tr) => Q.videoGaps(tr.clips, scan.seqEnd, 1).forEach((g) => found.push({ t: g.t, d: g.d, kind: "gap", text: `${KIND.gap.name} V${tr.index + 1} (${fmt(g.d).replace(/\.\d$/, "")})` })));
      if (c().scene) for (let i = 0; i < vTracks.length; i++) {
        const ev = await sceneEvents(vTracks[i], S.scene, i + 1, vTracks.length);
        ev.forEach((h) => found.push({ t: h.t, d: h.d, kind: "scene", text: `${KIND.scene.name} V${vTracks[i].index + 1}` }));
      }
      found.sort((a, b) => a.t - b.t);
      status("Ставлю маркеры…");
      await K.call("ac_removeMarkers", scan.seqId, PREFIX);
      const marks = found.map((f) => ({ t: +f.t.toFixed(3), d: +Math.max(0.2, f.d).toFixed(3), n: PREFIX + f.text, c: KIND[f.kind].color }));
      for (let i = 0; i < marks.length; i += 200) await K.call("ac_markers", scan.seqId, marks.slice(i, i + 200));
      const by = {};
      found.forEach((f) => (by[f.kind] = (by[f.kind] || 0) + 1));
      log(`Найдено: ${found.length} — ` + Object.entries(by).map(([k, n]) => `${KIND[k].name.toLowerCase()} ${n}`).join(", "));
      found.forEach((f) => log(`  ${fmt(f.t)}  ${f.text}`));
      status(found.length ? `Найдено мест: ${found.length}. Маркеры «kök: …» на таймлайне.` : "Ничего подозрительного не нашёл.", "good");
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    log("Лог: " + K.saveLog("qc"));
    K.setBusy(false);
  }
  $("qc-run").onclick = run;
  $("qc-clear").onclick = async () => {
    if (!K.scan) return;
    const r = await K.call("ac_removeMarkers", K.scan.seqId, PREFIX);
    found = []; render();
    status(r.ok ? `Удалено маркеров: ${r.n}` : r.error, r.ok ? "good" : "err");
  };

  K.modules.qc = { title: "Проверка", cfgKey: "qc", needsTimeline: true, onScan: () => { found = []; render(); }, render };
})();

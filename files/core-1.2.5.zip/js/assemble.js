// kök Edit — Синхронизация: папка съёмки → синхрон по звуку → новая последовательность (через XML).
(function () {
  const { $, esc, log, status, fmt, SY } = K;
  const DEFAULTS = { src: "folder", camAudio: "all", folder: "", off: {} };
  const c = () => K.cfg.as;
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = JSON.parse(JSON.stringify(v));
  const VIDEO = /\.(mov|mp4|mxf|mts|m2ts|m4v|avi|mkv)$/i;
  const AUDIO = /\.(wav|bwf|mp3|m4a|aif|aiff|flac)$/i;
  const BIN = "kök Edit/Синхронизация";

  let groups = []; // [{key, label, kind: 'cam'|'audio', files: [path]}]

  function scanFolder(root) {
    const cams = {}, auds = {};
    const walk = (dir, depth) => {
      let items;
      try { items = K.fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
      const vids = [];
      for (const it of items) {
        if (it.name.startsWith(".")) continue;
        const full = K.path.join(dir, it.name);
        if (it.isDirectory()) { if (depth < 3) walk(full, depth + 1); continue; }
        if (VIDEO.test(it.name)) vids.push(full);
        else if (AUDIO.test(it.name)) {
          const base = it.name.replace(/\.[^.]+$/, "");
          const m = base.match(/[_-](Tr\d+|TrLR|LR|Ch\d+|MIC\d+|TX\d+)$/i);
          const key = m ? "suffix:" + m[1].toUpperCase() : "dir:" + dir;
          (auds[key] = auds[key] || { label: m ? m[1] : K.path.basename(dir), files: [] }).files.push(full);
        }
      }
      if (vids.length) {
        if (dir === root) vids.forEach((v) => (cams["file:" + v] = { label: K.path.basename(v), files: [v] }));
        else cams["dir:" + dir] = { label: K.path.relative(root, dir) || K.path.basename(dir), files: vids };
      }
    };
    walk(root, 0);
    const nat = (a, b) => a.localeCompare(b, undefined, { numeric: true });
    groups = [
      ...Object.entries(cams).sort((a, b) => nat(a[1].label, b[1].label)).map(([key, g]) => ({ key, kind: "cam", label: g.label, files: g.files.sort(nat) })),
      ...Object.entries(auds).sort((a, b) => nat(a[1].label, b[1].label)).map(([key, g]) => ({ key, kind: "audio", label: g.label, files: g.files.sort(nat) })),
    ];
  }

  // группы из открытой последовательности: каждая видеодорожка — камера, звук без видео — рекордер
  async function scanTimeline() {
    const r = await K.readTimeline();
    groups = [];
    if (!r) return;
    const vids = new Set();
    for (const t of r.video) {
      const files = [...new Set(t.clips.map((x) => x.path).filter(Boolean))];
      files.forEach((f) => vids.add(f));
      if (files.length) groups.push({ key: "seqV:" + t.index, kind: "cam", label: `V${t.index + 1} · ${K.path.basename(files[0])}${files.length > 1 ? " …" : ""}`, files });
    }
    for (const t of r.audio) {
      const files = [...new Set(t.clips.map((x) => x.path).filter((p) => p && !vids.has(p)))];
      if (files.length) groups.push({ key: "seqA:" + t.index, kind: "audio", label: `A${t.index + 1} · ${K.path.basename(files[0])}${files.length > 1 ? " …" : ""}`, files });
    }
  }
  const fromSeq = () => c().src === "sequence";

  function render() {
    $("as-folderCard").classList.toggle("hidden", fromSeq());
    $("as-seqCard").classList.toggle("hidden", !fromSeq());
    if (fromSeq()) $("as-seqName").textContent = K.scan ? K.scan.seqName : "нет открытой последовательности";
    $("as-folder").textContent = c().folder || "не выбрана";
    $("as-folder").title = c().folder || "";
    let v = 0;
    $("as-layout").innerHTML = groups.map((g) => {
      const on = !c().off[g.key];
      const where = g.kind === "cam" ? (on ? `V${++v}` : "—") : "звук";
      return `<div class="li ${on ? "" : "off"}"><input type="checkbox" data-as="${esc(g.key)}" ${on ? "checked" : ""}>
        <span class="tc">${where}</span><span class="nm" title="${esc(g.files.join("\n"))}">${esc(g.label)}</span><span class="tc">${g.files.length} ф.</span></div>`;
    }).join("") || (c().folder || fromSeq() ? `<div class="small-text">Видео и звук не найдены.</div>` : "");
    if (!$("as-name").value && c().folder && !fromSeq()) $("as-name").value = K.path.basename(c().folder);
    K.renderSegs($("scr-assemble"), c());
    $("as-run").disabled = K.busy || !groups.some((g) => !c().off[g.key]);
  }
  $("as-pick").onclick = () => {
    const f = K.pickFolder("Папка съёмки");
    if (!f) return;
    c().folder = f; c().off = {}; $("as-name").value = K.path.basename(f);
    K.saveCfg(); scanFolder(f); render();
  };
  $("scr-assemble").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.as !== undefined) { if (t.checked) delete c().off[t.dataset.as]; else c().off[t.dataset.as] = true; K.saveCfg(); render(); }
  });

  // ---------- XML ----------
  const xe = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  function pathUrl(p) {
    const parts = p.replace(/\\/g, "/").split("/");
    return "file://localhost/" + parts.map((s, i) => (i === 0 && /^[A-Za-z]:$/.test(s) ? s[0] + "%3a" : encodeURIComponent(s))).join("/");
  }
  function rateOf(fps) {
    const near = (x) => Math.abs(fps - x) < 0.02;
    if (near(23.976)) return { tb: 24, ntsc: true, fps: 24000 / 1001 };
    if (near(29.97)) return { tb: 30, ntsc: true, fps: 30000 / 1001 };
    if (near(59.94)) return { tb: 60, ntsc: true, fps: 60000 / 1001 };
    return { tb: Math.round(fps), ntsc: false, fps: Math.round(fps) };
  }
  function buildXML(name, placed, rate, w, h) {
    const R = `<rate><timebase>${rate.tb}</timebase><ntsc>${rate.ntsc ? "TRUE" : "FALSE"}</ntsc></rate>`;
    const F = (sec) => Math.round(sec * rate.fps);
    const fileIds = {};
    let fid = 0, cid = 0;
    const fileEl = (p) => {
      if (fileIds[p.file]) return `<file id="${fileIds[p.file]}"/>`;
      const id = (fileIds[p.file] = "f" + ++fid);
      const vid = p.info.video ? `<video><samplecharacteristics><width>${p.info.video.w}</width><height>${p.info.video.h}</height></samplecharacteristics></video>` : "";
      const aud = p.info.channels ? `<audio><samplecharacteristics><depth>16</depth><samplerate>${p.info.rate}</samplerate></samplecharacteristics><channelcount>${p.info.channels}</channelcount></audio>` : "";
      return `<file id="${id}"><name>${xe(K.path.basename(p.file))}</name><pathurl>${xe(pathUrl(p.file))}</pathurl>${R}<duration>${F(p.info.dur)}</duration><media>${vid}${aud}</media></file>`;
    };
    const clip = (p, ch) => {
      const d = F(p.info.dur), s = F(p.start);
      const src = ch ? `<sourcetrack><mediatype>audio</mediatype><trackindex>${ch}</trackindex></sourcetrack>` : "";
      return `<clipitem id="c${++cid}"><name>${xe(K.path.basename(p.file))}</name><enabled>TRUE</enabled><duration>${d}</duration>${R}<start>${s}</start><end>${s + d}</end><in>0</in><out>${d}</out>${fileEl(p)}${src}</clipitem>`;
    };
    const vTracks = [], aTracks = [];
    const cams = [...new Set(placed.filter((p) => p.kind === "cam").map((p) => p.group))];
    for (const g of cams) vTracks.push(`<track>${placed.filter((p) => p.group === g).map((p) => clip(p, 0)).join("")}</track>`);
    const audioGroups = [...new Set(placed.map((p) => p.group))];
    for (const g of audioGroups) {
      const ps = placed.filter((p) => p.group === g && p.info.channels);
      if (!ps.length) continue;
      const isCam = ps[0].kind === "cam";
      if (isCam && c().camAudio === "none") continue;
      const maxCh = isCam && c().camAudio === "first" ? 1 : Math.max(...ps.map((p) => p.info.channels));
      for (let ch = 1; ch <= maxCh; ch++) aTracks.push(`<track>${ps.filter((p) => p.info.channels >= ch).map((p) => clip(p, ch)).join("")}</track>`);
    }
    const total = Math.max(...placed.map((p) => F(p.start + p.info.dur)));
    return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="seq1"><name>${xe(name)}</name><duration>${total}</duration>${R}` +
      `<media><video><format><samplecharacteristics>${R}<width>${w}</width><height>${h}</height><pixelaspectratio>square</pixelaspectratio></samplecharacteristics></format>${vTracks.join("")}</video>` +
      `<audio>${aTracks.join("")}</audio></media></sequence></xmeml>`;
  }

  // ---------- синхронизация ----------
  async function run() {
    if (K.busy) return;
    K.setBusy(true);
    const name = $("as-name").value.trim() || (fromSeq() && K.scan ? K.scan.seqName + " синхрон" : K.path.basename(c().folder));
    const use = groups.filter((g) => !c().off[g.key]);
    K.report = [`Синхронизация «${name}» из ${fromSeq() ? "последовательности «" + (K.scan ? K.scan.seqName : "?") + "»" : c().folder}`];
    $("as-result").classList.add("hidden");
    try {
      // 1. сведения о файлах
      const files = [];
      for (const g of use) for (const f of g.files) {
        status(`Читаю сведения о файлах… ${files.length + 1}`);
        const info = await K.probe(f);
        if (!info || !info.dur) { log(`  пропущен (не читается): ${f}`); continue; }
        files.push({ file: f, group: g.key, label: g.label, kind: g.kind, info });
      }
      if (!files.some((f) => f.info.channels)) throw new Error("Ни в одном файле нет звука — синхронизировать не по чему.");
      // 2. опорный файл: самый длинный звук с рекордера, иначе самое длинное видео со звуком
      const withAudio = files.filter((f) => f.info.channels);
      const recs = withAudio.filter((f) => f.kind === "audio");
      const ref = (recs.length ? recs : withAudio).reduce((a, b) => (b.info.dur > a.info.dur ? b : a));
      log(`Опорный звук: ${K.path.basename(ref.file)} (${fmt(ref.info.dur)})`);
      // 3. громкость: опорный целиком, остальные — первые 10 минут
      const MAXSEC = 600;
      const envOf = async (f, full, idx) => {
        const key = "sync_" + K.hash(K.fileKey(f.file), SY.ENV_RATE, full ? "full" : MAXSEC);
        let env = K.cacheGet(key);
        if (!env) {
          env = await K.envelope(f.file, SY.ENV_RATE, (s) => status(`Слушаю ${idx}/${files.length}: ${K.path.basename(f.file)} — ${Math.round(s / Math.min(full ? f.info.dur : MAXSEC, f.info.dur) * 100)}%`), full ? 0 : MAXSEC);
          K.cachePut(key, env);
        }
        return env;
      };
      const refEnv = await envOf(ref, true, 1);
      const others = withAudio.filter((f) => f !== ref);
      let next = 0;
      const worker = async () => {
        while (next < others.length) {
          const f = others[next++];
          f.env = await envOf(f, false, next + 1);
        }
      };
      await Promise.all([worker(), worker()]);
      // 4. смещения
      status("Ищу совпадения по звуку…");
      ref.start = 0; ref.conf = 99;
      for (const f of others) {
        const r = SY.findOffset(refEnv, f.env, MAXSEC);
        f.start = r.lag; f.conf = r.conf;
        f.env = null;
      }
      // без звука или неуверенно — ставим сразу после предыдущего файла той же камеры
      const byGroup = {};
      for (const f of files) (byGroup[f.group] = byGroup[f.group] || []).push(f);
      for (const list of Object.values(byGroup)) {
        list.forEach((f, i) => {
          if (f.start !== undefined && f.conf >= 1.3) return;
          const prev = list[i - 1];
          if (prev && prev.start !== undefined) { f.start = prev.start + prev.info.dur; f.guess = true; }
          else if (f.start === undefined) { f.start = 0; f.guess = true; }
          else f.guess = true;
        });
      }
      const minStart = Math.min(...files.map((f) => f.start));
      files.forEach((f) => (f.start -= minStart));
      // 5. XML и импорт
      const firstCam = files.find((f) => f.kind === "cam" && f.info.video);
      const rate = rateOf(firstCam ? firstCam.info.video.fps : 25);
      const w = firstCam ? firstCam.info.video.w : 1920, h = firstCam ? firstCam.info.video.h : 1080;
      const xmlDir = K.path.join(K.OUT, "assemble");
      K.fs.mkdirSync(xmlDir, { recursive: true });
      const xml = K.path.join(xmlDir, K.safeName(name) + "_" + Date.now() + ".xml");
      K.fs.writeFileSync(xml, buildXML(name, files, rate, w, h), "utf8");
      status("Premiere собирает последовательность…");
      const r = await K.call("ac_importXML", xml, BIN);
      if (!r.ok) throw new Error(r.error + ` — XML лежит: ${xml}`);
      // 6. отчёт
      $("as-sync").innerHTML = files.map((f) => {
        const bad = f.guess || f.conf < 1.3;
        return `<div class="li"><span class="tc">${fmt(f.start).replace(/\.\d$/, "")}</span><span class="nm" title="${esc(f.file)}">${esc(f.label)} · ${esc(K.path.basename(f.file))}</span>
          <span class="${bad ? "warn" : "good"}" title="${bad ? "Не уверен — проверьте синхрон этого файла" : "Совпадение уверенное"}">${bad ? "⚠" : "✓"}</span></div>`;
      }).join("");
      $("as-result").classList.remove("hidden");
      const weak = files.filter((f) => f.guess || f.conf < 1.3).length;
      files.forEach((f) => log(`  ${fmt(f.start)}  ${f.label} · ${K.path.basename(f.file)}  ${f === ref ? "опорный" : f.guess ? "⚠ поставлен по порядку" : "совпадение " + f.conf.toFixed(1)}`));
      status(`Готово: «${r.name}»${weak ? ` · проверьте ⚠ (${weak})` : ""}. Дальше — AutoCam.`, weak ? "err" : "good");
      await K.readTimeline();
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    log("Лог: " + K.saveLog("assemble"));
    K.setBusy(false);
  }
  $("as-run").onclick = run;
  $("as-reread").onclick = () => onSeg();
  if (!fromSeq() && c().folder && K.fs.existsSync(c().folder)) scanFolder(c().folder);
  // смена источника: папка ↔ открытая последовательность
  async function onSeg() {
    $("as-name").value = "";
    if (fromSeq()) await scanTimeline();
    else if (c().folder && K.fs.existsSync(c().folder)) scanFolder(c().folder); else groups = [];
    if (fromSeq() && K.scan) $("as-name").value = K.scan.seqName + " синхрон";
    render();
  }

  K.modules.assemble = { title: "Синхронизация", cfgKey: "as", needsTimeline: false, render, onSeg, onShow: () => { if (fromSeq()) onSeg(); }, _buildXML: buildXML };
})();

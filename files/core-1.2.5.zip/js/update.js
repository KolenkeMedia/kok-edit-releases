// kök Edit — обновления: проверка новой версии, плашка «Обновить», установка по кнопке без перезапуска Premiere.
// Версии лежат на GitHub (KolenkeMedia/kok-edit-releases). Каналы: main — клиенты, test — тестовая среда.
// Каждая версия подписана ключом kök (Ed25519) — подменённое обновление не установится.
(function () {
  const { $, esc, log, status, fs, path } = K;
  const L = require(path.join(K.EXT, "lib", "license.js"));
  const U = require(path.join(K.EXT, "lib", "unzip.js"));
  const REPO = "KolenkeMedia/kok-edit-releases";
  const CHANNEL_URL = (ch) => `https://raw.githubusercontent.com/${REPO}/main/channels/${ch}.json?t=${Date.now()}`;
  const COMP_FILE = path.join(K.EXT, "components.json"); // какие части установлены: { core:{key,files}, ffmpeg:{key}, whisper:{key} }
  const BACKUP = path.join(K.WORK, "backup");
  const EVERY = 6 * 3600000;

  let rel = null;      // проверенный release.json новой версии
  let state = "idle";  // idle | checking | available | downloading | done | error
  let note = "";
  const installed = () => { try { return JSON.parse(fs.readFileSync(COMP_FILE, "utf8")); } catch (e) { return {}; } };

  // «1.10.2» > «1.9.9»
  function newer(a, b) {
    const x = String(a).split(/[.-]/).map((n) => parseInt(n, 10) || 0), y = String(b).split(/[.-]/).map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
    return false;
  }
  const sha = (file) => K.crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");

  // release.json + подпись → проверенный объект
  async function fetchRelease(ptr) {
    const [data, sig] = await Promise.all([K.getText(ptr.release), K.getText(ptr.sig)]);
    if (!L.verifySig(data, sig.trim())) throw new Error("Подпись версии не сходится — обновление не установлено.");
    const r = JSON.parse(data);
    if (r.version !== ptr.version) throw new Error("Версия в описании не совпадает.");
    return r;
  }

  async function check(manual) {
    if (state === "downloading") return;
    state = "checking"; render();
    try {
      const ptr = JSON.parse(await K.getText(CHANNEL_URL(K.CHANNEL)));
      if (!newer(ptr.version, K.VERSION)) { rel = null; state = "idle"; note = manual ? `У вас последняя версия ${K.VERSION}` : ""; }
      else { rel = await fetchRelease(ptr); state = "available"; note = ""; }
    } catch (e) {
      state = rel ? "available" : "idle";
      note = manual ? (e.offline ? "Нет связи с GitHub — проверьте интернет." : e.message) : "";
    }
    render();
  }

  // скачать часть, проверить хэш
  async function fetchComp(name, c, onProg) {
    const dir = path.join(K.CACHE, "update");
    fs.mkdirSync(dir, { recursive: true });
    const f = path.join(dir, `${name}-${c.key.slice(0, 12)}.zip`);
    if (!fs.existsSync(f) || sha(f) !== c.sha256) await K.download(c.url, f, onProg);
    if (sha(f) !== c.sha256) { try { fs.unlinkSync(f); } catch (e) {} throw new Error(`Файл ${name} скачался с ошибкой — попробуйте ещё раз.`); }
    return f;
  }
  const mb = (b) => (b / 1048576).toFixed(1);

  // поставить часть (whisper — по требованию; ffmpeg — если поменялся)
  async function installComp(name, c, prog) {
    const f = await fetchComp(name, c, (g, t) => prog && prog(`${name}: ${mb(g)} из ${mb(t || c.size)} МБ`));
    U.extract(f, K.EXT, "");
    const inst = installed();
    inst[name] = { key: c.key };
    fs.writeFileSync(COMP_FILE, JSON.stringify(inst, null, 2));
  }

  // whisper скачивается, когда впервые нужен локальный режим (в установщике его нет — он лёгкий)
  async function ensureComponent(name, prog) {
    const inst = installed();
    if (name === "whisper" && fs.existsSync(path.join(K.EXT, "bin", "whisper", "whisper-cli.exe")) && inst.whisper) return;
    let r = rel;
    if (!r) {
      const ptr = JSON.parse(await K.getText(CHANNEL_URL(K.CHANNEL)));
      // берём описание той версии, что стоит, если она ещё есть; иначе последней
      r = await fetchRelease(ptr);
    }
    const c = r.components[name];
    if (!c) throw new Error(`В версии ${r.version} нет части ${name}`);
    await installComp(name, c, prog || ((m) => status(`Скачиваю ${m}`)));
  }

  // обновление: сначала всё скачать и проверить, потом заменить файлы; при ошибке — вернуть старые
  async function apply() {
    if (!rel || state === "downloading") return;
    if (K.busy) { note = "Дождитесь окончания текущей задачи — потом нажмите «Обновить»."; return render(); }
    state = "downloading"; note = ""; render();
    K.setBusy(true);
    const inst = installed();
    const need = ["core", "ffmpeg", "whisper"].filter((n) => rel.components[n] && (n === "core" || (inst[n] ? inst[n].key !== rel.components[n].key : n === "ffmpeg" && !fs.existsSync(path.join(K.EXT, "bin", "ffmpeg.exe")))));
    const prog = (m) => { note = "Скачиваю " + m; render(); };
    const bdir = path.join(BACKUP, K.VERSION);
    let backed = [];
    try {
      const files = {};
      for (const n of need) files[n] = await fetchComp(n, rel.components[n], (g, t) => prog(`${n === "core" ? "плагин" : n}: ${mb(g)} из ${mb(t || rel.components[n].size)} МБ`));
      note = "Устанавливаю…"; render();
      // копия текущего кода (без ffmpeg/whisper — они большие и не меняются при откате кода)
      const oldCore = (inst.core && inst.core.files) || [];
      fs.rmSync(bdir, { recursive: true, force: true });
      for (const rel0 of oldCore) {
        const src = path.join(K.EXT, rel0);
        if (!fs.existsSync(src)) continue;
        const dst = path.join(bdir, rel0);
        fs.mkdirSync(path.dirname(dst), { recursive: true });
        fs.copyFileSync(src, dst);
        backed.push(rel0);
      }
      fs.writeFileSync(path.join(bdir, "backup.json"), JSON.stringify({ version: K.VERSION, files: backed, comp: inst }));
      // замена
      const newCore = U.extract(files.core, K.EXT, "");
      for (const old of oldCore) if (!newCore.includes(old)) { try { fs.unlinkSync(path.join(K.EXT, old)); } catch (e) {} } // удалённые в новой версии
      const next = Object.assign({}, inst, { core: { key: rel.components.core.key, files: newCore } });
      for (const n of need) if (n !== "core") { U.extract(files[n], K.EXT, ""); next[n] = { key: rel.components[n].key }; }
      fs.writeFileSync(COMP_FILE, JSON.stringify(next, null, 2));
      log(`Обновлено: ${K.VERSION} → ${rel.version}`);
      state = "done";
      note = rel.restart ? "Готово. Перезапустите Premiere Pro — в этой версии изменились настройки панели." : "Готово — перезагружаю панель…";
      render();
      K.setBusy(false);
      if (!rel.restart) setTimeout(reload, 800);
    } catch (e) {
      // откат: возвращаем сохранённые файлы
      for (const f of backed) { try { fs.copyFileSync(path.join(bdir, f), path.join(K.EXT, f)); } catch (e2) {} }
      state = "error"; note = "Обновление не удалось: " + e.message + (backed.length ? " Прежняя версия на месте." : "");
      K.setBusy(false);
      render();
    }
  }

  // перечитать ExtendScript и перезагрузить панель — Premiere закрывать не нужно
  async function reload() {
    try { await K.host(`$.evalFile(${JSON.stringify(path.join(K.EXT, "jsx", "host.jsx").replace(/\\/g, "/"))})`); } catch (e) {}
    location.reload();
  }

  // вернуть прошлую версию (если новая чем-то не понравилась)
  function rollbackInfo() {
    try {
      const vs = fs.readdirSync(BACKUP).filter((v) => fs.existsSync(path.join(BACKUP, v, "backup.json")) && v !== K.VERSION);
      return vs.length ? JSON.parse(fs.readFileSync(path.join(BACKUP, vs.sort((a, b) => (newer(a, b) ? -1 : 1))[0], "backup.json"), "utf8")) : null;
    } catch (e) { return null; }
  }
  function rollback() {
    const b = rollbackInfo();
    if (!b || K.busy) return;
    const bdir = path.join(BACKUP, b.version);
    const inst = installed();
    for (const f of (inst.core && inst.core.files) || []) if (!b.files.includes(f)) { try { fs.unlinkSync(path.join(K.EXT, f)); } catch (e) {} }
    for (const f of b.files) { fs.mkdirSync(path.dirname(path.join(K.EXT, f)), { recursive: true }); fs.copyFileSync(path.join(bdir, f), path.join(K.EXT, f)); }
    inst.core = { key: (b.comp.core && b.comp.core.key) || "", files: b.files };
    fs.writeFileSync(COMP_FILE, JSON.stringify(inst, null, 2));
    reload();
  }

  // ---------- плашка и блок в «Аккаунте» ----------
  function render() {
    const bar = $("upd-bar");
    if (bar) {
      const show = state === "available" || state === "downloading" || state === "done" || (state === "error" && rel);
      bar.classList.toggle("hidden", !show);
      if (show) {
        bar.innerHTML = state === "available"
          ? `<div class="grow"><b>Доступна версия ${esc(rel.version)}</b>${K.CHANNEL === "test" ? ' <span class="badge">тест</span>' : ""}${rel.notes && rel.notes.length ? `<div class="small-text">${rel.notes.slice(0, 3).map(esc).join(" · ")}</div>` : ""}${note ? `<div class="small-text warn">${esc(note)}</div>` : ""}</div><button class="btn" id="upd-go">Обновить</button>`
          : `<div class="grow small-text ${state === "error" ? "err" : ""}">${esc(note)}</div>${state === "error" ? `<button class="btn" id="upd-go">Ещё раз</button>` : ""}`;
      }
    }
    const box = $("upd-info");
    if (box) {
      const b = rollbackInfo();
      box.innerHTML = `<div class="row"><div class="label">Версия</div><div class="grow">${esc(K.VERSION)}${K.CHANNEL === "test" ? " · тестовая среда" : ""}</div>
        <button class="btn" id="upd-check" ${state === "checking" || state === "downloading" ? "disabled" : ""}>${state === "checking" ? "Проверяю…" : "Проверить обновления"}</button></div>
        ${note && state !== "available" ? `<div class="small-text">${esc(note)}</div>` : ""}
        ${b ? `<div class="row"><div class="grow small-text">Можно вернуть версию ${esc(b.version)}</div><button class="btn" id="upd-back">Вернуть</button></div>` : ""}`;
    }
  }
  document.addEventListener("click", (e) => {
    if (e.target.id === "upd-go") apply();
    if (e.target.id === "upd-check") check(true);
    if (e.target.id === "upd-back") rollback();
  });

  K.update = { check, apply, ensureComponent, render, newer };
  setTimeout(() => check(false), 15000); // не мешаем старту панели
  setInterval(() => { if (!K.busy) check(false); }, EVERY);
})();

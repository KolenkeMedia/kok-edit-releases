// kök Edit — общее ядро панели: пути, настройки, связь с Premiere, ffmpeg, лог.
/* global window, document */
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const https = require("https");
const { spawn } = require("child_process");

const K = (window.K = {});
K.fs = fs; K.path = path; K.os = os; K.crypto = crypto; K.spawn = spawn;

// ---------- пути ----------
K.EXT = decodeURI(window.__adobe_cep__.getSystemPath("extension")).replace(/^file:\/{2,3}/, "");
K.P = require(path.join(K.EXT, "lib", "planner.js"));
K.TC = require(path.join(K.EXT, "lib", "timecodes.js"));
K.SY = require(path.join(K.EXT, "lib", "sync.js"));
K.WORK = path.join(os.homedir(), "kokEdit");
K.CACHE = path.join(K.WORK, "cache");
K.LOGS = path.join(K.WORK, "logs");
K.PRESETS = path.join(K.WORK, "presets");
K.OUT = path.join(K.WORK, "files");
for (const d of [K.WORK, K.CACHE, K.LOGS, K.PRESETS, K.OUT]) { try { fs.mkdirSync(d, { recursive: true }); } catch (e) {} }

// перенос настроек и кэша из старой AutoCam (один раз)
(function migrate() {
  const old = path.join(os.homedir(), "AutoCam");
  const flag = path.join(K.WORK, ".migrated");
  if (!fs.existsSync(old) || fs.existsSync(flag)) return;
  const copyDir = (from, to, filter) => {
    try { for (const f of fs.readdirSync(from)) if (!filter || filter(f)) { try { fs.copyFileSync(path.join(from, f), path.join(to, f)); } catch (e) {} } } catch (e) {}
  };
  copyDir(path.join(old, "presets"), K.PRESETS);
  copyDir(path.join(old, "cache"), K.CACHE, (f) => f.startsWith("track_"));
  try {
    const last = JSON.parse(fs.readFileSync(path.join(old, "last.json"), "utf8"));
    const cfgFile = path.join(K.WORK, "settings.json");
    if (!fs.existsSync(cfgFile)) fs.writeFileSync(cfgFile, JSON.stringify({ ac: last, wavPreset: last.wavPreset }, null, 2));
  } catch (e) {}
  try { fs.writeFileSync(flag, new Date().toISOString()); } catch (e) {}
})();

// ffmpeg: в папке расширения → в папке старой AutoCam → системный
K.FFMPEG = [path.join(K.EXT, "bin", "ffmpeg.exe"), path.join(K.EXT, "..", "autocam", "bin", "ffmpeg.exe")].find((p) => fs.existsSync(p)) || "ffmpeg";

// ---------- настройки ----------
K.CFG_FILE = path.join(K.WORK, "settings.json");
K.cfg = { ac: {}, cl: {}, au: {}, as: {}, sb: {}, qc: {}, ai: {}, ct: {}, dl: {}, kok: {} };
try { Object.assign(K.cfg, JSON.parse(fs.readFileSync(K.CFG_FILE, "utf8"))); } catch (e) {}
for (const k of ["ac", "cl", "au", "as", "sb", "qc", "ai", "ct", "dl", "kok"]) K.cfg[k] = K.cfg[k] || {};
K.saveCfg = () => { try { fs.writeFileSync(K.CFG_FILE, JSON.stringify(K.cfg, null, 2)); } catch (e) {} };

// ---------- интерфейс ----------
K.$ = (id) => document.getElementById(id);
K.esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
K.report = [];
K.log = (s) => { K.report.push(s); K.$("out").textContent = K.report.join("\n"); K.$("out").scrollTop = 1e9; };
K.status = (s, cls) => { const el = K.$("status"); el.textContent = s || ""; el.className = cls || ""; };
K.fmt = (sec) => { const m = Math.floor(sec / 60), s = (sec % 60).toFixed(1); return `${m}:${s.padStart(4, "0")}`; };
K.saveLog = (tag) => {
  const file = path.join(K.LOGS, `kok_${tag}_${new Date().toISOString().replace(/[:.]/g, "-")}.txt`);
  try { fs.writeFileSync(file, K.report.join("\n"), "utf8"); return file; } catch (e) { return "не сохранён: " + e.message; }
};
K.openURL = (url) => { try { window.cep.util.openURLInDefaultBrowser(url); } catch (e) { try { require("child_process").exec(`start "" "${String(url).replace(/"/g, "")}"`); } catch (e2) {} } };
K.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
K.safeName = (s) => String(s).replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 80) || "без названия";

K.busy = false;
K.setBusy = (b) => { K.busy = b; document.querySelectorAll(".main").forEach((x) => { if (b) x.disabled = true; }); if (!b && K.onIdle) K.onIdle(); };

// ---------- Premiere ----------
K.host = (code) => new Promise((resolve) => window.__adobe_cep__.evalScript(code, (raw) => {
  try { resolve(JSON.parse(raw)); } catch (e) { resolve({ ok: false, error: "Ответ Premiere: " + raw }); }
}));
K.call = (fn, ...args) => K.host(`${fn}(${args.map((a) => JSON.stringify(a)).join(", ")})`);

K.scan = null;
K.readTimeline = async () => {
  const r = await K.host("ac_scan()");
  if (!r.ok) { K.scan = null; K.$("seqName").textContent = "нет последовательности"; return null; }
  r.seqEnd = Math.max(0, ...r.video.flatMap((t) => t.clips.map((c) => c.end)), ...r.audio.flatMap((t) => t.clips.map((c) => c.end)));
  K.scan = r;
  K.$("seqName").textContent = `${r.seqName} · ${K.fmt(r.seqEnd)}`;
  K.$("seqName").title = `${r.seqName} · ${(1 / r.frameDur).toFixed(2)} к/с · ${r.width}×${r.height} · Premiere ${r.premiere}`;
  return r;
};

// ---------- пресет WAV ----------
K.findWavPreset = () => {
  if (K.cfg.wavPreset && fs.existsSync(K.cfg.wavPreset)) return K.cfg.wavPreset;
  const roots = ["C:\\Program Files\\Adobe", "C:\\Program Files (x86)\\Adobe", path.join(os.homedir(), "Documents", "Adobe")];
  const found = [];
  let seen = 0;
  const walk = (dir, depth) => {
    if (depth > 8 || seen > 300000) return;
    let items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const it of items) {
      seen++;
      const full = path.join(dir, it.name);
      if (it.isDirectory()) walk(full, depth + 1);
      else if (/\.epr$/i.test(it.name) && (/wav|waveform/i.test(it.name) || /57415645/.test(dir))) found.push(full);
    }
  };
  for (const r of roots) if (fs.existsSync(r)) walk(r, 0);
  found.sort((a, b) => (/48/.test(path.basename(b)) - /48/.test(path.basename(a))) || b.localeCompare(a));
  if (found.length) { K.cfg.wavPreset = found[0]; K.saveCfg(); }
  return found[0] || null;
};
K.pickFile = (title, exts) => {
  try { const r = window.cep.fs.showOpenDialogEx(false, false, title, "", exts); return r && r.data && r.data[0] ? r.data[0] : null; } catch (e) { return null; }
};
K.pickFolder = (title) => {
  try { const r = window.cep.fs.showOpenDialogEx(false, true, title, ""); return r && r.data && r.data[0] ? r.data[0] : null; } catch (e) { return null; }
};

// Выгрузка звука последовательности (ti >= 0 — одна дорожка) в WAV через Premiere
K.exportWav = async (seqId, ti, outPath) => {
  const preset = K.findWavPreset();
  if (!preset) throw new Error("Не найден пресет экспорта WAV. Лог → «Пресет WAV…»");
  await K.sleep(50);
  const r = await K.call("ac_renderTrack", seqId, ti, outPath, preset);
  if (!r.ok) throw new Error(r.error);
  return outPath;
};

// ---------- ffmpeg ----------
K.ffmpeg = (args, onErr) => new Promise((resolve, reject) => {
  const p = spawn(K.FFMPEG, ["-hide_banner", "-nostdin", ...args]);
  let err = "";
  p.stderr.on("data", (d) => { err += d; if (err.length > 200000) err = err.slice(-100000); if (onErr) onErr(String(d)); });
  p.on("error", (e) => reject(new Error("ffmpeg не запустился: " + e.message)));
  p.on("close", (code) => (code === 0 ? resolve(err) : reject(new Error("ffmpeg: " + err.slice(-500)))));
});

// Сведения о файле: длительность, аудиоканалы по потокам, видео (ширина, высота, к/с)
const probeCache = {};
K.probe = (file) => {
  if (probeCache[file]) return Promise.resolve(probeCache[file]);
  return new Promise((resolve) => {
    const p = spawn(K.FFMPEG, ["-hide_banner", "-i", file]);
    let err = "";
    p.stderr.on("data", (d) => (err += d));
    p.on("error", () => resolve(null));
    p.on("close", () => {
      const info = { file, dur: 0, streams: [], video: null, rate: 48000 };
      const d = err.match(/Duration: (\d+):(\d+):([\d.]+)/);
      if (d) info.dur = +d[1] * 3600 + +d[2] * 60 + +d[3];
      const LAYOUT = { mono: 1, stereo: 2, "2.1": 3, "3.0": 3, quad: 4, "4.0": 4, "5.0": 5, "5.1": 6, "5.1(side)": 6, "6.1": 7, "7.1": 8 };
      for (const line of err.split(/\r?\n/)) {
        if (/Stream #\d+:\d+.*Audio:/.test(line)) {
          const m = line.match(/(\d+) Hz, ([^,]+),/);
          let ch = 1;
          if (m) { info.rate = +m[1]; const t = m[2].trim(); const n = t.match(/(\d+) channels/); ch = n ? +n[1] : (LAYOUT[t] || 2); }
          info.streams.push(ch);
        } else if (/Stream #\d+:\d+.*Video:/.test(line) && !/attached pic/.test(line) && !info.video) {
          const wh = line.match(/, (\d{2,5})x(\d{2,5})/);
          const fps = line.match(/([\d.]+) fps/) || line.match(/([\d.]+) tbr/);
          info.video = { w: wh ? +wh[1] : 1920, h: wh ? +wh[2] : 1080, fps: fps ? +fps[1] : 25 };
        }
      }
      info.channels = info.streams.reduce((a, b) => a + b, 0);
      probeCache[file] = info;
      resolve(info);
    });
  });
};

// Громкость файла по окнам (дБ), моно-сумма. rate — окон в секунду. maxSec — читать только начало.
K.envelope = (file, rate, onProg, maxSec) => new Promise((resolve, reject) => {
  const SR = 8000, SPW = Math.round(SR / rate);
  const out = [];
  let sum = 0, cnt = 0, left = null, err = "", samples = 0;
  const args = ["-hide_banner", "-nostdin", "-v", "error"];
  if (maxSec) args.push("-t", String(maxSec));
  args.push("-i", file, "-vn", "-ac", "1", "-ar", String(SR), "-f", "s16le", "-");
  const p = spawn(K.FFMPEG, args);
  p.stdout.on("data", (chunk) => {
    let buf = left ? Buffer.concat([left, chunk]) : chunk;
    const usable = buf.length - (buf.length % 2);
    if (buf.byteOffset % 2) buf = Buffer.from(buf);
    const s16 = new Int16Array(buf.buffer, buf.byteOffset, usable / 2);
    for (let i = 0; i < s16.length; i++) {
      sum += s16[i] * s16[i];
      if (++cnt === SPW) { out.push(10 * Math.log10(sum / cnt / 1073741824 + 1e-10)); sum = 0; cnt = 0; }
    }
    samples += s16.length;
    left = usable < buf.length ? Buffer.from(buf.subarray(usable)) : null;
    if (onProg) onProg(samples / SR);
  });
  p.stderr.on("data", (d) => (err += d));
  p.on("error", (e) => reject(new Error("ffmpeg не запустился: " + e.message)));
  p.on("close", (code) => {
    if (code !== 0 && !out.length) return reject(new Error("ffmpeg: " + err.slice(-400)));
    resolve(Float32Array.from(out));
  });
});

// Кэш массивов Float32 на диске
K.cacheGet = (key) => {
  const f = path.join(K.CACHE, key + ".f32");
  if (!fs.existsSync(f)) return null;
  const b = fs.readFileSync(f);
  return new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.length));
};
K.cachePut = (key, arr) => { try { fs.writeFileSync(path.join(K.CACHE, key + ".f32"), Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength)); } catch (e) {} };
K.hash = (...parts) => crypto.createHash("sha1").update(parts.join("~")).digest("hex");
K.fileKey = (file) => { try { const st = fs.statSync(file); return [file, st.size, st.mtimeMs].join("|"); } catch (e) { return file; } };

// ---------- HTTPS (распознавание речи) ----------
// POST с JSON (Claude API)
K.postJSON = (url, headers, body) => new Promise((resolve, reject) => {
  const data = Buffer.from(JSON.stringify(body), "utf8");
  const u = new URL(url);
  const req = https.request({ method: "POST", hostname: u.hostname, path: u.pathname + u.search,
    headers: Object.assign({ "Content-Type": "application/json", "Content-Length": data.length }, headers), timeout: 300000 }, (res) => {
    const chunks = [];
    res.on("data", (c) => chunks.push(c));
    res.on("end", () => {
      const text = Buffer.concat(chunks).toString("utf8");
      if (res.statusCode >= 300) return reject(new Error(`HTTP ${res.statusCode}: ${text.slice(0, 300)}`));
      try { resolve(JSON.parse(text)); } catch (e) { reject(new Error("Ответ не JSON: " + text.slice(0, 200))); }
    });
  });
  req.on("timeout", () => req.destroy(new Error("Сервис не ответил за 5 минут")));
  req.on("error", reject);
  req.end(data);
});

// Запрос к серверу kök: JSON туда и обратно. Ошибка содержит .status и .data (ответ сервера).
K.request = (method, url, headers, body, timeoutMs) => new Promise((resolve, reject) => {
  const u = new URL(url);
  const lib = u.protocol === "http:" ? require("http") : https;
  const data = body === undefined ? null : Buffer.from(JSON.stringify(body), "utf8");
  const h = Object.assign({ Accept: "application/json" }, data ? { "Content-Type": "application/json", "Content-Length": data.length } : {}, headers || {});
  const req = lib.request({ method, hostname: u.hostname, port: u.port || undefined, path: u.pathname + u.search, headers: h, timeout: timeoutMs || 20000 }, (res) => {
    const chunks = [];
    res.on("data", (c) => chunks.push(c));
    res.on("end", () => {
      const text = Buffer.concat(chunks).toString("utf8");
      let json = null;
      try { json = JSON.parse(text); } catch (e) {}
      if (res.statusCode >= 300 || !json) {
        const err = new Error((json && json.error) || `Сервер ответил ${res.statusCode}${json ? "" : ": " + text.slice(0, 120)}`);
        err.status = res.statusCode; err.data = json;
        return reject(err);
      }
      resolve(json);
    });
  });
  req.on("timeout", () => req.destroy(new Error("Сервер kök не ответил — проверьте интернет")));
  req.on("error", (e) => reject(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET/.test(e.code || e.message) ? Object.assign(new Error("Нет связи с сервером kök (" + (e.code || e.message) + ")"), { offline: true }) : e));
  req.end(data || undefined);
});

// Версия плагина и канал обновлений: main — для клиентов, test — тестовая среда (ставит тестовый установщик)
K.VERSION = (() => { try { return (fs.readFileSync(path.join(K.EXT, "CSXS", "manifest.xml"), "utf8").match(/ExtensionBundleVersion="([^"]+)"/) || [])[1] || "0"; } catch (e) { return "0"; } })();
K.CHANNEL = (() => { try { return fs.readFileSync(path.join(K.WORK, "channel.txt"), "utf8").trim() === "test" ? "test" : "main"; } catch (e) { return "main"; } })();

// Скачать файл по https с переадресациями (GitHub отдаёт файлы через redirect)
K.download = (url, dest, onProg, redirects) => new Promise((resolve, reject) => {
  const req = https.get(url, { headers: { "User-Agent": "kok-edit/" + K.VERSION } }, (res) => {
    if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
      res.resume();
      if ((redirects || 0) > 6) return reject(new Error("Слишком много переадресаций"));
      return resolve(K.download(new URL(res.headers.location, url).toString(), dest, onProg, (redirects || 0) + 1));
    }
    if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode}: ${url}`)); }
    const total = +res.headers["content-length"] || 0;
    let got = 0;
    const part = dest + ".part";
    const out = fs.createWriteStream(part);
    res.on("data", (c) => { got += c.length; if (onProg) onProg(got, total); });
    res.pipe(out);
    out.on("finish", () => out.close(() => { try { fs.renameSync(part, dest); resolve(dest); } catch (e) { reject(e); } }));
    res.on("error", reject);
    out.on("error", reject);
  });
  req.on("error", (e) => reject(Object.assign(new Error("Нет связи с " + new URL(url).hostname), { offline: true })));
  req.setTimeout(60000, () => req.destroy(new Error("Сервер не отвечает")));
});
K.getText = async (url) => {
  const f = path.join(K.CACHE, "dl_" + crypto.randomBytes(6).toString("hex"));
  await K.download(url, f);
  try { return fs.readFileSync(f, "utf8"); } finally { try { fs.unlinkSync(f); } catch (e) {} }
};

K.postMultipart = (url, headers, fields, file) => new Promise((resolve, reject) => {
  const boundary = "----kok" + crypto.randomBytes(8).toString("hex");
  const parts = [];
  for (const [k, v] of fields) parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  if (file) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${file.field}"; filename="${path.basename(file.path)}"\r\nContent-Type: ${file.type}\r\n\r\n`));
    parts.push(fs.readFileSync(file.path));
    parts.push(Buffer.from("\r\n"));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`));
  const body = Buffer.concat(parts);
  const u = new URL(url);
  const req = https.request({
    method: "POST", hostname: u.hostname, path: u.pathname + u.search,
    headers: Object.assign({ "Content-Type": `multipart/form-data; boundary=${boundary}`, "Content-Length": body.length }, headers),
    timeout: 300000,
  }, (res) => {
    const chunks = [];
    res.on("data", (c) => chunks.push(c));
    res.on("end", () => {
      const text = Buffer.concat(chunks).toString("utf8");
      if (res.statusCode >= 300) return reject(new Error(`HTTP ${res.statusCode}: ${text.slice(0, 300)}`));
      try { resolve(JSON.parse(text)); } catch (e) { reject(new Error("Ответ не JSON: " + text.slice(0, 200))); }
    });
  });
  req.on("timeout", () => req.destroy(new Error("Сервис не ответил за 5 минут")));
  req.on("error", reject);
  req.end(body);
});

// ---------- переключатели .seg (общий обработчик) ----------
// data-key внутри секции модуля → K.cfg[модуль][key]; модуль задаётся K.modules[id].cfgKey
K.modules = {};
K.renderSegs = (root, store) => {
  root.querySelectorAll(".seg[data-key]").forEach((seg) => {
    seg.querySelectorAll("button").forEach((b) => b.classList.toggle("on", String(store[seg.dataset.key]) === b.dataset.v));
  });
};

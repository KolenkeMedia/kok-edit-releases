// kök Edit — связь с kök: правки клиента маркерами на таймлайне, отметка «сделано», учёт времени монтажа.
// Время считается само, пока панель открыта: активная минута — если в Premiere что-то меняется (плейхед, клипы, длина).
(function () {
  const { $, esc, log, status, fmt } = K;
  const DEFAULTS = { server: K.CHANNEL === "test" ? "https://test.kok.blue" : "https://kok.blue", contact: "", token: "", me: null, links: {}, offset: 0, track: true };
  const c = () => K.cfg.kok;
  K.cfg.kok = K.cfg.kok || {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (k !== "server" && c()[k] === undefined) c()[k] = v;
  if (c().server === "https://test.msng.app") c().server = ""; // тестовая CRM переехала на test.kok.blue
  if (c().server === "https://kok.blue" && K.CHANNEL === "test") c().server = "";
  const PREFIX = "kök правка: ";
  const IDLE = 5 * 60; // без действий дольше 5 минут — пауза
  const TICK = 5;
  const TIME_FILE = K.path.join(K.WORK, "time.json");

  let codeSent = false, projects = null, items = null, itemsFor = "", act = null, loading = false, errText = "";

  // ---------- сервер ----------
  const base = () => String(c().server || DEFAULTS.server).trim().replace(/\/+$/, "");
  async function api(method, path, body) {
    try {
      return await K.request(method, base() + "/api/miniapp" + path, { "x-web-session": c().token }, body);
    } catch (e) {
      if (e.status === 401) { c().token = ""; c().me = null; K.saveCfg(); render(); throw new Error("Вход в kök истёк — войдите снова."); }
      throw e;
    }
  }

  // ---------- учёт времени ----------
  let T = { chunks: [] };
  try { T = JSON.parse(K.fs.readFileSync(TIME_FILE, "utf8")); if (!Array.isArray(T.chunks)) T.chunks = []; } catch (e) {}
  const saveTime = () => { try { K.fs.writeFileSync(TIME_FILE, JSON.stringify(T)); } catch (e) {} };
  let cur = null, lastSig = "", lastActive = 0, lastTick = Date.now() / 1000, inflight = false, sending = false, lastSave = 0, lastFlush = 0;
  const linkOf = (pp) => (pp && c().links[pp]) || null;
  const uuid = () => K.crypto.randomBytes(12).toString("hex");

  async function tick() {
    const now = Date.now() / 1000, dt = Math.min(15, now - lastTick);
    lastTick = now;
    if (c().track === false || inflight) return;
    let pp = act ? act.path : "";
    if (K.busy) lastActive = now; // панель сама работает по просьбе монтажёра — это тоже работа
    else {
      inflight = true;
      try { act = await K.call("ac_activity"); } catch (e) { act = null; }
      inflight = false;
      if (!act || !act.ok) return;
      if (act.path !== pp && current() === "kok") { render(); guard(() => loadItems(false)); }
      pp = act.path;
      const sig = [act.path, act.sig, Math.round((act.cti || 0) * 10)].join("|");
      if (sig !== lastSig) { if (lastSig) lastActive = now; lastSig = sig; }
    }
    if (!pp || now - lastActive > IDLE) { cur = null; return; }
    if (!cur || cur.prproj !== pp || now - cur.lastAt > IDLE || cur.sec > 3600) {
      const l = linkOf(pp);
      cur = { id: uuid(), prproj: pp, projectId: l ? l.id : null, sec: 0, sent: 0, startedAt: Math.round(now - dt), endedAt: Math.round(now), lastAt: now };
      T.chunks.push(cur);
    }
    cur.sec += dt; cur.endedAt = Math.round(now); cur.lastAt = now;
    if (now - lastSave > 30) { lastSave = now; prune(); saveTime(); }
    if (now - lastFlush > 120) { lastFlush = now; flush(); }
    if (current() === "kok") renderTime();
  }
  function prune() {
    const old = Date.now() / 1000 - 60 * 86400;
    T.chunks = T.chunks.filter((x) => x === cur || x.endedAt > old || (x.projectId && x.sec - x.sent > 1));
  }
  async function flush() {
    if (sending || !c().token) return;
    sending = true;
    try {
      for (const x of T.chunks) {
        if (!x.projectId || x.sec - x.sent < 30) continue;
        const sec = Math.round(x.sec);
        try {
          await api("POST", "/edit-time", { id: x.id, projectId: x.projectId, sec, startedAt: x.startedAt * 1000, endedAt: x.endedAt * 1000, device: K.os.hostname(), file: K.path.basename(x.prproj) });
          x.sent = sec;
        } catch (e) {
          if (e.offline || /истёк/.test(e.message)) break;
          if (e.status === 403 || e.status === 404) { x.sent = sec; x.rejected = e.message; } // не наш проект — не долбим сервер
          else break;
        }
      }
      saveTime();
    } finally { sending = false; }
  }
  const sum = (f) => T.chunks.filter(f).reduce((a, x) => a + x.sec, 0);
  const hours = (sec) => { const m = Math.round(sec / 60), h = Math.floor(m / 60); return h ? `${h} ч ${m % 60} мин` : `${m} мин`; };
  setInterval(tick, TICK * 1000);
  window.addEventListener("beforeunload", () => { prune(); saveTime(); });

  // ---------- отрисовка ----------
  const current = () => K.cfg.screen;
  function render() {
    const logged = !!c().token;
    $("kk-login").classList.toggle("hidden", logged);
    $("kk-main").classList.toggle("hidden", !logged);
    $("kk-server").value = c().server || DEFAULTS.server;
    $("kk-contact").value = c().contact;
    $("kk-codeRow").classList.toggle("hidden", !codeSent);
    $("kk-me").textContent = c().me ? `${c().me.name}${c().me.title ? " · " + c().me.title : ""}` : "";
    $("kk-track").checked = c().track !== false;
    const pp = act && act.path;
    $("kk-prproj").textContent = pp ? K.path.basename(pp) : "проект Premiere не сохранён";
    const l = linkOf(pp);
    const sel = $("kk-project");
    if (projects) {
      const opts = projects.map((p) => `<option value="${esc(p.id)}">${esc(label(p))}</option>`);
      if (l && !projects.some((p) => p.id === l.id)) opts.unshift(`<option value="${esc(l.id)}">${esc(l.name)}</option>`);
      sel.innerHTML = `<option value="">— не привязан —</option>` + opts.join("");
    } else sel.innerHTML = l ? `<option value="${esc(l.id)}">${esc(l.name)}</option>` : `<option value="">${loading ? "загружаю…" : "— нажмите ⟳ —"}</option>`;
    sel.value = l ? l.id : "";
    sel.disabled = !pp || K.busy;
    $("kk-revCard").classList.toggle("hidden", !l);
    $("kk-offset").value = c().offset || 0;
    renderItems();
    renderTime();
    $("kk-err").textContent = errText;
  }
  const label = (p) => [p.name, p.title || p.packageName, p.statusLabel ? p.statusLabel.replace(/^\S+\s/, "") : ""].filter(Boolean).join(" · ");
  const secOf = (it) => {
    if (it.tSec !== null && it.tSec !== undefined) return +it.tSec;
    if (!it.timecode) return null;
    const v = K.TC.tcToSec(String(it.timecode).split(/[–—-]/)[0].trim());
    return isFinite(v) ? v : null;
  };
  function renderItems() {
    const box = $("kk-items");
    if (!items) { box.innerHTML = `<div class="small-text">${loading ? "Загружаю…" : "Нет данных"}</div>`; $("kk-marks").disabled = true; return; }
    if (!items.length) { box.innerHTML = `<div class="small-text">Правок нет — клиент ещё не прислал или все отмечены в другом круге.</div>`; $("kk-marks").disabled = true; return; }
    const left = items.filter((x) => !x.done).length;
    $("kk-revSum").textContent = left ? `осталось ${left} из ${items.length}` : `все ${items.length} сделаны ✓`;
    box.innerHTML = items.map((x, i) => {
      const t = secOf(x);
      return `<div class="li ${x.done ? "off" : ""}"><input type="checkbox" data-kk-done="${i}" ${x.done ? "checked" : ""} ${K.busy ? "disabled" : ""}>
        ${t !== null ? `<span class="tc" data-kk-go="${t}" style="cursor:pointer" title="К месту на таймлайне">${esc(x.timecode || fmt(t))}</span>` : `<span class="tc">весь ролик</span>`}
        <span class="nm" style="white-space:normal">${esc(x.text)}${x.pmNote ? `<br><span class="small-text">💬 ${esc(x.pmNote)}</span>` : ""}${x.files && x.files.length ? `<br><span class="small-text">📎 ${x.files.length} файл(а) — в kök</span>` : ""}${x.link ? `<br><a href="#" class="small-text" data-kk-url="${esc(x.link)}">ссылка</a>` : ""}</span></div>`;
    }).join("");
    $("kk-marks").disabled = K.busy || !items.some((x) => secOf(x) !== null);
  }
  function renderTime() {
    const pp = act && act.path, l = linkOf(pp);
    const day = new Date(); day.setHours(0, 0, 0, 0);
    const d0 = day.getTime() / 1000;
    const today = sum((x) => x.prproj === pp && x.endedAt >= d0);
    const proj = l ? sum((x) => x.projectId === l.id) : sum((x) => x.prproj === pp);
    const unsent = T.chunks.some((x) => x.projectId && !x.rejected && x.sec - x.sent >= 30);
    $("kk-timeToday").textContent = pp ? hours(today) : "—";
    $("kk-timeTotal").textContent = pp ? hours(proj) : "—";
    const idle = !lastActive || Date.now() / 1000 - lastActive > IDLE;
    $("kk-timeState").textContent = c().track === false ? "учёт выключен" : !pp ? "сохраните проект Premiere" : idle ? "пауза — нет действий" : "идёт ●";
    $("kk-timeState").className = c().track !== false && pp && !idle ? "good" : "small-text";
    const rej = T.chunks.find((x) => x.rejected && x.prproj === pp);
    $("kk-timeNote").textContent = !l ? "Привяжите проект — время уйдёт в kök, включая уже накопленное." : rej ? "kök не принял время: " + rej.rejected : !c().token ? "" : unsent ? "часть ещё не отправлена — уйдёт в течение пары минут" : "отправляется в kök автоматически";
  }

  // ---------- действия ----------
  async function guard(fn) {
    errText = "";
    try { await fn(); } catch (e) { errText = e.message; status(e.message, "err"); }
    render();
  }
  $("kk-send").onclick = () => guard(async () => {
    c().server = $("kk-server").value.trim() || DEFAULTS.server;
    c().contact = $("kk-contact").value.trim();
    K.saveCfg();
    if (!c().contact) throw new Error("Введите почту, на которую зарегистрированы в kök");
    const r = await K.request("POST", base() + "/api/web/login/contact", {}, { contact: c().contact });
    codeSent = true;
    status(r.via ? `Код отправлен: ${r.via}` : "Код отправлен — проверьте почту", "good");
    setTimeout(() => $("kk-code").focus(), 50);
  });
  $("kk-verify").onclick = () => guard(async () => {
    const code = $("kk-code").value.trim();
    if (!code) throw new Error("Введите код из письма");
    const r = await K.request("POST", base() + "/api/web/login/contact/verify", { "User-Agent": `kök Edit (Premiere Pro) ${K.os.hostname()}` }, { contact: c().contact, code });
    c().token = r.token; codeSent = false; K.saveCfg();
    try { const me = await api("GET", "/me"); c().me = { name: me.name, title: me.title, roles: me.roles }; K.saveCfg(); } catch (e) {}
    status("Вход выполнен", "good");
    await loadProjects();
    flush();
  });
  $("kk-logout").onclick = () => { c().token = ""; c().me = null; projects = null; items = null; K.saveCfg(); render(); };
  $("kk-reload").onclick = () => guard(async () => { await loadProjects(); await loadItems(true); });
  $("kk-track").onchange = (e) => { c().track = e.target.checked; K.saveCfg(); if (!c().track) cur = null; render(); };
  $("kk-offset").onchange = (e) => { c().offset = +e.target.value || 0; K.saveCfg(); };
  $("kk-project").onchange = (e) => guard(async () => {
    const pp = act && act.path;
    if (!pp) return;
    const id = e.target.value;
    if (!id) { delete c().links[pp]; K.saveCfg(); items = null; return; }
    const p = (projects || []).find((x) => x.id === id);
    c().links[pp] = { id, name: p ? label(p) : id };
    K.saveCfg();
    // время, накопленное до привязки, тоже уходит в этот проект
    let moved = 0;
    for (const x of T.chunks) if (x.prproj === pp && !x.projectId) { x.projectId = id; moved += x.sec; }
    if (cur && cur.prproj === pp) cur.projectId = id;
    saveTime();
    if (moved >= 60) log(`Накопленное время ${hours(moved)} уйдёт в kök по проекту «${c().links[pp].name}»`);
    await loadItems(true);
    flush();
  });

  $("scr-kok").addEventListener("change", (e) => {
    const i = e.target.dataset.kkDone;
    if (i === undefined || !items) return;
    const it = items[+i], want = e.target.checked;
    it.done = want; renderItems();
    api("POST", "/revision-items/" + encodeURIComponent(it.id), { done: want })
      .then(() => { status(want ? "Отмечено в kök: сделано" : "Снята отметка в kök", "good"); if (K.scan && hasMarks) placeMarks(true); })
      .catch((err) => { it.done = !want; renderItems(); status(err.message, "err"); });
  });
  $("scr-kok").addEventListener("click", (e) => {
    const g = e.target.closest("[data-kk-go]");
    if (g && K.scan) { K.call("ac_setPlayhead", K.scan.seqId, +g.dataset.kkGo + (+c().offset || 0)); return; }
    const u = e.target.closest("[data-kk-url]");
    if (u) { e.preventDefault(); K.openURL(u.dataset.kkUrl); }
  });

  async function loadProjects() {
    if (!c().token) return;
    loading = true; render();
    try { projects = await api("GET", "/projects/my-edits"); } finally { loading = false; }
  }
  async function loadItems(force) {
    const l = linkOf(act && act.path);
    if (!l || !c().token) { items = null; return; }
    if (!force && itemsFor === l.id && items) return;
    loading = true; renderItems();
    try { const r = await api("GET", `/projects/${encodeURIComponent(l.id)}/revision-items`); items = r.items || []; itemsFor = l.id; }
    finally { loading = false; }
  }
  let hasMarks = false;
  async function placeMarks(quiet) {
    if (!K.scan || !items) return;
    const off = +c().offset || 0;
    await K.call("ac_removeMarkers", K.scan.seqId, PREFIX);
    const list = items.map((x) => ({ x, t: secOf(x) })).filter((o) => o.t !== null).map((o) => ({
      t: +(o.t + off).toFixed(3), d: 0.5, c: o.x.done ? 0 : 1,
      n: PREFIX + (o.x.done ? "✓ " : "") + o.x.text.slice(0, 200) + (o.x.pmNote ? ` (менеджер: ${o.x.pmNote.slice(0, 120)})` : ""),
    }));
    for (let i = 0; i < list.length; i += 100) await K.call("ac_markers", K.scan.seqId, list.slice(i, i + 100));
    hasMarks = true;
    const out = list.filter((m) => m.t > K.scan.seqEnd + 1).length;
    if (!quiet) status(`Маркеры правок на «${K.scan.seqName}»: ${list.length}${out ? `, ${out} за концом таймлайна — проверьте сдвиг` : ""}. Красные — сделать, зелёные — сделано.`, out ? "err" : "good");
  }
  $("kk-marks").onclick = () => guard(async () => { await K.readTimeline(); if (!K.scan) throw new Error("Откройте последовательность ролика"); await placeMarks(false); });
  $("kk-clearMarks").onclick = async () => { if (!K.scan) await K.readTimeline(); if (!K.scan) return; const r = await K.call("ac_removeMarkers", K.scan.seqId, PREFIX); hasMarks = false; status(r.ok ? `Удалено маркеров: ${r.n}` : r.error, r.ok ? "good" : "err"); };

  K.modules.kok = {
    title: "kök: правки и время", cfgKey: "kok", needsTimeline: false,
    async onShow() {
      try { act = await K.call("ac_activity"); } catch (e) {}
      render();
      if (c().token) guard(async () => { if (!projects) await loadProjects(); await loadItems(false); });
    },
    render,
  };
})();

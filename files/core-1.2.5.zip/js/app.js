// kök Edit — навигация между разделами и общие кнопки.
(function () {
  const { $, status } = K;
  let current = "home";

  function show(id) {
    // без активной лицензии открыт только экран входа
    if (id !== "license" && K.lic && !K.lic.ok()) { if (id !== "home") K.cfg.screenAfterLogin = id; id = "license"; }
    current = id;
    document.querySelectorAll("section").forEach((s) => s.classList.toggle("hidden", s.id !== "scr-" + id));
    const mod = K.modules[id];
    $("back").classList.toggle("hidden", id === "home" || (id === "license" && !K.lic.ok()));
    $("logo").classList.toggle("hidden", id !== "home");
    $("screenTitle").classList.toggle("hidden", id === "home");
    $("screenTitle").textContent = mod ? mod.title : "";
    $("refresh").classList.toggle("hidden", id === "home" || id === "assemble" || id === "kok" || id === "license");
    $("seqName").classList.toggle("hidden", !mod || !mod.needsTimeline);
    $("logCard").classList.toggle("hidden", id === "home" || id === "license");
    status("");
    if (id !== "license") { K.cfg.screen = id; K.saveCfg(); }
    if (mod) {
      if (mod.onShow) mod.onShow();
      if (mod.needsTimeline) refresh();
      else mod.render();
    }
  }

  async function refresh() {
    if (K.busy) return;
    const r = await K.readTimeline();
    K.report = r ? [`Последовательность «${r.seqName}», ${K.fmt(r.seqEnd)}, ${(1 / r.frameDur).toFixed(2)} к/с`] : [];
    if (r && K.FFMPEG === "ffmpeg") K.log("ffmpeg.exe не найден в папке расширения — используется системный.");
    const mod = K.modules[current];
    if (mod && mod.onScan) mod.onScan(); else if (mod) mod.render();
  }

  // общие переключатели: .seg[data-key] внутри раздела → настройки этого раздела
  document.addEventListener("click", (e) => {
    const b = e.target.closest(".seg button");
    if (b) {
      const sec = b.closest("section"), mod = sec && K.modules[sec.id.replace("scr-", "")];
      if (!mod) return;
      K.cfg[mod.cfgKey][b.parentElement.dataset.key] = b.dataset.v;
      K.saveCfg();
      if (mod.onSeg) mod.onSeg(); else mod.render();
      return;
    }
    const tile = e.target.closest("[data-go]");
    if (tile) show(tile.dataset.go);
  });
  K.show = show;
  K.onIdle = () => { const m = K.modules[current]; if (m) m.render(); };

  $("back").onclick = () => show("home");
  $("crmLink").onclick = (e) => { e.preventDefault(); K.openURL("https://kok.blue"); };
  $("refresh").onclick = refresh;
  $("saveLog").onclick = () => K.log("Лог: " + K.saveLog("manual"));
  $("pickWav").onclick = () => { const f = K.pickFile("Пресет экспорта WAV (.epr)", ["epr"]); if (f) { K.cfg.wavPreset = f; K.saveCfg(); status("Пресет WAV: " + K.path.basename(f), "good"); } };
  $("clearCache").onclick = () => {
    let n = 0;
    try { for (const f of K.fs.readdirSync(K.CACHE)) { try { K.fs.unlinkSync(K.path.join(K.CACHE, f)); n++; } catch (e) {} } } catch (e) {}
    status(`Кэш очищен (${n} файлов)`, "good");
  };

  // следим за сменой открытой последовательности
  setInterval(async () => {
    if (K.busy || current === "home") return;
    const mod = K.modules[current];
    if (!mod || !mod.needsTimeline) return;
    const r = await K.call("ac_activeId");
    if (r.ok && r.id && (!K.scan || r.id !== K.scan.seqId)) refresh();
  }, 2000);

  // старт: сначала лицензия (по сохранённой — сразу, затем проверка на сервере)
  // лицензия стала активной (вход, продление, «Проверить снова») — сразу открываем модули, а не держим на экране аккаунта
  let wasOk = K.lic.ok();
  K.onLicense = (ok) => {
    if (!ok && current !== "license") show("license");
    else if (ok && !wasOk && current === "license") {
      const next = K.cfg.screenAfterLogin || K.cfg.screen;
      show(K.modules[next] && next !== "license" ? next : "home");
    }
    wasOk = ok;
  };
  if (wasOk) show(K.modules[K.cfg.screen] && K.cfg.screen !== "license" ? K.cfg.screen : "home");
  else show("license");
  K.licStart();
})();

// kök Edit — AutoCam: смена камер по голосу + глушение молчащих микрофонов.
(function () {
  const { $, esc, log, status, fmt, P } = K;
  const COLORS = ["#3a7bfd", "#35c27a", "#f0b429", "#e05ca8", "#8b6cf6", "#22b8cf", "#ef5350", "#9e9e9e"];
  const RHYTHM = { calm: 2.5, std: 1.5, fast: 1.0 };
  const WIDE = { never: 0, rare: 35, mid: 20, often: 12 };
  const SENS = { 1: 10, 2: 8, 3: 6, 4: 5, 5: 4 };
  const LEAD = 0.1;
  const DEFAULTS = { mics: {}, cams: {}, rhythm: "std", wideFreq: "mid", cutaway: "wide", gate: "off", mode: "disable", delay: 0, minReply: 0.5, markers: false, minShotOverride: "", pauseSec: 3, pauseMode: "wide", multiToWide: "1", sens: 3 };
  const c = () => K.cfg.ac;
  for (const [k, v] of Object.entries(DEFAULTS)) if (c()[k] === undefined) c()[k] = JSON.parse(JSON.stringify(v));
  if ((c().ver || 0) < 8) { c().pauseSec = 3; c().ver = 8; }

  let plan = null;
  const scan = () => K.scan;
  const usedV = () => (scan() ? scan().video.filter((t) => t.clips.length) : []);
  const usedA = () => (scan() ? scan().audio.filter((t) => t.clips.length) : []);
  const speakers = () => usedA().filter((t) => c().mics[t.index] && c().mics[t.index].use).map((t) => t.index);
  const spkName = (mi) => (c().mics[mi] && c().mics[mi].name) || `A${mi + 1}`;
  K.acSpeakers = speakers; K.acSpkName = spkName; K.acUsedA = usedA;

  function ensureDefaults() {
    if (!scan()) return;
    let n = 0;
    for (const t of usedA()) {
      if (!c().mics[t.index]) {
        const cover = t.clips.reduce((s, x) => s + (x.end - x.start), 0) / (scan().seqEnd || 1);
        c().mics[t.index] = { use: cover > 0.5, name: "" };
      }
      if (c().mics[t.index].use) { n++; if (!c().mics[t.index].name) c().mics[t.index].name = `Спикер ${n}`; }
    }
    const spk = speakers();
    usedV().forEach((t, i) => {
      if (!c().cams[t.index]) c().cams[t.index] = i < spk.length ? [spk[i]] : spk.slice();
      c().cams[t.index] = c().cams[t.index].filter((m) => spk.includes(m));
    });
  }
  K.acEnsure = ensureDefaults;

  function render() {
    const tracksA = usedA();
    $("ac-mics").innerHTML = !scan() ? `<div class="small-text">Откройте последовательность подкаста.</div>` : !tracksA.length ? `<div class="small-text">На таймлайне нет звука.</div>` :
      tracksA.map((t) => {
        const m = c().mics[t.index];
        return `<div class="row ${m.use ? "" : "off"}">
          <input type="checkbox" data-mic-use="${t.index}" ${m.use ? "checked" : ""}>
          <div class="tag">A${t.index + 1}</div>
          <input type="text" class="grow" data-mic-name="${t.index}" value="${esc(m.name)}" placeholder="Имя спикера" ${m.use ? "" : "disabled"}></div>`;
      }).join("");
    const tracksV = usedV(), spk = speakers();
    $("ac-cams").innerHTML = !tracksV.length ? `<div class="small-text">—</div>` : tracksV.map((t) => {
      const on = c().cams[t.index] || [];
      const kind = !on.length ? "не используется" : on.length === spk.length && spk.length > 1 ? "общий" : on.length > 1 ? "двойной" : "крупный";
      return `<div class="row"><div class="tag">V${t.index + 1}</div>
        <div class="chips">${spk.map((m) => `<button class="chip ${on.includes(m) ? "on" : ""}" data-cam="${t.index}" data-spk="${m}">${esc(spkName(m))}</button>`).join("")}</div>
        <span class="badge">${kind}</span></div>`;
    }).join("");
    K.renderSegs($("scr-autocam"), c());
    $("ac-delay").value = c().delay; $("ac-minReply").value = c().minReply; $("ac-markers").checked = !!c().markers;
    $("ac-minShotOverride").value = c().minShotOverride; $("ac-pauseSec").value = c().pauseSec;
    $("ac-pauseMode").value = c().pauseMode; $("ac-multiToWide").value = c().multiToWide; $("ac-sens").value = c().sens;
    const ready = scan() && spk.length > 0 && Object.values(c().cams).some((a) => a.length);
    $("ac-create").disabled = !ready || K.busy;
    $("ac-apply").disabled = K.busy || !plan;
  }

  const hideResult = () => { plan = null; $("ac-result").classList.add("hidden"); };
  const changed = () => { hideResult(); K.saveCfg(); render(); };

  // ---------- события ----------
  $("scr-autocam").addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.micUse !== undefined) { c().mics[t.dataset.micUse].use = t.checked; ensureDefaults(); }
    else if (t.dataset.micName !== undefined) c().mics[t.dataset.micName].name = t.value;
    else if (t.id && t.id.startsWith("ac-") && ["delay", "minReply", "minShotOverride", "pauseSec", "pauseMode", "multiToWide", "sens"].includes(t.id.slice(3))) c()[t.id.slice(3)] = t.value;
    else if (t.id === "ac-markers") c().markers = t.checked;
    else return;
    changed();
  });
  $("scr-autocam").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b || b.dataset.cam === undefined) return;
    const list = c().cams[b.dataset.cam] || (c().cams[b.dataset.cam] = []);
    const m = +b.dataset.spk, i = list.indexOf(m);
    if (i >= 0) list.splice(i, 1); else list.push(m);
    changed();
  });

  // ---------- шаблоны шоу ----------
  const presetFile = (name) => K.path.join(K.PRESETS, K.safeName(name) + ".json");
  function listPresets() {
    let names = [];
    try { names = K.fs.readdirSync(K.PRESETS).filter((f) => f.endsWith(".json")).map((f) => f.slice(0, -5)); } catch (e) {}
    const cur = $("ac-preset").value;
    $("ac-preset").innerHTML = `<option value="">— без шаблона —</option>` + names.map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
    if (names.includes(cur)) $("ac-preset").value = cur;
  }
  $("ac-presetNew").onclick = () => { $("ac-presetNameRow").classList.toggle("hidden"); $("ac-presetName").value = $("ac-preset").value; $("ac-presetName").focus(); };
  $("ac-presetSave").onclick = () => {
    const name = $("ac-presetName").value.trim();
    if (!name) return;
    K.fs.writeFileSync(presetFile(name), JSON.stringify(c(), null, 2));
    $("ac-presetNameRow").classList.add("hidden");
    listPresets(); $("ac-preset").value = K.safeName(name);
    status(`Шаблон «${name}» сохранён`, "good");
  };
  $("ac-preset").onchange = () => {
    const name = $("ac-preset").value;
    if (!name) return;
    try {
      K.cfg.ac = Object.assign(JSON.parse(JSON.stringify(DEFAULTS)), JSON.parse(K.fs.readFileSync(presetFile(name), "utf8")));
      ensureDefaults(); changed();
      status(`Шаблон «${name}» загружен`, "good");
    } catch (e) { status("Не удалось открыть шаблон: " + e.message, "err"); }
  };
  $("ac-presetDel").onclick = () => {
    const name = $("ac-preset").value;
    if (!name) return;
    try { K.fs.unlinkSync(presetFile(name)); } catch (e) {}
    listPresets(); status(`Шаблон «${name}» удалён`);
  };

  // ---------- звук дорожек ----------
  function trackKey(t) {
    const sig = t.clips.map((x) => [x.name, x.start.toFixed(3), x.end.toFixed(3), x.inPoint.toFixed(3), x.path].join("|")).join("#");
    return "track_" + K.hash(scan().seqId, t.index, scan().seqEnd.toFixed(3), sig, P.RATE);
  }
  // Громкость микрофонных дорожек (20 окон/с), с кэшем. Используется и модулем «Звук».
  async function trackLevels(spk, opt) {
    opt = opt || {};
    const T = Math.ceil(scan().seqEnd * P.RATE);
    const levels = spk.map(() => new Float32Array(T).fill(-100));
    const t0 = Date.now();
    let rendered = 0;
    for (let k = 0; k < spk.length; k++) {
      const mi = spk[k], tr = scan().audio[mi], key = trackKey(tr);
      let env = K.cacheGet(key);
      if (env) log(`${spkName(mi)}: A${mi + 1} — из кэша`);
      else {
        const wav = K.path.join(K.CACHE, `A${mi + 1}_${Date.now()}.wav`);
        status(`Premiere выгружает звук ${spkName(mi)} (A${mi + 1}, ${k + 1}/${spk.length})… Premiere может не отвечать.`);
        const tk = Date.now();
        await K.exportWav(scan().seqId, mi, wav);
        const exportSec = (Date.now() - tk) / 1000;
        env = await K.envelope(wav, P.RATE, (sec) => status(`Слушаю ${spkName(mi)}… ${Math.min(99, Math.round(sec / scan().seqEnd * 100))}%`));
        try { K.fs.unlinkSync(wav); } catch (e) {}
        K.cachePut(key, env);
        rendered++;
        log(`${spkName(mi)}: A${mi + 1} — выгрузка ${exportSec.toFixed(0)} с`);
      }
      levels[k].set(env.subarray(0, Math.min(env.length, T)));
    }
    if (rendered) log(`Звук подготовлен за ${((Date.now() - t0) / 1000).toFixed(0)} с`);
    if (!opt.noSameCheck) for (let a = 0; a < spk.length; a++) for (let b = a + 1; b < spk.length; b++) {
      let same = 0, n = 0;
      for (let t = 0; t < T; t += 20) { if (levels[a][t] > -99 || levels[b][t] > -99) { n++; if (Math.abs(levels[a][t] - levels[b][t]) < 0.5) same++; } }
      if (n && same / n > 0.9) throw new Error(`${spkName(spk[a])} и ${spkName(spk[b])} звучат одинаково — проверьте, что на A${spk[a] + 1} и A${spk[b] + 1} разные микрофоны.`);
    }
    return levels;
  }

  // ---------- создать монтаж ----------
  async function create() {
    if (!scan() || K.busy) return;
    K.setBusy(true); hideResult();
    K.report = K.report.slice(0, 1);
    try {
      const spk = speakers();
      const levels = await trackLevels(spk);
      status("Считаю склейки…");
      const camMask = {}, avail = {};
      for (const t of usedV()) {
        let mk = 0;
        (c().cams[t.index] || []).forEach((mi) => { const k = spk.indexOf(mi); if (k >= 0) mk |= 1 << k; });
        if (mk) { camMask[t.index] = mk; avail[t.index] = t.clips.map((x) => [x.start, x.end]).sort((a, b) => a[0] - b[0]); }
      }
      const minShot = parseFloat(c().minShotOverride) || RHYTHM[c().rhythm];
      const minReply = parseFloat(c().minReply) || 0.5;
      const lw = P.labelWindows(levels, { snrDb: 8, excessDb: SENS[c().sens] || 6, multiDensity: 0.6, hangoverSec: 0.6, minReplySec: minReply, multiMinSec: 1.5 });
      spk.forEach((mi, j) => log(`  A${mi + 1} слышит соседей: ` + spk.map((mk, i) => (i === j ? null : `${spkName(mk)} ${lw.bleed[i][j].toFixed(0)} дБ`)).filter(Boolean).join(", ")));
      const segs = P.planShots(lw.labels, lw.mask, {
        nSpk: spk.length, camMask, avail, minShot, maxShot: WIDE[c().wideFreq], cutaway: c().cutaway, cutLen: 3,
        minReply, backtrackSec: 2.0, delay: (parseFloat(c().delay) || 0) - LEAD, multiToWide: c().multiToWide === "1", pauseMode: c().pauseMode,
        pauseSec: parseFloat(c().pauseSec) || 2, seqEnd: scan().seqEnd, frameDur: scan().frameDur,
      });
      const marks = [];
      for (const r of P.toRuns(lw.labels)) {
        if (r.label === -1 || r.len < 10) continue;
        let name;
        if (r.label >= 0) name = spkName(spk[r.label]);
        else { const m = lw.mask[r.from]; name = "Вместе: " + spk.filter((_, k) => m & (1 << k)).map(spkName).join(" + "); }
        marks.push({ t: +(r.from / P.RATE).toFixed(3), d: +(r.len / P.RATE).toFixed(3), n: name, c: r.label >= 0 ? r.label : 7 });
      }
      plan = { segs, avail, seqId: scan().seqId, marks, spk, act: lw.act };
      // откуда взялся общий план: «вместе», паузы или перебивки длинных монологов
      const wideCams = new Set(Object.keys(camMask).map(Number).filter((k) => camMask[k] === (1 << spk.length) - 1));
      const why = { together: 0, pause: 0, cutaway: 0 };
      let total = 0;
      for (const g of segs) {
        total += g.end - g.start;
        if (!wideCams.has(g.cam)) continue;
        let a = 0, b = 0, d = 0;
        for (let t = Math.round(g.start * P.RATE); t < g.end * P.RATE && t < lw.labels.length; t++) { const l = lw.labels[t]; if (l === -2) a++; else if (l === -1) b++; else d++; }
        why[a >= b && a >= d ? "together" : b >= d ? "pause" : "cutaway"] += g.end - g.start;
      }
      const pct = (x) => Math.round((x / (total || 1)) * 100);

      const st = P.stats(segs);
      const camLabel = (cam) => {
        if (cam < 0) return "нет кадра";
        const tags = c().cams[cam] || [];
        return `V${cam + 1} · ${tags.length === spk.length && spk.length > 1 ? "общий" : tags.map(spkName).join(" + ")}`;
      };
      const entries = Object.entries(st.share).map(([k, v]) => [+k, v]).sort((a, b) => a[0] - b[0]);
      $("ac-rCuts").textContent = st.cuts;
      $("ac-rAvg").textContent = st.avgShot.toFixed(1);
      $("ac-rBar").innerHTML = entries.map(([k, v], i) => `<div style="width:${(v * 100).toFixed(2)}%;background:${k < 0 ? "#555" : COLORS[i % COLORS.length]}"></div>`).join("");
      $("ac-rLegend").innerHTML = entries.map(([k, v], i) => `<div><span class="dot" style="background:${k < 0 ? "#555" : COLORS[i % COLORS.length]}"></span>${esc(camLabel(k))}<span class="grow"></span>${(v * 100).toFixed(0)}%</div>`).join("");
      const warns = [];
      spk.forEach((mi, k) => {
        log(`  ${spkName(mi)}: шум ${lw.floors[k].toFixed(0)} дБ, речь ${lw.refs[k].toFixed(0)} дБ`);
        if (lw.refs[k] - lw.floors[k] < 10) warns.push(`${spkName(mi)}: голос плохо отделяется от шума — проверьте, что на дорожке его микрофон.`);
      });
      if (st.uncovered > 0) warns.push(`${st.uncovered.toFixed(1)} с без материала ни на одной камере.`);
      if (!entries.some(([k]) => k >= 0 && (c().cams[k] || []).length === spk.length) && WIDE[c().wideFreq] > 0 && spk.length > 1)
        warns.push("Нет камеры с общим планом — перебивки будут на слушателя.");
      if (wideCams.size && spk.length > 1) {
        const w = pct(why.together + why.pause + why.cutaway);
        $("ac-rWhy").innerHTML = `<span data-tip="«Вместе» — говорят или смеются несколько человек (строже: «Реакция на голос» влево). Перебивки — длинный монолог (реже: «Общий план → Редко»). Паузы — никто не говорит (реже: «Пауза дольше»).">Общий план ${w}%: вместе ${pct(why.together)}% · перебивки ${pct(why.cutaway)}% · паузы ${pct(why.pause)}%</span>`;
        log(`Общий план ${w}%: вместе ${pct(why.together)}%, перебивки ${pct(why.cutaway)}%, паузы ${pct(why.pause)}%`);
      } else $("ac-rWhy").innerHTML = "";
      $("ac-rWarn").innerHTML = warns.map((w) => `<div class="warn">⚠ ${esc(w)}</div>`).join("");
      log(`План: ${st.cuts} склеек, средний кадр ${st.avgShot.toFixed(1)} с`);
      $("ac-result").classList.remove("hidden");
      $("ac-result").scrollIntoView({ behavior: "smooth" });
      status("");
    } catch (e) {
      log("ОШИБКА: " + e.message);
      status(e.message, "err");
    }
    K.setBusy(false);
  }

  // ---------- применить ----------
  async function apply() {
    if (!plan || K.busy) return;
    K.setBusy(true);
    $("ac-apply").disabled = true;
    const mode = c().mode;
    log(`\n=== Применяю: ${mode === "remove" ? "удалить лишнее" : "отключить лишнее"} ===`);
    try {
      const srcKey = await K.TR.keyOf(plan.seqId);
      const cl = await K.call("ac_clone", plan.seqId, "AutoCam");
      if (!cl.ok) throw new Error(cl.error);
      log(`Копия: «${cl.name}»`);
      const sigBefore = await K.call("ac_audioSig", cl.id);
      const fd = scan().frameDur;
      for (const cam of Object.keys(plan.avail).map(Number)) {
        const ints = plan.segs.filter((g) => g.cam === cam);
        const clips = plan.avail[cam];
        const inside = (t) => clips.some(([a, b]) => t > a + fd / 2 && t < b - fd / 2);
        const times = [...new Set(ints.flatMap((g) => [g.start, g.end]).map((t) => +t.toFixed(4)))].filter(inside).sort((a, b) => a - b);
        for (let i = 0; i < times.length; i += 50) {
          status(`V${cam + 1}: режу ${Math.min(i + 50, times.length)} из ${times.length}…`);
          const r = await K.call("ac_razor", cl.id, cam, times.slice(i, i + 50));
          if (!r.ok) throw new Error(`V${cam + 1}: ${r.error}`);
        }
        status(`V${cam + 1}: ${mode === "remove" ? "удаляю" : "отключаю"} лишнее…`);
        const r2 = await K.call("ac_states", cl.id, cam, ints.flatMap((g) => [g.start, g.end]), mode);
        if (!r2.ok) throw new Error(`V${cam + 1}: ${r2.error}`);
        log(`  V${cam + 1}: разрезов ${times.length}, в кадре ${r2.on}, ${mode === "remove" ? "удалено" : "отключено"} ${r2.off}`);
      }
      for (const t of usedV()) if (!plan.avail[t.index]) await K.call("ac_states", cl.id, t.index, [], mode);
      const sigAfter = await K.call("ac_audioSig", cl.id);
      const soundOk = !(sigBefore.ok && sigAfter.ok && sigBefore.sig !== sigAfter.sig);
      if (!soundOk) log(`⚠ ЗВУК В КОПИИ ИЗМЕНИЛСЯ\n  до: ${sigBefore.sig}\n  после: ${sigAfter.sig}`);

      // глушение молчащих: ключи громкости на микрофонных дорожках копии
      if (c().gate !== "off") {
        const closedDb = c().gate === "full" ? -100 : -15;
        for (let k = 0; k < plan.spk.length; k++) {
          const mi = plan.spk[k];
          const keys = P.gateKeys(plan.act[k], { closedDb, end: scan().seqEnd }).map(([t, db]) => [+t.toFixed(3), db]);
          status(`Глушу паузы ${spkName(mi)} (${keys.length} ключей)…`);
          const r = await K.call("ac_volumeKeys", cl.id, mi, keys);
          if (!r.ok) { log(`  A${mi + 1}: ключи громкости не поставлены — ${r.error}`); continue; }
          log(`  A${mi + 1}: ключей громкости ${r.added}${r.skipped ? `, пропущено клипов с ручными ключами: ${r.skipped}` : ""}${r.firstKey !== "" ? `, первый ключ ${(+r.firstKey).toFixed(2)} с` : ""}`);
        }
      }

      if (c().markers && plan.marks.length) {
        status(`Ставлю маркеры (${plan.marks.length})…`);
        for (let i = 0; i < plan.marks.length; i += 200) {
          const r = await K.call("ac_markers", cl.id, plan.marks.slice(i, i + 200));
          if (!r.ok) { log("Маркеры: " + r.error); break; }
        }
      }
      await K.TR.link(srcKey, cl.id, K.TR.IDENT, scan().seqName);
      if (soundOk) log("Звук на месте ✓");
      status(soundOk ? `Готово: «${cl.name}»` : "Готово, но звук в копии изменился — пришлите лог.", soundOk ? "good" : "err");
      log("Лог: " + K.saveLog("autocam"));
      $("ac-result").classList.add("hidden");
    } catch (e) {
      log("ОШИБКА: " + e.message);
      log("Лог: " + K.saveLog("autocam_error"));
      status("Остановлено: " + e.message + " — оригинал не тронут.", "err");
      $("ac-apply").disabled = false;
    }
    K.setBusy(false);
  }

  $("ac-create").onclick = create;
  $("ac-apply").onclick = apply;
  $("ac-cancel").onclick = () => { hideResult(); status(""); };
  listPresets();

  K.modules.autocam = {
    title: "AutoCam", cfgKey: "ac", needsTimeline: true,
    onScan() { hideResult(); ensureDefaults(); K.saveCfg(); render(); },
    onSeg() { hideResult(); render(); },
    render, trackLevels,
  };
})();

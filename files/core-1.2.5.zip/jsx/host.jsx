// kök Edit — ExtendScript-часть (выполняется внутри Premiere).
// Правило: исходные последовательности не меняем — работаем в копиях или создаём новые.

// ---------- служебное ----------
function ac_esc(s) {
    s = String(s);
    return s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
}
function ac_toJSON(v) {
    if (v === null || v === undefined) return "null";
    var t = typeof v;
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") return '"' + ac_esc(v) + '"';
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(ac_toJSON(v[i]));
        return "[" + a.join(",") + "]";
    }
    var parts = [];
    for (var k in v) if (v.hasOwnProperty(k)) parts.push('"' + ac_esc(k) + '":' + ac_toJSON(v[k]));
    return "{" + parts.join(",") + "}";
}
function ac_err(msg) { return ac_toJSON({ ok: false, error: msg }); }
function ac_ex(e) { return ac_err(e.message + (e.line ? " (строка " + e.line + ")" : "")); }

var AC_TICKS = 254016000000;
function ac_time(sec) { var t = new Time(); t.seconds = sec; return t; }
function ac_ticks(sec) { return String(Math.round(sec * AC_TICKS)); }

function ac_findSeq(id) {
    var seqs = app.project.sequences;
    for (var i = 0; i < seqs.numSequences; i++) if (seqs[i].sequenceID == id) return seqs[i];
    return null;
}
function ac_activate(id) {
    var s = app.project.activeSequence;
    if (s && s.sequenceID == id) return s;
    app.project.openSequence(id);
    s = app.project.activeSequence;
    return (s && s.sequenceID == id) ? s : null;
}
function ac_seqIds() {
    var r = {}, seqs = app.project.sequences;
    for (var i = 0; i < seqs.numSequences; i++) r[seqs[i].sequenceID] = true;
    return r;
}
function ac_newSeqSince(before) {
    var seqs = app.project.sequences, found = null;
    for (var i = 0; i < seqs.numSequences; i++) if (!before[seqs[i].sequenceID]) found = seqs[i];
    return found;
}

// Папка (bin) в проекте по пути "kök Edit/Нарезки"
function ac_bin(pathStr) {
    var parts = pathStr.split("/"), cur = app.project.rootItem;
    for (var p = 0; p < parts.length; p++) {
        var found = null;
        for (var i = 0; i < cur.children.numItems; i++) {
            var it = cur.children[i];
            if (it.type == ProjectItemType.BIN && it.name == parts[p]) { found = it; break; }
        }
        if (!found) {
            var made = cur.createBin(parts[p]);
            found = made;
            if (!found || !found.children) {
                for (var j = 0; j < cur.children.numItems; j++) {
                    var it2 = cur.children[j];
                    if (it2.type == ProjectItemType.BIN && it2.name == parts[p]) { found = it2; break; }
                }
            }
        }
        cur = found;
    }
    return cur;
}
function ac_findItemByPath(bin, mediaPath) {
    var want = String(mediaPath).replace(/\\/g, "/").toLowerCase();
    for (var i = 0; i < bin.children.numItems; i++) {
        var it = bin.children[i];
        if (it.type == ProjectItemType.BIN) {
            var r = ac_findItemByPath(it, mediaPath);
            if (r) return r;
        } else {
            try { if (String(it.getMediaPath()).replace(/\\/g, "/").toLowerCase() == want) return it; } catch (e) {}
        }
    }
    return null;
}
function ac_import(paths, binPath) {
    var bin = ac_bin(binPath);
    app.project.importFiles(paths, true, bin, false);
    var items = [];
    for (var i = 0; i < paths.length; i++) items.push(ac_findItemByPath(bin, paths[i]) || ac_findItemByPath(app.project.rootItem, paths[i]));
    return items;
}

// ---------- чтение таймлайна ----------
function ac_clipObj(c) {
    var o = { name: "", start: 0, end: 0, inPoint: 0, path: "" };
    try { o.name = c.name; } catch (e) {}
    try { o.start = c.start.seconds; } catch (e) {}
    try { o.end = c.end.seconds; } catch (e) {}
    try { o.inPoint = c.inPoint.seconds; } catch (e) {}
    try { o.path = c.projectItem ? c.projectItem.getMediaPath() : ""; } catch (e) {}
    return o;
}
function ac_tracks(coll) {
    var res = [];
    for (var i = 0; i < coll.numTracks; i++) {
        var tr = coll[i];
        var t = { index: i, name: "", clips: [] };
        try { t.name = tr.name; } catch (e) {}
        for (var j = 0; j < tr.clips.numItems; j++) t.clips.push(ac_clipObj(tr.clips[j]));
        res.push(t);
    }
    return res;
}
function ac_scan() {
    try {
        if (!app.project) return ac_err("Нет открытого проекта");
        var seq = app.project.activeSequence;
        if (!seq) return ac_err("Нет активной последовательности");
        var st = seq.getSettings();
        return ac_toJSON({
            ok: true, premiere: app.version, seqId: seq.sequenceID, seqName: seq.name,
            frameDur: st.videoFrameRate.seconds, width: st.videoFrameWidth, height: st.videoFrameHeight,
            projectPath: app.project.path,
            video: ac_tracks(seq.videoTracks), audio: ac_tracks(seq.audioTracks)
        });
    } catch (e) { return ac_ex(e); }
}
function ac_activeId() {
    try {
        var s = app.project ? app.project.activeSequence : null;
        return ac_toJSON({ ok: true, id: s ? s.sequenceID : "", name: s ? s.name : "" });
    } catch (e) { return ac_ex(e); }
}
function ac_listSequences() {
    try {
        var r = [], seqs = app.project.sequences, act = app.project.activeSequence;
        for (var i = 0; i < seqs.numSequences; i++) {
            var s = seqs[i], st = s.getSettings();
            r.push({ id: s.sequenceID, name: s.name, end: s.end ? Number(s.end) / AC_TICKS : 0, fps: 1 / st.videoFrameRate.seconds, w: st.videoFrameWidth, h: st.videoFrameHeight });
        }
        return ac_toJSON({ ok: true, list: r, active: act ? act.sequenceID : "" });
    } catch (e) { return ac_ex(e); }
}

// ---------- копия / нарезка камер ----------
function ac_clone(id, suffix) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Исходная последовательность не найдена");
        var before = ac_seqIds();
        seq.clone();
        var copy = ac_newSeqSince(before);
        if (!copy) return ac_err("Не удалось создать копию последовательности");
        try { copy.name = seq.name + " " + suffix; } catch (e) {}
        if (!ac_activate(copy.sequenceID)) return ac_err("Не удалось открыть копию");
        return ac_toJSON({ ok: true, id: copy.sequenceID, name: copy.name });
    } catch (e) { return ac_ex(e); }
}
function ac_razor(id, ti, times) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Копия не активна — не трогаю таймлайн");
        app.enableQE();
        var qt = qe.project.getActiveSequence().getVideoTrackAt(ti);
        var st = seq.getSettings();
        for (var i = 0; i < times.length; i++) qt.razor(ac_time(times[i]).getFormatted(st.videoFrameRate, st.videoDisplayFormat));
        return ac_toJSON({ ok: true, done: times.length });
    } catch (e) { return ac_ex(e); }
}
function ac_states(id, ti, intervals, mode) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Копия не активна — не трогаю таймлайн");
        var track = seq.videoTracks[ti], list = [];
        for (var i = 0; i < track.clips.numItems; i++) list.push(track.clips[i]);
        var on = 0, off = 0;
        for (var j = 0; j < list.length; j++) {
            var c = list[j], mid = (c.start.seconds + c.end.seconds) / 2, active = false;
            for (var k = 0; k < intervals.length; k += 2) if (mid > intervals[k] && mid < intervals[k + 1]) { active = true; break; }
            if (active) { if (c.disabled) c.disabled = false; on++; }
            else { if (mode == "remove") c.remove(false, false); else c.disabled = true; off++; }
        }
        return ac_toJSON({ ok: true, on: on, off: off });
    } catch (e) { return ac_ex(e); }
}
function ac_audioSig(id) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var sig = [];
        for (var i = 0; i < seq.audioTracks.numTracks; i++) {
            var tr = seq.audioTracks[i], sum = 0;
            for (var j = 0; j < tr.clips.numItems; j++) sum += tr.clips[j].end.seconds - tr.clips[j].start.seconds;
            sig.push(tr.clips.numItems + ":" + Math.round(sum * 100));
        }
        return ac_toJSON({ ok: true, sig: sig.join("|") });
    } catch (e) { return ac_ex(e); }
}
function ac_markers(id, list) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        for (var i = 0; i < list.length; i++) {
            var m = seq.markers.createMarker(list[i].t);
            m.name = list[i].n;
            try { m.end = ac_time(list[i].t + list[i].d); } catch (e1) {}
            try { m.setColorByIndex(list[i].c % 8); } catch (e2) {}
        }
        return ac_toJSON({ ok: true, n: list.length });
    } catch (e) { return ac_ex(e); }
}

// ---------- звук ----------
// Выгрузка звука последовательности в файл. ti >= 0 — только эта дорожка (остальные временно заглушены).
function ac_renderTrack(id, ti, outPath, presetPath) {
    var seq = ac_findSeq(id);
    if (!seq) return ac_err("Последовательность не найдена");
    var saved = [], err = "", res = null;
    try {
        if (ti >= 0) for (var i = 0; i < seq.audioTracks.numTracks; i++) {
            saved.push(seq.audioTracks[i].isMuted());
            seq.audioTracks[i].setMute(i == ti ? 0 : 1);
        }
        res = seq.exportAsMediaDirect(outPath, presetPath, 0);
    } catch (e) {
        err = e.message + " (строка " + e.line + ")";
    } finally {
        for (var j = 0; j < saved.length; j++) { try { seq.audioTracks[j].setMute(saved[j] ? 1 : 0); } catch (e2) {} }
    }
    if (err) return ac_err(err);
    if (!new File(outPath).exists) return ac_err("Premiere не создал файл (" + res + ")");
    return ac_toJSON({ ok: true });
}

// Свойство «Уровень» громкости аудиоклипа
function ac_levelProp(clip) {
    for (var c = 0; c < clip.components.numItems; c++) {
        var comp = clip.components[c];
        for (var p = 0; p < comp.properties.numItems; p++) {
            var pr = comp.properties[p];
            if (/^(level|уровень)$/i.test(pr.displayName)) return pr;
        }
    }
    try { return clip.components[0].properties[1]; } catch (e) { return null; }
}

// Ключи громкости на аудиодорожке ti: keys = [[секунды последовательности, усиление дБ относительно текущего], ...]
function ac_volumeKeys(id, ti, keys) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var track = seq.audioTracks[ti], added = 0, skipped = 0, firstKey = "";
        for (var i = 0; i < track.clips.numItems; i++) {
            var clip = track.clips[i], s = clip.start.seconds, e = clip.end.seconds, inP = clip.inPoint.seconds;
            var mine = [];
            for (var k = 0; k < keys.length; k++) if (keys[k][0] >= s && keys[k][0] <= e) mine.push(keys[k]);
            if (!mine.length) continue;
            var pr = ac_levelProp(clip);
            if (!pr) { skipped++; continue; }
            if (pr.isTimeVarying()) { skipped++; continue; } // уже есть ручные ключи — не трогаем
            var base = pr.getValue();
            pr.setTimeVarying(true);
            for (var m = 0; m < mine.length; m++) {
                var t = ac_time(inP + (mine[m][0] - s)); // ключи клипа — во времени исходника
                pr.addKey(t);
                pr.setValueAtKey(t, base * Math.pow(10, mine[m][1] / 20), m == mine.length - 1);
                added++;
            }
            if (!firstKey) { try { var ks = pr.getKeys(); if (ks && ks.length) firstKey = ks[0].seconds; } catch (e3) {} }
        }
        return ac_toJSON({ ok: true, added: added, skipped: skipped, firstKey: firstKey });
    } catch (e) { return ac_ex(e); }
}

// Добавить дорожки через QE (если не хватает)
function ac_addTracks(id, nVideo, nAudio) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Не удалось открыть последовательность");
        app.enableQE();
        var qs = qe.project.getActiveSequence();
        qs.addTracks(nVideo, seq.videoTracks.numTracks, nAudio, 1, seq.audioTracks.numTracks, 0, 0, 0);
        return ac_toJSON({ ok: true, v: seq.videoTracks.numTracks, a: seq.audioTracks.numTracks });
    } catch (e) { return ac_ex(e); }
}

// Обработанный звук: положить файлы на пустые аудиодорожки с 0, исходные дорожки заглушить
// items = [{path, from: индекс исходной дорожки}]
function ac_placeAudio(id, items, binPath) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Не удалось открыть последовательность");
        var paths = [];
        for (var i = 0; i < items.length; i++) paths.push(items[i].path);
        var pis = ac_import(paths, binPath);
        // свободные дорожки после последней занятой
        var last = -1;
        for (var a = 0; a < seq.audioTracks.numTracks; a++) if (seq.audioTracks[a].clips.numItems) last = a;
        var need = last + 1 + items.length - seq.audioTracks.numTracks;
        if (need > 0) {
            app.enableQE();
            try { qe.project.getActiveSequence().addTracks(0, seq.videoTracks.numTracks, need, 1, seq.audioTracks.numTracks, 0, 0, 0); } catch (e1) {}
            seq = app.project.activeSequence;
            if (last + items.length >= seq.audioTracks.numTracks) return ac_err("Не хватает пустых аудиодорожек: добавьте " + need + " и повторите");
        }
        var placed = [];
        for (var k = 0; k < items.length; k++) {
            if (!pis[k]) return ac_err("Не удалось импортировать " + items[k].path);
            var to = last + 1 + k;
            seq.audioTracks[to].overwriteClip(pis[k], 0);
            try { seq.audioTracks[items[k].from].setMute(1); } catch (e2) {}
            placed.push(to);
        }
        return ac_toJSON({ ok: true, tracks: placed });
    } catch (e) { return ac_ex(e); }
}

// ---------- нарезки ----------
// Новая последовательность из куска [inSec, outSec] исходной
function ac_subsequence(srcId, inSec, outSec, name) {
    var seq = ac_findSeq(srcId);
    if (!seq) return ac_err("Исходная последовательность не найдена");
    var oldIn = null, oldOut = null;
    try { oldIn = seq.getInPointAsTime().seconds; oldOut = seq.getOutPointAsTime().seconds; } catch (e0) {}
    try {
        seq.setInPoint(ac_ticks(inSec));
        seq.setOutPoint(ac_ticks(outSec));
        var before = ac_seqIds();
        var sub = seq.createSubsequence(true);
        if (!sub || !sub.sequenceID) sub = ac_newSeqSince(before);
        if (!sub) return ac_err("Premiere не создал подпоследовательность");
        try { sub.name = name; } catch (e1) {}
        return ac_toJSON({ ok: true, id: sub.sequenceID, name: sub.name });
    } catch (e) { return ac_ex(e); }
    finally {
        try { if (oldIn !== null) { seq.setInPoint(ac_ticks(oldIn)); seq.setOutPoint(ac_ticks(oldOut)); } } catch (e2) {}
    }
}

function ac_motion(clip) {
    for (var c = 0; c < clip.components.numItems; c++) {
        var comp = clip.components[c];
        if (comp.matchName == "AE.ADBE Motion" || /^(motion|движение)$/i.test(comp.displayName)) return comp;
    }
    return null;
}

// Сделать последовательность вертикальной: кадр w×h, все клипы — масштаб «заполнить», по центру
function ac_makeVertical(id, w, h, srcW, srcH) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var st = seq.getSettings();
        st.videoFrameWidth = w;
        st.videoFrameHeight = h;
        seq.setSettings(st);
        var scale = Math.max(w / srcW, h / srcH) * 100, n = 0;
        for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var i = 0; i < tr.clips.numItems; i++) {
                var mo = ac_motion(tr.clips[i]);
                if (!mo) continue;
                for (var p = 0; p < mo.properties.numItems; p++) {
                    var pr = mo.properties[p], dn = pr.displayName;
                    if (/^(position|положение)$/i.test(dn)) pr.setValue([0.5, 0.5], true);
                    else if (/^(scale|масштаб)$/i.test(dn)) pr.setValue(scale, true);
                }
                n++;
            }
        }
        return ac_toJSON({ ok: true, clips: n, scale: scale });
    } catch (e) { return ac_ex(e); }
}

// Auto Reframe Premiere: создаёт новую последовательность, исходную (промежуточную) удаляем
function ac_autoReframe(id, num, den, name) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var before = ac_seqIds();
        var res = seq.autoReframeSequence(num, den, "default", name, false);
        if (!res || !res.sequenceID) res = ac_newSeqSince(before);
        if (!res) return ac_err("Auto Reframe не создал последовательность");
        try { app.project.deleteSequence(seq); } catch (e1) {}
        return ac_toJSON({ ok: true, id: res.sequenceID, name: res.name });
    } catch (e) { return ac_ex(e); }
}

function ac_moveSeqToBin(id, binPath) {
    try {
        var seq = ac_findSeq(id);
        if (seq && seq.projectItem) seq.projectItem.moveBin(ac_bin(binPath));
        return ac_toJSON({ ok: true });
    } catch (e) { return ac_ex(e); }
}

// Субтитры из SRT дорожкой субтитров
function ac_captionsSRT(id, srtPath, binPath) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var items = ac_import([srtPath], binPath);
        if (!items[0]) return ac_err("Premiere не импортировал SRT");
        var fmt = (typeof Sequence !== "undefined" && Sequence.CAPTION_FORMAT_SUBTITLE !== undefined) ? Sequence.CAPTION_FORMAT_SUBTITLE : undefined;
        if (fmt !== undefined) seq.createCaptionTrack(items[0], 0, fmt); else seq.createCaptionTrack(items[0], 0);
        return ac_toJSON({ ok: true });
    } catch (e) { return ac_ex(e); }
}

// Подставить текст в параметр MOGRT (шаблон из Premiere или After Effects)
function ac_setMgtText(item, text) {
    var comp = item.getMGTComponent();
    if (!comp) return false;
    for (var p = 0; p < comp.properties.numItems; p++) {
        var pr = comp.properties[p], v;
        try { v = pr.getValue(); } catch (e) { continue; }
        if (typeof v != "string") continue;
        if (/"textEditValue"\s*:/.test(v)) {
            var nv = v.replace(/"textEditValue"\s*:\s*"(?:[^"\\]|\\.)*"/, '"textEditValue":"' + ac_esc(text) + '"');
            pr.setValue(nv, true);
            return true;
        }
        pr.setValue(text, true);
        return true;
    }
    return false;
}

// Субтитры шаблоном .mogrt: items = [{t, d, text}] — на новую видеодорожку сверху
function ac_captionsMGT(id, mogrtPath, items) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Не удалось открыть последовательность");
        app.enableQE();
        try { qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0, 1, seq.audioTracks.numTracks, 0, 0, 0); } catch (e0) {}
        seq = app.project.activeSequence;
        var vt = seq.videoTracks.numTracks - 1, n = 0, textOk = 0;
        for (var i = 0; i < items.length; i++) {
            var it = seq.importMGT(mogrtPath, ac_ticks(items[i].t), vt, 0);
            if (!it) continue;
            try { it.end = ac_time(items[i].t + items[i].d); } catch (e1) {}
            if (ac_setMgtText(it, items[i].text)) textOk++;
            n++;
        }
        return ac_toJSON({ ok: true, n: n, text: textOk });
    } catch (e) { return ac_ex(e); }
}

// ---------- сборка из папки ----------
// Импорт готового XML (Final Cut Pro XML), созданного панелью; возвращает новую последовательность
function ac_importXML(xmlPath, binPath) {
    try {
        var before = ac_seqIds();
        app.project.importFiles([xmlPath], true, ac_bin(binPath), false);
        var s = ac_newSeqSince(before);
        if (!s) return ac_err("Premiere не создал последовательность из XML");
        ac_activate(s.sequenceID);
        return ac_toJSON({ ok: true, id: s.sequenceID, name: s.name });
    } catch (e) { return ac_ex(e); }
}

// Вставить последовательность nestId вложением в vId на время t; масштаб «заполнить кадр», маркер с названием
function ac_placeNest(vId, nestId, t, w, h, title) {
    try {
        var v = ac_activate(vId);
        if (!v) return ac_err("Не удалось открыть вертикальную последовательность");
        var nest = ac_findSeq(nestId);
        if (!nest || !nest.projectItem) return ac_err("Нарезка не найдена");
        var ns = nest.getSettings();
        v.videoTracks[0].overwriteClip(nest.projectItem, t);
        var tr = v.videoTracks[0], clip = null;
        for (var i = 0; i < tr.clips.numItems; i++) if (Math.abs(tr.clips[i].start.seconds - t) < 0.05) clip = tr.clips[i];
        if (!clip) return ac_err("Premiere не вставил нарезку на таймлайн");
        var scale = Math.max(w / ns.videoFrameWidth, h / ns.videoFrameHeight) * 100;
        var mo = ac_motion(clip);
        if (mo) for (var p = 0; p < mo.properties.numItems; p++) {
            var pr = mo.properties[p], dn = pr.displayName;
            if (/^(position|положение)$/i.test(dn)) pr.setValue([0.5, 0.5], true);
            else if (/^(scale|масштаб)$/i.test(dn)) pr.setValue(scale, true);
        }
        var dur = clip.end.seconds - clip.start.seconds;
        if (title) try { var m = v.markers.createMarker(t); m.name = title; m.end = ac_time(t + dur); } catch (e1) {}
        return ac_toJSON({ ok: true, dur: dur, scale: scale });
    } catch (e) { return ac_ex(e); }
}
function ac_activate_json(id) { return ac_toJSON({ ok: !!ac_activate(id) }); }

// Удалить маркеры, чьё имя начинается с prefix
function ac_removeMarkers(id, prefix) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var list = [], m = seq.markers.getFirstMarker();
        while (m) { list.push(m); m = seq.markers.getNextMarker(m); }
        var n = 0;
        for (var i = 0; i < list.length; i++) if (String(list[i].name).indexOf(prefix) === 0) { seq.markers.deleteMarker(list[i]); n++; }
        return ac_toJSON({ ok: true, n: n });
    } catch (e) { return ac_ex(e); }
}
// Поставить плейхед
function ac_setPlayhead(id, t) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        seq.setPlayerPosition(ac_ticks(t));
        return ac_toJSON({ ok: true });
    } catch (e) { return ac_ex(e); }
}

// ---------- вырезание пауз (только в копии) ----------
// Все дорожки режутся в одних и тех же местах и сдвигаются на одно и то же время — синхрон не теряется.
function ac_allTracks(seq) {
    var r = [], i;
    for (i = 0; i < seq.videoTracks.numTracks; i++) r.push({ t: seq.videoTracks[i], name: "V" + (i + 1), video: true, i: i });
    for (i = 0; i < seq.audioTracks.numTracks; i++) r.push({ t: seq.audioTracks[i], name: "A" + (i + 1), video: false, i: i });
    return r;
}
function ac_cutCheck(id) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Копия не активна — не трогаю таймлайн");
        var tr = ac_allTracks(seq), locked = [], n = 0;
        for (var i = 0; i < tr.length; i++) {
            var lk = false;
            try { lk = tr[i].t.isLocked(); } catch (e) {}
            if (lk && tr[i].t.clips.numItems) locked.push(tr[i].name);
            n += tr[i].t.clips.numItems;
        }
        if (locked.length) return ac_err("Заблокированы дорожки " + locked.join(", ") + " — разблокируйте их в копии или в исходной и повторите.");
        var canMove = false;
        for (var c = 0; c < tr.length && !canMove; c++) if (tr[c].t.clips.numItems) { try { canMove = !!tr[c].t.clips[0].move; } catch (e) {} break; }
        return ac_toJSON({ ok: true, items: n, canMove: canMove });
    } catch (e) { return ac_ex(e); }
}
function ac_cutRazor(id, times) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Копия не активна — не трогаю таймлайн");
        app.enableQE();
        var q = qe.project.getActiveSequence(), st = seq.getSettings(), nv = seq.videoTracks.numTracks, na = seq.audioTracks.numTracks;
        for (var k = 0; k < times.length; k++) {
            var tc = ac_time(times[k]).getFormatted(st.videoFrameRate, st.videoDisplayFormat);
            for (var i = 0; i < nv; i++) if (seq.videoTracks[i].clips.numItems) q.getVideoTrackAt(i).razor(tc);
            for (var j = 0; j < na; j++) if (seq.audioTracks[j].clips.numItems) q.getAudioTrackAt(j).razor(tc);
        }
        return ac_toJSON({ ok: true, n: times.length });
    } catch (e) { return ac_ex(e); }
}
// убрать куски внутри вырезаемых мест (без сдвига); если клип пересекает границу — значит, разрезать не вышло: стоп
function ac_cutRemove(id, cuts, eps) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Копия не активна — не трогаю таймлайн");
        var tr = ac_allTracks(seq), bad = [], kill = [];
        for (var i = 0; i < tr.length; i++) {
            var cl = tr[i].t.clips;
            for (var j = 0; j < cl.numItems; j++) {
                var it = cl[j], s = it.start.seconds, e = it.end.seconds;
                for (var k = 0; k < cuts.length; k += 2) {
                    var a = cuts[k], b = cuts[k + 1];
                    if (e <= a + eps || s >= b - eps) continue;
                    if (s >= a - eps && e <= b + eps) kill.push(it);
                    else bad.push(tr[i].name + " " + Math.floor(a / 60) + ":" + ("0" + (a % 60).toFixed(1)).slice(-4));
                    break;
                }
            }
        }
        if (bad.length) return ac_err("Не удалось разрезать: " + bad.slice(0, 5).join(", ") + (bad.length > 5 ? " и ещё " + (bad.length - 5) : "") + ". Копия не доделана — удалите её; исходная не тронута.");
        for (var m = kill.length - 1; m >= 0; m--) { try { kill[m].remove(false, false); } catch (e2) {} }
        return ac_toJSON({ ok: true, removed: kill.length });
    } catch (e) { return ac_ex(e); }
}
// сдвинуть влево все клипы, которые начинались в [t0, t1). cuts — [a0,b0,a1,b1,…] в исходном времени
// Порядок — по времени через все дорожки, поэтому сдвигаемый клип никогда не наезжает на соседа.
function ac_cutMove(id, cuts, t0, t1, eps) {
    try {
        var seq = ac_activate(id);
        if (!seq) return ac_err("Копия не активна — не трогаю таймлайн");
        var shift = function (t) { var s = 0; for (var k = 0; k < cuts.length; k += 2) { if (cuts[k + 1] <= t + eps) s += cuts[k + 1] - cuts[k]; else break; } return s; };
        var tr = ac_allTracks(seq), list = [];
        for (var i = 0; i < tr.length; i++) {
            var cl = tr[i].t.clips;
            for (var j = 0; j < cl.numItems; j++) {
                var s = cl[j].start.seconds;
                if (s >= t0 - eps && s < t1 - eps) list.push({ it: cl[j], s: s, target: s - shift(s), name: tr[i].name });
            }
        }
        list.sort(function (x, y) { return x.s - y.s; });
        var moved = 0;
        for (var n = 0; n < list.length; n++) {
            var o = list[n], cur = o.it.start.seconds;
            if (Math.abs(cur - o.target) < eps) continue; // уже на месте (сдвинулся вместе со связанным клипом)
            o.it.move(ac_time(o.target - cur));
            var now = o.it.start.seconds;
            if (Math.abs(now - o.target) >= eps) return ac_err("Premiere сдвинул клип на " + o.name + " не туда (" + cur.toFixed(2) + " → " + now.toFixed(2) + " вместо " + o.target.toFixed(2) + "). Копия испорчена — удалите её; исходная не тронута.");
            moved++;
        }
        return ac_toJSON({ ok: true, moved: moved, failed: 0 });
    } catch (e) { return ac_ex(e); }
}
// маркеры копии — тоже сдвигаем, чтобы остались на своих словах
function ac_cutMarkers(id, cuts, eps) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var shift = function (t) { var s = 0; for (var k = 0; k < cuts.length; k += 2) { if (cuts[k + 1] <= t + eps) s += cuts[k + 1] - cuts[k]; else if (cuts[k] < t) { s += t - cuts[k]; break; } else break; } return s; };
        var list = [], m = seq.markers.getFirstMarker(), n = 0;
        while (m) { list.push(m); m = seq.markers.getNextMarker(m); }
        for (var i = 0; i < list.length; i++) {
            var st = list[i].start.seconds, en = list[i].end.seconds, d = shift(st);
            if (d < eps) continue;
            try { list[i].start = ac_time(st - d); list[i].end = ac_time(Math.max(st - d, en - shift(en))); n++; } catch (e) {}
        }
        return ac_toJSON({ ok: true, n: n, total: list.length });
    } catch (e) { return ac_ex(e); }
}
// проверка после: нет наложений на дорожках, длина как ожидалась
function ac_cutVerify(id, eps) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var tr = ac_allTracks(seq), over = [], items = 0;
        for (var i = 0; i < tr.length; i++) {
            var cl = tr[i].t.clips, prevEnd = -1;
            for (var j = 0; j < cl.numItems; j++) {
                items++;
                var s = cl[j].start.seconds;
                if (s < prevEnd - eps) over.push(tr[i].name + " " + s.toFixed(1));
                prevEnd = Math.max(prevEnd, cl[j].end.seconds);
            }
        }
        return ac_toJSON({ ok: true, end: Number(seq.end) / AC_TICKS, items: items, overlaps: over.slice(0, 10), nOver: over.length });
    } catch (e) { return ac_ex(e); }
}

// ---------- учёт времени: признаки активности ----------
// Плагин раз в несколько секунд сравнивает: файл проекта, последовательность, плейхед, длина, число клипов.
function ac_activity() {
    try {
        if (!app.project) return ac_toJSON({ ok: true, path: "" });
        var seq = app.project.activeSequence, sig = "", cti = 0;
        if (seq) {
            var n = 0, i;
            for (i = 0; i < seq.videoTracks.numTracks; i++) n += seq.videoTracks[i].clips.numItems;
            for (i = 0; i < seq.audioTracks.numTracks; i++) n += seq.audioTracks[i].clips.numItems;
            try { cti = seq.getPlayerPosition().seconds; } catch (e) {}
            sig = seq.sequenceID + "|" + seq.end + "|" + n;
        }
        return ac_toJSON({ ok: true, path: app.project.path, name: app.project.name, seq: seq ? seq.sequenceID : "", seqName: seq ? seq.name : "", sig: sig, cti: cti });
    } catch (e) { return ac_ex(e); }
}

// ---------- общая расшифровка ----------
// «Отпечаток» звука последовательности: какие клипы, где лежат и с какого места взяты. Тот же звук → та же расшифровка.
function ac_audioKey(id) {
    try {
        var seq = ac_findSeq(id);
        if (!seq) return ac_err("Последовательность не найдена");
        var parts = [];
        for (var i = 0; i < seq.audioTracks.numTracks; i++) {
            var cl = seq.audioTracks[i].clips, t = [];
            for (var j = 0; j < cl.numItems; j++) {
                var c = cl[j], nm = "";
                try { nm = c.projectItem ? (c.projectItem.getMediaPath() || c.projectItem.name) : c.name; } catch (e) { nm = c.name; }
                t.push(nm + "@" + Math.round(c.start.seconds * 100) + "-" + Math.round(c.end.seconds * 100) + "+" + Math.round(c.inPoint.seconds * 100));
            }
            parts.push(t.join(","));
        }
        return ac_toJSON({ ok: true, key: parts.join("|"), end: seq.end ? Number(seq.end) / AC_TICKS : 0 });
    } catch (e) { return ac_ex(e); }
}
